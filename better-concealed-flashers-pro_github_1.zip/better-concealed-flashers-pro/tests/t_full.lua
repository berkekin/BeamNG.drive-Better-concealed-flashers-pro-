-- tam yukleme testi: mod, oyunun gercek jbeam yukleyicisi icinde (oyun disinda) calisir
QUIET = QUIET_FLAG
local B = require('bench')
local bcfpPro = require('bcfpPro')
EXT.bcfpPro = bcfpPro
bcfpPro.onExtensionLoaded()
local m = bcfpPro._mods
local loader = require('jbeam/loader')

local ZONES = {'windshield', 'dash', 'grille', 'bumperF', 'hood', 'hideF', 'mirrors', 'sideF', 'skirt', 'sideRear', 'rearglass', 'reardeck',
               'trunk', 'bumperR', 'hideR', 'roof'}

local function defaultPc(model)
  local info = jsonReadFile('/vehicles/' .. model .. '/info.json')
  local d = type(info) == 'table' and info.default_pc
  local pcs = B.pcs(model)
  if d then for _, p in ipairs(pcs) do if p == d then return p end end end
  return pcs[1]
end

local function run(model, pcn, opts)
  opts = opts or {}
  pcn = pcn or defaultPc(model) or model
  local pc = jsonReadFile('/vehicles/' .. model .. '/' .. pcn .. '.pc')
  if type(pc) ~= 'table' then pc = {parts = {}} pcn = '(varsayilan)' end
  local items = {}
  for i, z in ipairs(opts.zones or ZONES) do
    items[#items + 1] = {kind = 'array', anchor = z, colB = (i % 3 == 0) and 3 or 0}
  end
  if opts.mlbar then items[#items + 1] = {kind = 'mlbar', len = 139} end
  local cfg = {parts = deepcopy(pc.parts), vars = pc.vars, bcfp = {v = 3, enabled = true, items = items}}
  for k, v in pairs(opts.parts or {}) do cfg.parts[k] = v end
  local t0 = py_clock()
  local nlog = #LOGS
  local ok, bundle = xpcall(function() return loader.loadJbeam(nil, nil, {'/vehicles/' .. model .. '/', '/vehicles/common/'}, cfg) end, debug.traceback)
  if not ok or not bundle then print(model .. '/' .. pcn .. ': YUKLEME HATASI ' .. tostring(bundle)) return end
  local v = bundle.vdata
  local rt = v.bcfpRuntime
  local dt = py_clock() - t0
  if not rt then print(model .. '/' .. pcn .. ': bcfpRuntime yok') return end
  -- gorseller: dugum baglari
  local flexByPart = {}
  local unbound, total = 0, 0
  for _, f in pairs(v.flexbodies or {}) do
    if type(f.mesh) == 'string' and f.mesh:find('^bcfp_h') then
      total = total + 1
      local n = f._group_nodes and #f._group_nodes or 0
      if n < 3 then unbound = unbound + 1 end
    end
  end
  local lights, badLights = 0, 0
  for _, p in pairs(v.props or {}) do
    if type(p.func) == 'string' and p.func:find('^bcfp_u') then
      lights = lights + 1
      if type(p.idRef) ~= 'number' or type(p.idX) ~= 'number' or type(p.idY) ~= 'number' then badLights = badLights + 1 end
    end
  end
  local glow = 0
  for mat in pairs(v.glowMap or {}) do if mat:find('^bcfp_k_u') then glow = glow + 1 end end
  local zrows = 0
  for _, r in pairs(v.bcfpZones or {}) do if type(r) == 'table' then zrows = zrows + 1 end end
  local ctrl = 0
  for _, c in pairs(v.controller or {}) do if type(c) == 'table' and c.fileName == 'bcfp_flasher' then ctrl = ctrl + 1 end end
  local env = m.E.cache[rt.envKey or '']
  print(string.format('== %s/%s: %.1fs  flex %d (bagsiz %d)  isik %d (hatali %d)  glow %d  zones %d  ctrl %d  gizlenen fabrika %s  uyarilar %d', model, pcn, dt, total, unbound,
    lights, badLights, glow, zrows, ctrl, tostring(rt.hiddenFactory), #(rt.warnings or {})))
  for _, w in ipairs(rt.warnings or {}) do print('   UYARI: ' .. (type(w) == 'table' and (tostring(w.k) .. ': ' .. tostring(w.v)) or tostring(w))) end
  for i = nlog + 1, #LOGS do print('   LOG ' .. LOGS[i]) end
  if not opts.brief then
    for _, it in ipairs(rt.items) do
      if it.kind == 'array' then
        local h = it.heads and it.heads[1]
        local H = env and env.hints and env.hints[it.anchor]
        local cmp = ''
        if H and h then
          cmp = string.format('  [fabrika %s: y=%.3f z=%.3f]', H.part, H.heads[1].y, H.heads[1].z)
        end
        print(string.format('   %-4s %-10s %-8s n=%d %s x0=%.1f gap=%.1f bagli=%s%s', it.id, it.anchor, tostring(it.src), it.heads and #it.heads or 0,
          h and string.format('ilk=(%.3f, %.3f, %.3f) yaw=%.0f tilt=%.0f', h[1], h[2], h[3], h[4], h[5]) or 'YOK', it.x0 or -1, it.gap or -1, tostring(it.bound), cmp))
      else
        print(string.format('   %-4s %s src=%s T=%s', it.id, it.kind, tostring(it.src), it.T and string.format('(%.3f, %.3f, %.3f)', it.T[1], it.T[2], it.T[3]) or '-'))
      end
    end
  end
  return v, rt, env
end

if ARGS and ARGS[1] then
  local spec = ARGS[1]
  local model, pcn = spec:match('^([^:]+):?(.*)$')
  if pcn == '' then pcn = nil end
  local parts
  if ARGS[2] then
    parts = {}
    for kv in ARGS[2]:gmatch('[^,]+') do
      local k, val = kv:match('^(.-)=(.*)$')
      if k then parts[k] = val end
    end
  end
  run(model, pcn, {parts = parts, mlbar = true})
end
return run
