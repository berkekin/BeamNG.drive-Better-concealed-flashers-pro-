-- tani: aracin taranan modelleri, siniflari, ucgen sayilari, eksik mesh'ler
--   python3 eng.py build/tests/t_meshes.lua <model>[:pc] [filtre]
local B = require('bench')
local m = B.mods()
local spec = ARGS[1]
local model, pcn = spec:match('^([^:]+):?(.*)$')
if pcn == '' then
  local info = jsonReadFile('/vehicles/' .. model .. '/info.json')
  pcn = (type(info) == 'table' and info.default_pc) or B.pcs(model)[1]
end
local ioCtx, cfg, r = B.find(model, pcn)
assert(ioCtx, tostring(cfg))
local env = m.E.forLoad(ioCtx, cfg, r)
local M = env.M
print(string.format('== %s/%s  dosya %s okunan %s gereken %s eksik %s ucgen %s', model, pcn, tostring(M and M.stats.files), tostring(M and M.stats.filesRead),
  tostring(M and M.stats.need), tostring(M and M.stats.missing), tostring(M and M.nt)))
for _, w in ipairs(env.warnings or {}) do print('   UYARI ' .. (type(w) == 'table' and (w.k .. ': ' .. tostring(w.v)) or tostring(w))) end
if not M then return end
local CN = {[0] = 'SKIP', 'BODY', 'GLASS', 'LAMP', 'INT', 'EQUIP', 'PLATE'}
local cnt = {}
for k = 1, M.nt do local c = M.C[k] cnt[c] = (cnt[c] or 0) + 1 end
local parts = {}
for c, n in pairs(cnt) do parts[#parts + 1] = CN[c] .. '=' .. n end
print('   siniflar: ' .. table.concat(parts, ' '))
local filt = ARGS[2]
for i, me in ipairs(M.meshes or {}) do
  local nt = (me.t1 and me.t0) and (me.t1 - me.t0 + 1) or 0
  local bb = me.bbox and string.format(' y[%.2f..%.2f] z[%.2f..%.2f]', me.bbox[2], me.bbox[5], me.bbox[3], me.bbox[6]) or ''
  local cc = {}
  if me.t0 then for k = me.t0, me.t1 do local c = M.C[k] cc[c] = (cc[c] or 0) + 1 end end
  local cs = {}
  for c, n in pairs(cc) do cs[#cs + 1] = CN[c] .. n end
  local s = (me.name or '?') .. ' ' .. (CN[me.cls] or tostring(me.cls)) .. ' tris=' .. nt .. ' [' .. table.concat(cs, ',') .. ']' .. bb
  if not filt or s:lower():find(filt:lower(), 1, true) then print('   ' .. s) end
end
local F = m.Pl.frames(M)
local z = {}
for _, zd in ipairs(m.Pl.ZONES) do z[#z + 1] = zd.id .. '=' .. (F[zd.id] and 'ok' or '-') end
print('   cerceveler: ' .. table.concat(z, ' '))
print('   cam: on ' .. #(M.glass and M.glass.front or {}) .. ' arka ' .. #(M.glass and M.glass.rear or {}) .. ' sol ' .. #(M.glass and M.glass.sideL or {}))
