-- yerlesim sonucunu (yuzey modeli + basliklar) goruntuleme araci icin disari yazar
QUIET_FLAG = true
local run = dofile(BUILD .. '/tests/t_full.lua')
local ffi = require('ffi')
local spec = ARGS[1] or 'lansdale'
local outDir = ARGS[2] or '/tmp/bcfp_render'
local zonesArg = ARGS[3]
local model, pcn = spec:match('^([^:]+):?(.*)$')
if pcn == '' then pcn = nil end
local zones
if zonesArg and zonesArg ~= '' and zonesArg ~= '-' then
  zones = {}
  for z in zonesArg:gmatch('[^,]+') do zones[#zones + 1] = z end
end
local parts
if ARGS[4] then
  parts = {}
  for kv in ARGS[4]:gmatch('[^,]+') do
    local k, val = kv:match('^(.-)=(.*)$')
    if k then parts[k] = val end
  end
end
local v, rt, env = run(model, pcn, {zones = zones, mlbar = false, parts = parts})
if not env or not env.M then print('model yok') return end
local M = env.M
os.execute('mkdir -p ' .. outDir)
local n = M.nt * 9
local buf = ffi.new('float[?]', n)
local T = M.T
for i = 1, n do buf[i - 1] = T[i] end
local f = io.open(outDir .. '/tris.bin', 'wb') f:write(ffi.string(buf, n * 4)) f:close()
local cb = ffi.new('uint8_t[?]', M.nt)
for i = 1, M.nt do cb[i - 1] = M.C[i] end
f = io.open(outDir .. '/cls.bin', 'wb') f:write(ffi.string(cb, M.nt)) f:close()
-- basliklar
local m = EXT.bcfpPro._mods
local lines = {}
for _, it in ipairs(rt.items) do
  if it.kind == 'array' then
    local ut = m.Un.get(it.head)
    for _, h in ipairs(it.heads or {}) do
      lines[#lines + 1] = string.format('%s %s %s %.4f %.4f %.4f %.2f %.2f %.4f %.4f %.4f', it.id, it.anchor, tostring(it.src), h[1], h[2], h[3], h[4], h[5], ut.w, ut.h, ut.d)
    end
  end
end
-- fabrika basliklari (karsilastirma)
for zone, H in pairs(env.hints or {}) do
  for _, h in ipairs(H.heads) do
    lines[#lines + 1] = string.format('dev %s dev %.4f %.4f %.4f %.2f %.2f %.4f %.4f %.4f', zone, h.x, h.y, h.z, h.yaw, h.tilt or 0, H.dims.w, H.dims.h, H.dims.d)
  end
end
f = io.open(outDir .. '/heads.txt', 'w') f:write(table.concat(lines, '\n') .. '\n') f:close()
f = io.open(outDir .. '/info.txt', 'w') f:write(model .. ' ' .. tostring(pcn) .. ' ' .. M.nt .. '\n') f:close()
print('yazildi', outDir, M.nt, #lines)
