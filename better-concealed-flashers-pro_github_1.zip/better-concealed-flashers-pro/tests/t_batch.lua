-- toplu tam yukleme testi (ozet satirlari)
QUIET_FLAG = true
local run = dofile(BUILD .. '/tests/t_full.lua')
local m = EXT.bcfpPro._mods
local names = {}
for i, a in ipairs(ARGS) do names[i] = a end
local tot = {veh = 0, items = 0, factory = 0, scan = 0, approx = 0, unbound = 0, bad = 0, fail = 0}
for _, spec in ipairs(names) do
  local model, pcn = spec:match('^([^:]+):?(.*)$')
  if pcn == '' then pcn = nil end
  local t0 = py_clock()
  local ok, v, rt, env = pcall(run, model, pcn, {brief = true, mlbar = true})
  if not ok then
    print(model .. ': HATA ' .. tostring(v))
    tot.fail = tot.fail + 1
  elseif rt then
    tot.veh = tot.veh + 1
    local c = {factory = {}, scan = {}, approx = {}}
    for _, it in ipairs(rt.items) do
      if it.kind == 'array' then
        tot.items = tot.items + 1
        local s = it.src or 'approx'
        tot[s] = (tot[s] or 0) + 1
        c[s] = c[s] or {}
        c[s][#c[s] + 1] = it.anchor
      end
    end
    print(string.format('   fabrika: %s | yaklasik: %s | tarama %s ucgen %s', table.concat(c.factory, ','), table.concat(c.approx, ','),
      env and env.stats.scan and string.format('%.2fs', env.stats.scan) or '-', env and tostring(env.stats.tris) or '-'))
  else
    tot.fail = tot.fail + 1
  end
  m.E.invalidate()
  collectgarbage()
end
print(string.format('TOPLAM arac %d, dizi %d: fabrika %d, tarama %d, yaklasik %d, hata %d', tot.veh, tot.items, tot.factory, tot.scan, tot.approx, tot.fail))
