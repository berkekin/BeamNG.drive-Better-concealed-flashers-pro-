-- test tezgahi: mod modullerini oyunun gercek jbeam yukleyicisi ile (oyun disinda) calistirir
local B = {}
local function req(name) return require('bcfp/' .. name) end
function B.mods()
  if B._mods then return B._mods end
  local m = {}
  m.U = req('util'); m.P = req('palette'); m.G = req('geom'); m.D = req('dae'); m.Sc = req('scan'); m.Pl = req('place')
  m.H = req('hints'); m.E = req('env')
  m.G.init(m.U)
  m.Sc.init({U = m.U, D = m.D})
  m.Pl.init({U = m.U, S = m.Sc})
  m.H.init(m)
  m.E.init(m)
  B._mods = m
  return m
end

local jbeamIO = require('jbeam/io')
local ss = require('jbeam/slotSystem')

-- model + .pc adi -> ioCtx, cfg, findParts sonuclari
function B.find(model, pcName, extraParts)
  local dirs = {'/vehicles/' .. model .. '/', '/vehicles/common/'}
  local ioCtx = jbeamIO.startLoading(dirs)
  local cfg = {model = model}
  if pcName then
    local pc = jsonReadFile('/vehicles/' .. model .. '/' .. pcName .. '.pc')
    if type(pc) ~= 'table' then return nil, 'pc okunamadi: ' .. tostring(pcName) end
    cfg.parts = pc.parts
    cfg.vars = pc.vars
  end
  for k, v in pairs(extraParts or {}) do
    cfg.parts = cfg.parts or {}
    cfg.parts[k] = v
  end
  cfg.mainPartName = jbeamIO.getMainPartName(ioCtx)
  if not cfg.mainPartName then return nil, 'ana parca yok' end
  cfg.mainPartPath = '/' .. cfg.mainPartName
  local r = {ss.findParts(ioCtx, cfg)}
  if not r[1] then return nil, 'findParts basarisiz' end
  return ioCtx, cfg, r
end

function B.pcs(model)
  local out = {}
  for _, f in ipairs(FS:findFiles('/vehicles/' .. model .. '/', '*.pc', 0, false, false)) do
    local n = f:match('([^/]+)%.pc$')
    if n and not f:match('/vehicles/[^/]+/[^/]+/') then out[#out + 1] = n end
  end
  table.sort(out)
  return out
end

return B
