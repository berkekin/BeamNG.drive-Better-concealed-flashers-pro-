-- gelistirici (orijinal) cakar konumlariyla cozucu karsilastirmasi (cihazda lt.py ile calisir)
local D = require('bcfp/dae')
local S = require('bcfp/scan')
local P = require('bcfp/place')
local U = {}
S.init({D = D, U = U})
P.init({S = S, U = U})

local rows = py_json(py_readtext('~/w/vanilla_flashers.json'))
local dumps = py_dumps()
local only = ARGS and ARGS[1]

local gt = {}
for _, r in ipairs(rows) do
  local veh, part, mesh, grp, pos, rot, scale = r[1], r[2], r[4], r[5], r[6], r[7], r[8]
  if type(mesh) == 'string' and mesh:find('generic_flasher', 1, true) and type(pos) == 'table' and veh ~= 'common' and veh ~= 'us_semi' then
    local function n(v, d) v = tonumber(v) if v == nil then return d end return v end
    rot = type(rot) == 'table' and rot or {}
    scale = type(scale) == 'table' and scale or {}
    if tonumber(pos.x) and tonumber(pos.y) and tonumber(pos.z) and (rot.z == nil or tonumber(rot.z)) then
      gt[veh] = gt[veh] or {}
      gt[veh][part] = gt[veh][part] or {}
      local g = type(grp) == 'table' and table.concat(grp, ',') or tostring(grp)
      table.insert(gt[veh][part], {x = n(pos.x, 0), y = n(pos.y, 0), z = n(pos.z, 0), rx = n(rot.x, 0), ry = n(rot.y, 0), rz = n(rot.z, 0),
        sx = n(scale.x, 1), sy = n(scale.y, 1), sz = n(scale.z, 1), grp = g})
    end
  end
end

local function pickDump(veh, part)
  local best, bestHas, bestVan
  for _, key in ipairs(dumps) do
    local m = key:match('^(.-)__')
    if m == veh then
      local d = py_dump(key)
      local has = false
      for _, p in ipairs(d.parts or {}) do if p[2] == part then has = true break end end
      if has then return key, d, true end
      local van = py_exists('~/w/ref/vehicles/' .. veh .. '/' .. key:match('__(.*)$') .. '.pc')
      if not best or (van and not bestVan) or (van == bestVan and #key < #best) then best, bestVan = key, van end
    end
  end
  if best then return best, py_dump(best), false end
end

local models = {}
local function getModel(key, d)
  if models[key] ~= nil then return models[key] end
  local flex = {}
  for i, f in ipairs(d.flex) do
    if not tostring(f.m):find('generic_flasher', 1, true) then
      flex[#flex + 1] = {mesh = f.m, pos = f.pos, rot = f.rot, scale = f.scale, part = f.part}
    end
  end
  local t0 = py_clock()
  local M, err = S.build(flex, d.dirs, d.model)
  if not M then print(string.format('  BUILD FAIL %s: %s', key, tostring(err))) models[key] = false return false end
  print(string.format('  [%s] %d tris, %.2fs, glass F/R/sL/sR %d/%d/%d/%d', key, M.nt, py_clock() - t0, #M.glass.front, #M.glass.rear, #M.glass.sideL, #M.glass.sideR))
  models[key] = M
  return M
end

local vehs = {}
for veh in pairs(gt) do vehs[#vehs + 1] = veh end
table.sort(vehs)
local stats = {}
local function stat(zone, dy, dz)
  stats[zone] = stats[zone] or {n = 0, ay = 0, az = 0, my = 0, mz = 0}
  local s = stats[zone]
  s.n = s.n + 1
  s.ay, s.az = s.ay + math.abs(dy), s.az + math.abs(dz)
  s.my, s.mz = math.max(s.my, math.abs(dy)), math.max(s.mz, math.abs(dz))
end

for _, veh in ipairs(vehs) do
  if not only or only == veh then
    print('== ' .. veh)
    local parts = {}
    for part in pairs(gt[veh]) do parts[#parts + 1] = part end
    table.sort(parts)
    for _, part in ipairs(parts) do
      local key, d, has = pickDump(veh, part)
      local M = key and getModel(key, d)
      if M then
        local F = P.frames(M)
        local zRoof = M.bbox[6]
        -- kumeler: yon + yukseklik
        local clusters = {}
        for _, f in ipairs(gt[veh][part]) do
          if f.x > 0 then
            local rear = math.abs(math.abs(f.rz) - 180) < 40
            local frontF = math.abs(f.rz) < 40
            local ck = (rear and 'R' or (frontF and 'F' or 'S')) .. string.format('%.1f', f.z)
            clusters[ck] = clusters[ck] or {rear = rear, front = frontF, list = {}}
            table.insert(clusters[ck].list, f)
          end
        end
        for ck, c in pairs(clusters) do
          local f0 = c.list[1]
          local zone
          local high = f0.z > zRoof - 0.48
          if c.front then
            if high and f0.y > M.bbox[2] + 0.9 then zone = 'windshield'
            elseif f0.grp:find('grille') or f0.grp:find('fascia') then zone = 'grille'
            elseif f0.grp:find('hood') then zone = 'hood'
            else zone = 'bumperF' end
          elseif c.rear then
            if f0.y < M.bbox[5] - 0.25 and f0.z > zRoof - 0.75 then zone = 'rearwin'
            elseif f0.grp:find('trunk') or f0.grp:find('tailgate') then zone = 'trunk'
            else zone = 'bumperR' end
          end
          if zone then
            local sdy, sdz, n, extra = 0, 0, 0, ''
            local used = zone
            for _, f in ipairs(c.list) do
              local dims = {w = 0.0652 * f.sx, h = 0.0406 * f.sz, d = 0.017 * f.sy}
              local p
              if zone == 'windshield' then
                p = P.head(M, 'windshield', 1, f.x, dims, {})
              elseif zone == 'rearwin' then
                local a = P.head(M, 'rearglass', 1, f.x, dims, {})
                local b = P.head(M, 'reardeck', 1, f.x, dims, {})
                local da = a and (math.abs(a.y - f.y) + math.abs(a.z - f.z)) or 9
                local db = b and (math.abs(b.y - f.y) + math.abs(b.z - f.z)) or 9
                if da <= db then p, used = a, 'rearglass' else p, used = b, 'reardeck' end
              elseif zone == 'grille' or zone == 'bumperF' or zone == 'hood' then
                p = P.faceY(M, 1, f.x, f.z, dims.w / 2, dims.h / 2, dims.d / 2, {sink = 0.5})
                if p then extra = string.format(' yaw %+.0f/%+.0f tilt %+.0f/%+.0f %s', p.yaw, f.rz, p.tilt, -f.rx, tostring(p.tag)) end
              else
                p = P.faceY(M, -1, f.x, f.z, dims.w / 2, dims.h / 2, dims.d / 2, {sink = 0.5})
                if p then extra = string.format(' yaw %+.0f/%+.0f tilt %+.0f/%+.0f %s', p.yaw, f.rz, p.tilt, -f.rx, tostring(p.tag)) end
              end
              if p then
                sdy, sdz, n = sdy + (p.y - f.y), sdz + (p.z - f.z), n + 1
                stat(used, p.y - f.y, p.z - f.z)
              end
            end
            if n > 0 then
              print(string.format('  %-36s %-10s n=%d x=%.2f..%.2f gt(y=%.3f z=%.3f) dY=%+.3f dZ=%+.3f%s%s', part, used, n, c.list[1].x, c.list[#c.list].x,
                f0.y, f0.z, sdy / n, sdz / n, extra, has and '' or ' (*)'))
            else
              print(string.format('  %-36s %-10s NO SOLUTION (gt y=%.3f z=%.3f)', part, zone, f0.y, f0.z))
            end
          end
        end
        -- bolge cerceveleri ozeti
      end
    end
    for key, M in pairs(models) do
      if M and key:match('^(.-)__') == veh then
        local F = P.frames(M)
        local function fz(z) return z and string.format('x0=%.2f n=%s z=%s', z.x0 or 0, tostring(z.n), z.z and string.format('%.2f', z.z) or '-') or 'YOK' end
        print(string.format('  frames[%s]: halfW=%.2f ws{%s} rg{%s} grille{%s %s} bF{%s} bR{%s} trunk{%s}', key, F.halfW, fz(F.windshield), fz(F.rearglass), fz(F.grille),
          tostring(F.grille and F.grille.src), fz(F.bumperF), fz(F.bumperR), fz(F.trunk)))
        break
      end
    end
  end
end
print('---- ozet (ortalama |dY|, |dZ|; en buyuk)')
for zone, s in pairs(stats) do
  print(string.format('%-10s n=%3d  dY %.3f (max %.3f)  dZ %.3f (max %.3f)', zone, s.n, s.ay / s.n, s.my, s.az / s.n, s.mz))
end
