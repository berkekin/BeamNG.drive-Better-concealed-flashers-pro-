-- arayuz katmani testi (oyun disinda): durum paketi, hazir kit, bolge ac / kapat, canli guncelleme, profiller.
-- Oyunun arac nesnesi ve arac yoneticisi taklit edilir; "yeniden yukleme" oyunun gercek jbeam yukleyicisiyle yapilir.
--   python3 eng.py build/tests/t_ui.lua lansdale:25_base_A [durum.json]
QUIET = QUIET_FLAG
local B = require('bench')
local bcfpPro = require('bcfpPro')
EXT.bcfpPro = bcfpPro
bcfpPro.onExtensionLoaded()
local m = bcfpPro._mods
local UI = m.UI
local loader = require('jbeam/loader')

local spec = (ARGS and ARGS[1]) or 'lansdale'
local model, pcn = spec:match('^([^:]+):?(.*)$')
if pcn == '' then
  local info = jsonReadFile('/vehicles/' .. model .. '/info.json')
  pcn = (type(info) == 'table' and info.default_pc) or B.pcs(model)[1]
end
local pc = jsonReadFile('/vehicles/' .. model .. '/' .. pcn .. '.pc')
assert(type(pc) == 'table', 'pc yok: ' .. tostring(pcn))

local fails, checks = 0, 0
local function check(cond, what)
  checks = checks + 1
  if not cond then
    fails = fails + 1
    print('   BASARISIZ: ' .. tostring(what))
  end
  return cond
end

-- ---------------------------------------------------------------- oyun taklidi
local VID = 7
local veh = {cmds = {}, respawns = 0}
function veh:queueLuaCommand(c) self.cmds[#self.cmds + 1] = c end
function veh:setField(k, i, v) self.partConfig = v end
function veh:respawn(s) self.respawns = self.respawns + 1; self.wantReload = true end
function veh:getID() return VID end
be = {}
function be:getObjectByID(id) return id == VID and veh or nil end
function be:getPlayerVehicleID(i) return VID end
function be:getObjectCount() return 1 end
function be:getObject(i) return veh end
local vd = {config = {model = model, parts = deepcopy(pc.parts), vars = pc.vars}}
core_vehicle_manager = {getVehicleData = function(id) return id == VID and vd or nil end}
local EVENTS = {}
guihooks = {trigger = function(name, data) EVENTS[#EVENTS + 1] = {name = name, data = data} end, message = function() end}
local WRITTEN = {}
jsonWriteFile = function(path, data) WRITTEN[path] = deepcopy(data) return true end
local origJsonRead = jsonReadFile
jsonReadFile = function(path)
  if WRITTEN[path] then return deepcopy(WRITTEN[path]) end
  if path:find('^/settings/') then return nil end
  return origJsonRead(path)
end
core_vehicles = {getModel = function(mdl) return {model = {Name = mdl, Brand = 'Test', Type = 'Car'}} end}
extensions.core_vehicle_configTarget = {getTargetVehicleId = function() return VID end, getTargetPlayerId = function() return 0 end}

local loads = 0
local function reload()
  veh.wantReload = false
  local cfg = {model = model, parts = deepcopy(vd.config.parts or pc.parts), vars = vd.config.vars, bcfp = deepcopy(vd.config.bcfp)}
  if vd.config.partsTree then cfg.partsTree = deepcopy(vd.config.partsTree) cfg.parts = nil end
  local ok, bundle = xpcall(function() return loader.loadJbeam(nil, nil, {'/vehicles/' .. model .. '/', '/vehicles/common/'}, cfg) end, debug.traceback)
  assert(ok and bundle, 'yukleme hatasi: ' .. tostring(bundle))
  vd = {config = bundle.config or cfg, vdata = bundle.vdata}
  if vd.config.bcfp == nil and cfg.bcfp ~= nil then vd.config.bcfp = cfg.bcfp end
  loads = loads + 1
  bcfpPro.onVehicleSpawned(VID)
end

local function lastState()
  for i = #EVENTS, 1, -1 do
    if EVENTS[i].name == 'BcfpProState' then return EVENTS[i].data end
  end
end
local function lastError()
  for i = #EVENTS, 1, -1 do
    if EVENTS[i].name == 'BcfpProError' then return EVENTS[i].data end
  end
end
local function tick(n) for _ = 1, n or 5 do bcfpPro.onUpdate(0.2) end end
local function ui(cmd, args)
  EVENTS = {}
  veh.cmds = {}
  bcfpPro.ui(cmd, args or {})
  local e = lastError()
  if e then print('   ARAYUZ HATASI ' .. cmd .. ': ' .. tostring(e.err)) end
  if veh.wantReload then reload() end
  tick(5)
  return lastState()
end
local function arrays(st)
  local out = {}
  for _, it in ipairs(st.cfg and st.cfg.items or {}) do if it.kind == 'array' then out[#out + 1] = it end end
  return out
end
local function findItem(st, anchor)
  for _, it in ipairs(st.cfg.items) do if it.anchor == anchor and it.kind == 'array' then return it end end
end
local function rtItem(st, id)
  for _, r in ipairs(st.runtime and st.runtime.items or {}) do if r.id == id then return r end end
end
local function hasCmd(pat)
  for _, c in ipairs(veh.cmds) do if c:find(pat, 1, true) then return true end end
  return false
end

-- ---------------------------------------------------------------- 1) ilk acilis: ayarsiz arac
reload()
local t0 = py_clock()
local st = ui('hello')
check(st and st.ok, 'durum paketi (ok)')
check(st.env and st.env.ready, 'ortam hazir (tarama)')
check(st.hasConfig == false, 'ayarsiz arac: hasConfig = false')
local zi = st.env.zones or {}
local navail, nfac = 0, 0
for id, z in pairs(zi) do
  if z.avail then navail = navail + 1 end
  if z.avail == 'factory' then nfac = nfac + 1 end
end
print(string.format('== %s/%s: ortam %.2fs, %d ucgen, bolgeler: %d uygun (%d fabrika)', model, pcn, py_clock() - t0, st.env.tris or 0, navail, nfac))
check(navail >= 8, 'en az 8 bolge uygun')
check(zi.custom and zi.custom.avail, 'serbest bolge her zaman uygun')
check(#st.enums.zones == 17 and #st.enums.heads == 6 and #st.enums.kits == 7 and #st.enums.schemes == 10, 'enum sayilari')
check(#st.enums.colors == 6 and #st.enums.colors[1].tones == 3, 'renk tonlari')
check(st.lang == 'en', 'varsayilan dil (oyun dili Turkce degil): en')
st = ui('setLang', {lang = 'tr'})
check(st.lang == 'tr' and WRITTEN['/settings/bcfp_pro/prefs.json'] and WRITTEN['/settings/bcfp_pro/prefs.json'].lang == 'tr', 'dil secimi kaydedildi')
ui('setLang', {lang = 'xx'})
st = ui('hello')
check(st.lang == 'tr', 'gecersiz dil yok sayildi')

-- ---------------------------------------------------------------- 2) hazir kit
st = ui('kit', {id = 'undercover', scheme = 'rb'})
local ar = arrays(st)
check(#ar >= 3, 'sivil ekip kiti: en az 3 dizi (' .. #ar .. ')')
check(st.runtime and #st.runtime.items >= #ar, 'calisma zamani ogeleri')
check(not st.pending, 'kit sonrasi bekleyen degisiklik yok')
for _, it in ipairs(ar) do
  local r = rtItem(st, it.id)
  check(r and r.src and r.src ~= 'none', it.anchor .. ': yerlesti (' .. tostring(r and r.src) .. ')')
  check(st.photo[it.id] and st.photo[it.id].cd > 0, it.anchor .. ': fotometri')
end
print('   kit: ' .. #ar .. ' dizi, yukleme ' .. loads)

st = ui('kit', {id = 'full', scheme = 'br', lightbar = true})
ar = arrays(st)
local nbar = 0
for _, it in ipairs(st.cfg.items) do if it.kind == 'mlbar' then nbar = nbar + 1 end end
check(#ar >= 6, 'tam donanim kiti: en az 6 dizi (' .. #ar .. ')')
check(nbar == 1, 'kit ile LED bar eklendi')
local ws = findItem(st, 'windshield')
check(ws and ws.colL == 2 and ws.colR == 1, 'mavi-kirmizi semasi uygulandi')
check(ws and ws.colB == 3 and ws.bfn == 1, 'on cam: beyaz takedown ikinci renk')
print('   tam kit: ' .. #ar .. ' dizi + ' .. nbar .. ' bar')
for _, w in ipairs(st.runtime.warnings or {}) do print('   UYARI: ' .. (type(w) == 'table' and (tostring(w.k) .. ': ' .. tostring(w.v)) or tostring(w))) end

-- ---------------------------------------------------------------- 3) bolge ac / kapat
local before = #ar
local hadHood = findItem(st, 'hood') ~= nil
st = ui('zoneToggle', {zone = 'hood'})
check((findItem(st, 'hood') ~= nil) == (not hadHood), 'kaput bolgesi ac / kapat')
st = ui('zoneToggle', {zone = 'hood'})
check((findItem(st, 'hood') ~= nil) == hadHood, 'kaput bolgesi geri')
st = ui('zoneToggle', {zone = 'custom'})
local cu = findItem(st, 'custom')
check(cu and cu.z > 50, 'serbest bolge tavanda baslar (z=' .. tostring(cu and cu.z) .. ')')
local rcu = cu and rtItem(st, cu.id)
check(rcu and rcu.heads and #rcu.heads == 2, 'serbest bolge: 2 baslik')

-- ---------------------------------------------------------------- 4) canli guncelleme (yeniden yukleme yok)
ws = findItem(st, 'windshield')
local l0 = loads
st = ui('updateItem', {id = ws.id, fields = {colL = 1, toneL = 2, colR = 2, toneR = 3}, apply = false})
check(loads == l0, 'renk / ton: yeniden yukleme yok')
check(not st.pending, 'renk / ton: bekleyen degisiklik yok')
check(hasCmd('bcfpLive.apply'), 'renk / ton: canli isik komutu')
check(hasCmd('bcfpSetZone'), 'renk / ton: canli desen komutu')
ws = findItem(st, 'windshield')
check(ws.colL == 1 and ws.toneL == 2 and ws.toneR == 3, 'renk / ton kaydedildi')
local gm = vd.vdata.glowMap and vd.vdata.glowMap[m.Un.matA(m.C.itemIndex(ws.id), 'L')]
check(gm and tostring(gm.on):find('redt2', 1, true), 'lens materyali tonu: ' .. tostring(gm and gm.on))

local cd0 = st.photo[ws.id].cd
st = ui('updateItem', {id = ws.id, fields = {bright = 4, light = {unit = 1, cd = -1}}, apply = false})
check(loads == l0 and not st.pending, 'parlaklik: canli')
check(st.photo[ws.id].cd > cd0 * 1.5, 'parlaklik: kandela artti (' .. cd0 .. ' -> ' .. st.photo[ws.id].cd .. ')')
st = ui('updateItem', {id = ws.id, fields = {light = {unit = 3, lux = 50, luxd = 10}}, apply = false})
check(loads == l0, 'luks birimi: canli')
check(math.abs(st.photo[ws.id].cd - 5000) < 1, 'luks -> kandela: 50 lx @ 10 m = 5000 cd (' .. st.photo[ws.id].cd .. ')')
st = ui('updateItem', {id = ws.id, fields = {pat = 3, grp = 2, side = 1, lvl = 60, phase = 25}, apply = false})
check(loads == l0 and hasCmd('bcfpSetZone'), 'desen alanlari: canli')

-- ---------------------------------------------------------------- 5) yapisal degisiklik (bekler, sonra uygulanir)
st = ui('updateItem', {id = ws.id, fields = {n = 5, head = 'std'}, apply = false})
check(loads == l0, 'adet / tip: hemen yuklenmez')
check(st.pending, 'adet / tip: bekleyen degisiklik')
st = ui('apply')
check(loads == l0 + 1 and not st.pending, 'uygula: bir kez yuklendi')
local rws = rtItem(st, ws.id)
check(rws and rws.heads and #rws.heads == 10, 'on cam: 5 x 2 baslik (' .. tostring(rws and rws.heads and #rws.heads) .. ')')

st = ui('updateItem', {id = ws.id, fields = {x = 3, z = -2, yaw = 5}, apply = false})
st = ui('apply')
st = ui('resetItem', {id = ws.id})
ws = findItem(st, 'windshield')
check(ws.x == 0 and ws.z == 0 and ws.yaw == 0 and ws.gap == -1, 'ince ayar sifirlandi')

st = ui('duplicateItem', {id = ws.id})
local nws = 0
for _, it in ipairs(arrays(st)) do if it.anchor == 'windshield' then nws = nws + 1 end end
check(nws == 2, 'on camda ikinci sira')

-- ---------------------------------------------------------------- 6) toplu islemler
st = ui('scheme', {id = 'aa'})
local allAmber = true
for _, it in ipairs(arrays(st)) do if it.kind2 ~= 'white' and (it.colL ~= 4 or it.colR ~= 4) then allAmber = false end end
check(allAmber, 'renk semasi: tumu amber')
st = ui('allArrays', {fields = {bright = 1, light = {unit = 1, cd = -1}}})
local allB = true
for _, it in ipairs(arrays(st)) do if it.bright ~= 1 or it.light.cd ~= -1 then allB = false end end
check(allB, 'tum dizilere parlaklik')
st = ui('masterSet', {fields = {speed = 150, night = 20}, apply = true})
check(st.cfg.master.speed == 150 and hasCmd('bcfpSetLive'), 'genel ayar: canli')
l0 = loads
st = ui('masterSet', {fields = {glow = 200}, apply = true})
check(loads == l0 + 1 and st.cfg.master.glow == 200, 'lens parlamasi: yeniden yukleme')
st = ui('studioSet', {key = '*', params = {imode = 1, imult = 150}, all = true})
check(st.cfg.studio['*'] and st.cfg.studio['*'].imult == 150, 'isik studyosu: tumu')
st = ui('studioReset', {})
check(next(st.cfg.studio) == nil, 'isik studyosu sifirlandi')
ui('ctrl', {cmd = 'lightbar', value = 1})
check(hasCmd('set_lightbar_signal(1)'), 'kontrol: cakar ac')
ui('ctrl', {cmd = 'mode', value = 12})
check(hasCmd('setModeIndex(12)'), 'kontrol: mod')
st = ui('hello')

-- ---------------------------------------------------------------- 7) profiller, otomatik
local nItems = #st.cfg.items
ui('profileSave', {name = 'deneme', global = false})
ui('profileSave', {name = 'genel1', global = true})
st = ui('kit', {id = 'clear'})
check(#arrays(st) == 0, 'temizle: dizi kalmadi')
st = ui('profileLoad', {name = 'deneme', global = false})
check(#st.cfg.items == nItems, 'profil yuklendi (' .. #st.cfg.items .. ' oge)')
check(#st.profiles == 1 and #st.globalProfiles == 1, 'profil listeleri')
st = ui('profileDelete', {name = 'deneme', global = false})
check(#st.profiles == 0, 'profil silindi')
st = ui('auto', {enabled = true, kit = 'front', scheme = 'bb', lightbar = false})
check(st.auto.enabled and st.auto.kit == 'front' and st.auto.scheme == 'bb', 'otomatik uygula ayari')

-- otomatik uygula: ayarsiz arac acilinca kit kendiliginden gelir
vd.config.bcfp = nil
reload()
do local tEnd = os.clock() + 0.7 while os.clock() < tEnd do end end   -- otomatik is 0.6 sn sonra calisir
for _ = 1, 40 do
  bcfpPro.onUpdate(0.2)
  if veh.wantReload then reload() break end
end
st = ui('hello')
check(#arrays(st) >= 2, 'otomatik uygula: on kit yerlesti (' .. #arrays(st) .. ' dizi)')
ui('auto', {enabled = false})

-- ---------------------------------------------------------------- 8) arayuz denemesi icin ornek durum
ui('clearAll')
st = ui('kit', {id = 'full', scheme = 'rb', lightbar = true})
st.status = {mode = 2, lightbar = 1, night = false, tkd = false, aly = false}
print(string.format('== SONUC %s: %d kontrol, %d basarisiz, %d yukleme', model, checks, fails, loads))
if ARGS and ARGS[2] then
  print('STATE_JSON_BEGIN')
  print(jsonEncode(st))
  print('STATE_JSON_END')
end
