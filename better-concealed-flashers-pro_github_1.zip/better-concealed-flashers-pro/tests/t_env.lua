local B = require('bench')
local m = B.mods()
local model = ARGS[1] or 'lansdale'
local pcn = ARGS[2]
if not pcn then
  local pcs = B.pcs(model)
  pcn = pcs[1]
end
local t0 = py_clock()
local ioCtx, cfg, r = B.find(model, pcn)
if not ioCtx then print('HATA', cfg) return end
print(string.format('%s/%s: findParts %.2fs, %d parca', model, pcn, py_clock() - t0, #r[2]))
t0 = py_clock()
local env, cached = m.E.forLoad(ioCtx, cfg, r)
print(string.format('env %.2fs (scan %.2fs) nodes=%s flex=%s tris=%s hintParts=%s', py_clock() - t0, env.stats.scan or -1, tostring(env.stats.nodes), tostring(env.stats.flex),
  tostring(env.stats.tris), tostring(env.stats.hintParts)))
for _, w in ipairs(env.warnings) do print('  UYARI: ' .. w) end
for _, p in ipairs(env.factory or {}) do print('  fabrika parcasi: ' .. p.name .. (p.active and ' [takili]' or '') .. ' -> ' .. table.concat(p.zones, ',')) end
local zones = {}
for z in pairs(env.hints or {}) do zones[#zones + 1] = z end
table.sort(zones)
for _, z in ipairs(zones) do
  local H = env.hints[z]
  local xs = {}
  for i, h in ipairs(H.heads) do xs[i] = string.format('%.3f', h.x) end
  local h1 = H.heads[1]
  print(string.format('  %-10s %s n=%d x={%s} y=%.3f z=%.3f yaw=%.0f tilt=%.0f pitch=%.3f head=%s dims=%.0fx%.0fx%.0f dev=%.3f grp=%s dg=%s alts=%d', z, H.part, H.n, table.concat(xs, ','),
    h1.y, h1.z, h1.yaw, h1.tilt, H.pitch, H.head, H.dims.w * 1000, H.dims.h * 1000, H.dims.d * 1000, H.dev, table.concat(H.groups or {}, '+'), tostring(H.dg), H.alts))
end
if env.roofBar then print(string.format('  tavan cubugu: %s y=%.3f z=%.3f len=%.2f', env.roofBar.part, env.roofBar.y, env.roofBar.z, env.roofBar.len)) end
