-- tum araclarda ortam + fabrika konumlari ozeti
local B = require('bench')
local m = B.mods()
QUIET = true
local models = {}
for i, a in ipairs(ARGS) do models[i] = a end
local function defaultPc(model)
  local info = jsonReadFile('/vehicles/' .. model .. '/info.json')
  local d = type(info) == 'table' and info.default_pc
  local pcs = B.pcs(model)
  if d then for _, p in ipairs(pcs) do if p == d then return p end end end
  return pcs[1]
end
for _, spec in ipairs(models) do
  local model, pcn = spec:match('^([^:]+):?(.*)$')
  if pcn == '' then pcn = defaultPc(model) end
  local ok, err = pcall(function()
    local t0 = py_clock()
    local ioCtx, cfg, r = B.find(model, pcn)
    if not ioCtx then print(model .. ': HATA ' .. tostring(cfg)) return end
    local tf = py_clock() - t0
    t0 = py_clock()
    local env = m.E.forLoad(ioCtx, cfg, r)
    local M = env.M
    print(string.format('== %s/%s: find %.1fs env %.2fs tris=%s nodes=%s glass F/R %s/%s gate=%s', model, tostring(pcn), tf, py_clock() - t0, tostring(env.stats.tris), tostring(env.stats.nodes),
      M and #M.glass.front or '-', M and #M.glass.rear or '-', M and tostring(M.glass.rearGate) or '-'))
    for _, r in ipairs(env.hintRejected or {}) do print(string.format('  REDDEDILDI %-10s %-34s dev=%.3f tol=%.2f', r.zone, r.part, r.dev, r.tol)) end
    for _, w in ipairs(env.warnings) do print('  UYARI: ' .. (type(w) == 'table' and (tostring(w.k) .. ': ' .. tostring(w.v)) or tostring(w))) end
    local zones = {}
    for z in pairs(env.hints or {}) do zones[#zones + 1] = z end
    table.sort(zones)
    for _, z in ipairs(zones) do
      local H = env.hints[z]
      local xs = {}
      for i, h in ipairs(H.heads) do xs[i] = string.format('%.2f', h.x) end
      local h1 = H.heads[1]
      print(string.format('  %-10s %-34s n=%d x={%s} y=%.3f z=%.3f yaw=%.0f tilt=%.0f %s dev=%.3f grp=%s dg=%s alts=%d', z, H.part, H.n, table.concat(xs, ','),
        h1.y, h1.z, h1.yaw, h1.tilt, H.head, H.dev, table.concat(H.groups or {}, '+'), tostring(H.dg), H.alts))
    end
    local used = {}
    for _, p in ipairs(env.factory or {}) do
      local any = false
      for _, z in ipairs(p.zones) do if env.hints[z] and env.hints[z].part == p.name then any = true end end
      if not any then used[#used + 1] = p.name .. '(' .. table.concat(p.zones, ',') .. ')' end
    end
    if #used > 0 then print('  kullanilmayan adaylar: ' .. table.concat(used, ' ')) end
    if env.roofBar then print(string.format('  tavan cubugu: %s y=%.3f z=%.3f len=%.2f depth=%.2f', env.roofBar.part, env.roofBar.y, env.roofBar.z, env.roofBar.len, env.roofBar.depth)) end
    m.E.invalidate()
  end)
  if not ok then print(model .. ': HATA ' .. tostring(err)) end
  collectgarbage()
end
