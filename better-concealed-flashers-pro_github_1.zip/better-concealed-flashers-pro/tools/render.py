#!/usr/bin/env python3
"""Yerlesim goruntuleyici: yuzey modeli (ucgenler) + cakar basliklari -> golgeli gorunumler ve kesitler (PNG)."""
import sys, os, math
import numpy as np
import cv2

CLS_COL = {1: (150, 150, 155), 2: (235, 200, 150), 3: (90, 140, 230), 4: (95, 90, 85), 5: (60, 60, 60), 6: (200, 200, 200)}
SRC_COL = {'factory': (60, 220, 60), 'scan': (0, 165, 255), 'approx': (60, 60, 255), 'dev': (255, 255, 0)}

def load(d):
    T = np.fromfile(os.path.join(d, 'tris.bin'), dtype=np.float32).reshape(-1, 3, 3)
    C = np.fromfile(os.path.join(d, 'cls.bin'), dtype=np.uint8)
    heads = []
    for l in open(os.path.join(d, 'heads.txt')):
        p = l.split()
        if len(p) >= 11:
            heads.append(dict(id=p[0], zone=p[1], src=p[2], pos=np.array([float(p[3]), float(p[4]), float(p[5])]), yaw=float(p[6]), tilt=float(p[7]),
                              w=float(p[8]), h=float(p[9]), d=float(p[10])))
    return T, C, heads

def rot(yaw, tilt):
    a, t = math.radians(yaw), math.radians(-tilt)
    cz, sz, cx, sx = math.cos(a), math.sin(a), math.cos(t), math.sin(t)
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    return Rz @ Rx

def box_tris(h):
    hw, hd, hh = h['w'] / 2, h['d'] / 2, h['h'] / 2
    c = np.array([[sx * hw, sy * hd, sz * hh] for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])
    c = c @ rot(h['yaw'], h['tilt']).T + h['pos']
    faces = [(0, 1, 3, 2), (4, 5, 7, 6), (0, 1, 5, 4), (2, 3, 7, 6), (0, 2, 6, 4), (1, 3, 7, 5)]
    tris = []
    for f in faces:
        tris.append(c[[f[0], f[1], f[2]]]); tris.append(c[[f[0], f[2], f[3]]])
    return np.array(tris)

def view(T, C, heads, R, out, size=1500, crop=None, glass=False, title=''):
    """R: 3x3 dunya->gorunum (x saga, y yukari, z izleyiciye)."""
    keep = np.ones(len(C), bool)
    if not glass: keep &= (C != 2)
    Tt = T[keep] @ R.T
    Cc = C[keep]
    n = np.cross(Tt[:, 1] - Tt[:, 0], Tt[:, 2] - Tt[:, 0])
    ln = np.linalg.norm(n, axis=1) + 1e-12
    shade = np.abs(n[:, 2]) / ln * 0.75 + 0.25
    cols = np.array([CLS_COL.get(int(c), (150, 150, 150)) for c in Cc], dtype=np.float32) * shade[:, None]
    depth = Tt[:, :, 2].mean(axis=1)
    hb = []
    hc = []
    hdp = []
    for h in heads:
        bt = box_tris(h) @ R.T
        nn = np.cross(bt[:, 1] - bt[:, 0], bt[:, 2] - bt[:, 0])
        sh = np.abs(nn[:, 2]) / (np.linalg.norm(nn, axis=1) + 1e-12) * 0.5 + 0.5
        col = np.array(SRC_COL.get(h['src'], (255, 0, 255)), dtype=np.float32)
        hb.append(bt); hc.append(col[None, :] * sh[:, None]); hdp.append(bt[:, :, 2].mean(axis=1) + 0.004)
    if hb:
        Tt = np.concatenate([Tt] + hb); cols = np.concatenate([cols] + hc); depth = np.concatenate([depth] + hdp)
    if crop is None:
        x0, x1 = Tt[:, :, 0].min(), Tt[:, :, 0].max(); y0, y1 = Tt[:, :, 1].min(), Tt[:, :, 1].max()
    else:
        x0, x1, y0, y1 = crop
        inside = (Tt[:, :, 0].max(axis=1) >= x0) & (Tt[:, :, 0].min(axis=1) <= x1) & (Tt[:, :, 1].max(axis=1) >= y0) & (Tt[:, :, 1].min(axis=1) <= y1)
        Tt, cols, depth = Tt[inside], cols[inside], depth[inside]
    s = size / max(x1 - x0, 1e-6)
    W, H = size, max(8, int((y1 - y0) * s))
    img = np.full((H, W, 3), 30, np.uint8)
    order = np.argsort(depth)
    P = np.empty((len(Tt), 3, 2), np.int32)
    P[:, :, 0] = np.round((Tt[:, :, 0] - x0) * s * 16)
    P[:, :, 1] = np.round((y1 - Tt[:, :, 1]) * s * 16)
    for i in order:
        cv2.fillConvexPoly(img, P[i], tuple(int(v) for v in cols[i]), lineType=cv2.LINE_AA, shift=4)
    if title: cv2.putText(img, title, (10, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.imwrite(out, img)

def section(T, C, heads, axis, value, center, half, out, size=900, title=''):
    """axis = 0 (x sabit: yatay eksen y, dikey z) ya da 2 (z sabit: yatay x, dikey y ters)."""
    a = T[:, :, axis] - value
    segs, cls = [], []
    others = [i for i in range(3) if i != axis]
    for e0, e1, e2 in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
        pass
    # ucgen-duzlem kesisimi
    s0, s1, s2 = a[:, 0], a[:, 1], a[:, 2]
    cross = ~(((s0 > 0) & (s1 > 0) & (s2 > 0)) | ((s0 < 0) & (s1 < 0) & (s2 < 0)))
    idx = np.nonzero(cross)[0]
    for i in idx:
        pts = []
        tri = T[i]; sv = a[i]
        for p, q in ((0, 1), (1, 2), (2, 0)):
            if (sv[p] <= 0) != (sv[q] <= 0):
                t = sv[p] / (sv[p] - sv[q])
                pts.append(tri[p] + t * (tri[q] - tri[p]))
        if len(pts) >= 2:
            segs.append((pts[0][others], pts[1][others])); cls.append(int(C[i]))
    img = np.full((size, size, 3), 24, np.uint8)
    cx, cy = center
    s = size / (2 * half)
    def px(u, v):
        if axis == 0: return int(round((u - cx + half) * s)), int(round((cy + half - v) * s))
        return int(round((u - cx + half) * s)), int(round((v - cy + half) * s))
    # 5 cm izgara
    g = 0.05
    k0 = math.floor((cx - half) / g); k1 = math.ceil((cx + half) / g)
    for k in range(k0, k1 + 1):
        x = px(k * g, cy)[0]; cv2.line(img, (x, 0), (x, size), (42, 42, 42), 1)
    k0 = math.floor((cy - half) / g); k1 = math.ceil((cy + half) / g)
    for k in range(k0, k1 + 1):
        y = px(cx, k * g)[1]; cv2.line(img, (0, y), (size, y), (42, 42, 42), 1)
    for (p, q), c in zip(segs, cls):
        col = CLS_COL.get(c, (150, 150, 150))
        cv2.line(img, px(*p), px(*q), col, 2, cv2.LINE_AA)
    for h in heads:
        if abs(h['pos'][axis] - value) > (h['w'] if axis == 0 else h['h']) * 0.6 + 0.002: continue
        hw, hd, hh = h['w'] / 2, h['d'] / 2, h['h'] / 2
        R = rot(h['yaw'], h['tilt'])
        if axis == 0:
            loc = [(0, -hd, -hh), (0, hd, -hh), (0, hd, hh), (0, -hd, hh)]
        else:
            loc = [(-hw, -hd, 0), (hw, -hd, 0), (hw, hd, 0), (-hw, hd, 0)]
        pts = [np.array(l) @ R.T + h['pos'] for l in loc]
        poly = np.array([px(*p[others]) for p in pts], np.int32)
        col = SRC_COL.get(h['src'], (255, 0, 255))
        cv2.polylines(img, [poly], True, col, 2, cv2.LINE_AA)
        # lens yuzu (on): kalin cizgi
        cv2.line(img, tuple(poly[0]), tuple(poly[3] if axis == 0 else poly[1]), col, 4, cv2.LINE_AA)
    if title: cv2.putText(img, title, (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.imwrite(out, img)

def main():
    d = sys.argv[1]
    mode = sys.argv[2] if len(sys.argv) > 2 else 'all'
    T, C, heads = load(d)
    mine = [h for h in heads if h['src'] != 'dev']
    # gorunum matrisleri: satirlar = gorunum eksenleri (dunya koordinatlarinda)
    def look(az, el):
        a, e = math.radians(az), math.radians(el)
        # izleyici yonu (aractan izleyiciye)
        vz = np.array([math.sin(a) * math.cos(e), -math.cos(a) * math.cos(e), math.sin(e)])
        up = np.array([0, 0, 1.0])
        vx = np.cross(up, vz); vx /= np.linalg.norm(vx)
        vy = np.cross(vz, vx)
        return np.array([vx, vy, vz])
    if mode in ('all', 'views'):
        view(T, C, mine, look(-30, 18), os.path.join(d, 'v_front34.png'), title='on sol 3/4')
        view(T, C, mine, look(-150, 18), os.path.join(d, 'v_rear34.png'), title='arka sol 3/4')
        view(T, C, mine, look(0, 0), os.path.join(d, 'v_front.png'), title='on')
        view(T, C, mine, look(180, 0), os.path.join(d, 'v_rear.png'), title='arka')
        view(T, C, mine, look(-90, 0), os.path.join(d, 'v_side.png'), title='sol yan')
        view(T, C, mine, look(0, 89.9), os.path.join(d, 'v_top.png'), title='ust')
    if mode == 'sheet':
        a, b = os.path.join(d, '_a.png'), os.path.join(d, '_b.png')
        view(T, C, mine, look(-32, 20), a, size=1000, title='')
        view(T, C, mine, look(-148, 20), b, size=1000, title='')
        ia, ib = cv2.imread(a), cv2.imread(b)
        h = max(ia.shape[0], ib.shape[0])
        pad = lambda im: np.vstack([im, np.full((h - im.shape[0], im.shape[1], 3), 30, np.uint8)]) if im.shape[0] < h else im
        sheet = np.hstack([pad(ia), pad(ib)])
        name = open(os.path.join(d, 'info.txt')).read().strip()
        cv2.putText(sheet, name, (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2, cv2.LINE_AA)
        cv2.imwrite(os.path.join(d, 'sheet.jpg'), sheet, [cv2.IMWRITE_JPEG_QUALITY, 88])
        os.remove(a); os.remove(b)
    if mode in ('all', 'sections'):
        seen = set()
        tiles = []
        for h in mine:
            if h['pos'][0] < -0.001: continue
            key = h['id']
            if key in seen: continue
            seen.add(key)
            p = h['pos']
            f1 = os.path.join(d, 's_%s_%s_x.png' % (h['id'], h['zone']))
            f2 = os.path.join(d, 's_%s_%s_z.png' % (h['id'], h['zone']))
            section(T, C, heads, 0, p[0], (p[1], p[2]), 0.22, f1, size=560, title='%s %s [%s] x=%.2f (y-z)' % (h['id'], h['zone'], h['src'], p[0]))
            section(T, C, heads, 2, p[2], (p[0], p[1]), 0.22, f2, size=560, title='%s z=%.2f (x-y, on = yukari)' % (h['zone'], p[2]))
            tiles.append((f1, f2))
        # tek sayfa
        if tiles:
            rows = []
            per = 4
            for i in range(0, len(tiles), per):
                chunk = tiles[i:i + per]
                top = [cv2.imread(a) for a, b in chunk]; bot = [cv2.imread(b) for a, b in chunk]
                while len(top) < per:
                    top.append(np.full_like(top[0], 24)); bot.append(np.full_like(bot[0], 24))
                rows.append(np.hstack(top)); rows.append(np.hstack(bot))
            for j in range(0, len(rows), 4):
                cv2.imwrite(os.path.join(d, 'sections_%d.png' % (j // 4 + 1)), np.vstack(rows[j:j + 4]))

if __name__ == '__main__':
    main()
