#!/usr/bin/env python3
"""Builds the installable mod: dist/better_concealed_flashers_pro.zip

Usage:  python3 tools/build.py [--out PATH]

The zip contains the contents of mod/ at its root (lua/, ui/, vehicles/, scripts/, mod_info/ ...),
which is the layout BeamNG.drive expects inside a mod zip. Drop the zip into
  %LOCALAPPDATA%/BeamNG/BeamNG.drive/current/mods/
"""
import argparse
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'mod')
SKIP_DIRS = {'__pycache__', '.git', '.idea', '.vscode'}
SKIP_FILES = {'.DS_Store', 'Thumbs.db', 'desktop.ini'}
STORE_EXT = {'.png', '.jpg', '.dds'}   # already compressed


def build(out):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if os.path.exists(out):
        os.remove(out)
    n = 0
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for root, dirs, files in os.walk(SRC):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
            for f in sorted(files):
                if f in SKIP_FILES or f.endswith('~'):
                    continue
                p = os.path.join(root, f)
                arc = os.path.relpath(p, SRC).replace(os.sep, '/')
                comp = zipfile.ZIP_STORED if os.path.splitext(f)[1].lower() in STORE_EXT else zipfile.ZIP_DEFLATED
                z.write(p, arc, compress_type=comp)
                n += 1
    return n


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--out', default=os.path.join(ROOT, 'dist', 'better_concealed_flashers_pro.zip'))
    a = ap.parse_args()
    count = build(a.out)
    print('%d files -> %s (%.2f MB)' % (count, a.out, os.path.getsize(a.out) / 1048576.0))
    sys.exit(0)
