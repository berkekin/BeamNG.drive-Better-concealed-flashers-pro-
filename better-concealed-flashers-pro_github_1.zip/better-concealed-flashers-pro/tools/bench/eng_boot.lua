-- oyun motoru ortami taklidi (yalnizca jbeam yukleyicisinin gerektirdikleri)
package.path = GAME .. "/lua/common/?.lua;" .. GAME .. "/lua/common/libs/?.lua;" .. GAME .. "/lua/common/libs/luasocket/?.lua;" .. GAME .. "/lua/ge/?.lua;" ..
  BUILD .. "/mod/lua/ge/extensions/?.lua;" .. BUILD .. "/tests/?.lua;" .. package.path
vmType = 'game'
local logLevels = {E = true, W = true}
LOGS = {}
function log(l, tag, msg)
  if logLevels[l] then
    local s = '[' .. tostring(l) .. '] ' .. tostring(tag) .. ': ' .. tostring(msg)
    LOGS[#LOGS + 1] = s
    if not QUIET then print(s) end
  end
end
function profilerPushEvent() end
function profilerPopEvent() end
FS = {}
function FS:findFiles(dir, pattern, depth, a, b)
  local s = py_find(dir, pattern or '*')
  local t = {}
  for l in (s or ''):gmatch('[^\n]+') do t[#t + 1] = l end
  return t
end
function FS:stat(f) local n = py_size(f) if n < 0 then return nil end return {filesize = n} end
function FS:fileExists(f) return py_size(f) >= 0 end
function FS:directoryExists(f) return py_exists(f) end
Engine = {Platform = {}}
function require_optional(name) local ok, m = pcall(require, name) if ok then return m end return nil end
extensions = extensions or {}
HOOKS = {}
if not extensions.hook then extensions.hook = function(name, ...)
  HOOKS[#HOOKS + 1] = name
  for _, ext in pairs(EXT or {}) do
    if type(ext[name]) == 'function' then ext[name](...) end
  end
end end
EXT = {}
do
  -- BeamNG'nin LuaJIT eklentisi: buf:peekdecode() (tuketmeden coz)
  local buffer = require('string.buffer')
  local mt = getmetatable(buffer.new())
  local idx = mt and mt.__index
  if type(idx) == 'table' and not idx.peekdecode then
    idx.peekdecode = function(self) return buffer.decode(self:tostring()) end
  end
end
local okM, errM = pcall(require, 'mathlib')
if not okM then print('mathlib: ' .. tostring(errM)) end
local okU, errU = pcall(require, 'utils')
if not okU then print('utils: ' .. tostring(errU)) end
do
  -- BeamNG'nin LuaJIT eklentisi buf:peekdecode() burada yok: jbeam/utils kodlayicilarini standart API ile degistir
  local buffer = require('string.buffer')
  local okJ, ju = pcall(require, 'jbeam/utils')
  if okJ and type(ju) == 'table' then
    ju.stringBufferEncode = function(data) return buffer.encode(data) end
    ju.stringBufferDecode = function(s) return buffer.decode(s) end
  else
    print('jbeam/utils: ' .. tostring(ju))
  end
end
-- dosya okuma: Python uzerinden (oyunun sanal dosya sistemi yerine cikarilmis kaynaklar)
function readFile(p) return py_read(p) end
local function conv(v)
  -- lupa tablolari zaten Lua tablosu
  return v
end
function jsonReadFile(p) return conv(py_json(p)) end
return true
