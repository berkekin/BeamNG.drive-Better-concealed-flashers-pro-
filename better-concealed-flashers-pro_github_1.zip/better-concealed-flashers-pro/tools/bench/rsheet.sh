#!/bin/bash
# kullanim: rsheet.sh model[:pc] [zones] [parts]
spec="$1"; name=$(echo "$spec" | tr ':/ ' '___')
d=/tmp/bcfp_r_$name
rm -rf $d
timeout 150 python3 eng.py build/tests/t_render.lua "$spec" $d "${2:--}" ${3:+"$3"} 2>&1 | grep -v "^   a\|^   m" | tail -3 | cut -c1-220
timeout 60 python3 render.py $d sheet && mkdir -p $HOME/mnt/current/temp/bcfp_dev/render && cp $d/sheet.jpg $HOME/mnt/current/temp/bcfp_dev/render/sheet_$name.jpg && echo "sheet_$name.jpg"
