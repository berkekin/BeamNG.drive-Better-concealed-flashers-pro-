#!/usr/bin/env python3
# Oyunun jbeam yukleyicisini (lua/common/jbeam) oyun disinda, LuaJIT (lupa) icinde calistiran test tezgahi.
import sys, os, json, time, re, glob, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sjson
from lupa import luajit21
W = os.environ.get('BCFP_BENCH', os.path.dirname(os.path.abspath(__file__)))
GAME = os.environ.get('BEAMNG_GAME', os.path.expanduser('~/mnt/BeamNG.drive'))
REF = os.path.join(W, 'ref')
BUILD = os.environ.get('BCFP_BUILD', os.path.dirname(os.path.dirname(W)))

def refresh_build():
    # BUILD = repository root (mod/ and tests/) unless a dev zip is given in BCFP_BUILD_ZIP
    src = os.environ.get('BCFP_BUILD_ZIP', '')
    if src and os.path.exists(src):
        os.makedirs(BUILD, exist_ok=True)
        z = zipfile.ZipFile(src); z.extractall(BUILD); z.close()

def ensure_model(model):
    d = os.path.join(REF, 'vehicles', model)
    if glob.glob(d + '/**/*.dae', recursive=True) or glob.glob(d + '/**/*.DAE', recursive=True): return
    zp = os.path.join(GAME, 'content/vehicles', model + '.zip')
    if os.path.exists(zp):
        z = zipfile.ZipFile(zp)
        for i in z.infolist():
            if i.filename.lower().endswith('.dae'): z.extract(i, REF)

def vfs(p):
    if isinstance(p, bytes): p = p.decode('utf-8', 'replace')
    q = p.lstrip('/')
    if q.startswith('lua/'): return os.path.join(GAME, q)
    return os.path.join(REF, q)

class Bench:
    def __init__(self):
        self.L = luajit21.LuaRuntime(unpack_returned_tuples=True, encoding=None)
        L = self.L
        g = L.globals()
        g[b'py_read'] = self.py_read
        g[b'py_find'] = self.py_find
        g[b'py_size'] = self.py_size
        g[b'py_json'] = self.py_json
        g[b'py_clock'] = time.time
        g[b'py_exists'] = lambda p: os.path.exists(vfs(p))
        g[b'GAME'] = GAME.encode()
        g[b'BUILD'] = BUILD.encode()
        L.execute(open(os.path.join(W, 'eng_boot.lua'), 'rb').read())

    def to_lua(self, v):
        L = self.L
        if isinstance(v, dict):
            t = L.table()
            for k, x in v.items(): t[k.encode() if isinstance(k, str) else k] = self.to_lua(x)
            return t
        if isinstance(v, list):
            t = L.table()
            for i, x in enumerate(v): t[i + 1] = self.to_lua(x)
            return t
        if isinstance(v, str): return v.encode()
        return v

    def py_read(self, path):
        try:
            with open(vfs(path), 'rb') as f: return f.read()
        except OSError:
            return None

    def py_size(self, path):
        try: return os.path.getsize(vfs(path))
        except OSError: return -1

    def py_find(self, d, pattern):
        p = d.decode() if isinstance(d, bytes) else d
        pat = pattern.decode() if isinstance(pattern, bytes) else pattern
        exts = [x.strip().lower().lstrip('*') for x in pat.split('\t') if x.strip()]
        m = re.match(r'^/?vehicles/([^/]+)/?', p)
        if m and any(e.endswith('.dae') for e in exts): ensure_model(m.group(1))
        base = vfs(p)
        out = []
        for root, dirs, files in os.walk(base):
            for f in files:
                fl = f.lower()
                if any(fl.endswith(e) for e in exts):
                    full = os.path.join(root, f)
                    out.append(('/' + os.path.relpath(full, REF)).replace(os.sep, '/').encode())
        return b'\n'.join(sorted(out))

    def py_json(self, path):
        try:
            s = open(vfs(path), encoding='utf-8', errors='replace').read()
        except OSError:
            return None
        try:
            return self.to_lua(sjson.loads(s))
        except Exception as e:
            print('JSON ERR', path, e)
            return None

if __name__ == '__main__':
    refresh_build()
    b = Bench()
    L = b.L
    g = L.globals()
    g[b'ARGS'] = b.to_lua(sys.argv[2:])
    script = sys.argv[1]
    src = open(script, 'rb').read() if os.path.exists(script) else script.encode()
    L.execute(src)
