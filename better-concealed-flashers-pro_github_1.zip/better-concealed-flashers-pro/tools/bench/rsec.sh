#!/bin/bash
# kullanim: rsec.sh model[:pc] zones  -> kesit sayfalari
spec="$1"; name=$(echo "$spec" | tr ':/ ' '___')
d=/tmp/bcfp_s_$name
rm -rf $d
timeout 150 python3 eng.py build/tests/t_render.lua "$spec" $d "${2:--}" ${3:+"$3"} 2>&1 | grep "^   a" | sort -u | cut -c1-230
timeout 60 python3 render.py $d sections && mkdir -p $HOME/mnt/current/temp/bcfp_dev/render && for f in $d/sections_*.png; do b=$(basename $f .png); python3 -c "
import cv2,sys
im=cv2.imread('$f'); cv2.imwrite('$HOME/mnt/current/temp/bcfp_dev/render/sec_${name}_'+'$b'.split('_')[1]+'.jpg', im, [cv2.IMWRITE_JPEG_QUALITY, 85])"; done; ls $HOME/mnt/current/temp/bcfp_dev/render/ | grep "sec_${name}"
