# Lenient jbeam / sjson parser (comments, missing or trailing commas, unquoted nothing)
import re
_ws = re.compile(r'(?:\s+|//[^\n]*|/\*.*?\*/|,)+', re.S)
_num = re.compile(r'[-+]?(?:\d+\.?\d*(?:[eE][-+]?\d+)?|\.\d+(?:[eE][-+]?\d+)?)')
_str = re.compile(r'"((?:[^"\\]|\\.)*)"', re.S)
_word = re.compile(r'[A-Za-z_][A-Za-z0-9_]*')
_esc = re.compile(r'\\(u[0-9a-fA-F]{4}|.)', re.S)
_map = {'n': '\n', 't': '\t', 'r': '\r', 'b': '\b', 'f': '\f'}
def _unesc(t):
    if '\\' not in t: return t
    def rep(m):
        c = m.group(1)
        if c[0] == 'u' and len(c) == 5: return chr(int(c[1:], 16))
        return _map.get(c, c)
    return _esc.sub(rep, t)
def loads(s):
    i = 0
    n = len(s)
    def skip(i):
        m = _ws.match(s, i)
        return m.end() if m else i
    def val(i):
        i = skip(i)
        if i >= n: raise ValueError('eof')
        c = s[i]
        if c == '{':
            d = {}
            i = skip(i + 1)
            while i < n and s[i] != '}':
                m = _str.match(s, i)
                if not m:
                    m2 = _word.match(s, i)
                    if not m2: raise ValueError('key at %d: %r' % (i, s[i:i+40]))
                    k = m2.group(0); i = m2.end()
                else:
                    k = _unesc(m.group(1)); i = m.end()
                i = skip(i)
                if i < n and s[i] in ':=': i += 1
                v, i = val(i)
                d[k] = v
                i = skip(i)
            return d, i + 1
        if c == '[':
            a = []
            i = skip(i + 1)
            while i < n and s[i] != ']':
                v, i = val(i)
                a.append(v)
                i = skip(i)
            return a, i + 1
        if c == '"':
            m = _str.match(s, i)
            if not m: raise ValueError('str at %d' % i)
            return _unesc(m.group(1)), m.end()
        m = _num.match(s, i)
        if m and m.end() > i:
            t = m.group(0)
            try: return (int(t) if re.fullmatch(r'-?\d+', t) else float(t)), m.end()
            except ValueError: return float(t), m.end()
        m = _word.match(s, i)
        if m:
            w = m.group(0)
            return {'true': True, 'false': False, 'null': None}.get(w, w), m.end()
        raise ValueError('unexpected %r at %d' % (s[i:i+30], i))
    v, i = val(0)
    return v
def load(path):
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        return loads(f.read())
