#!/usr/bin/env python3
"""BCFP PRO 3 - cakar basligi modelleri, dokulari ve materyalleri uretir.

  bcfp_heads.dae           : 6 baslik tipi x 24 dizi x (L, R) -> govde + lens (A kanali) ve ikinci renk lensi (B kanali)
  bcfp_cell.color.png      : LED optik hucreleri (8 x 2)
  bcfp_cell_glow.data.png  : parlama (emissive) maskesi
  main.materials.json      : lens anahtar materyalleri, renk / ton / seviye merdiveni
"""
import json, math, os, sys, datetime
from PIL import Image, ImageDraw, ImageFilter

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'mod', 'vehicles', 'common', 'bcfp_pro')
MAXU = 24
TEX = '/vehicles/common/bcfp_pro/'

TYPES = [
    # id, w, h, d, cols, rows, round
    ('std', 0.0652, 0.0406, 0.0170, 4, 2, False),
    ('slim', 0.0652, 0.0203, 0.0170, 4, 1, False),
    ('wide', 0.0848, 0.0447, 0.0221, 6, 2, False),
    ('mini', 0.0456, 0.0203, 0.0119, 3, 1, False),
    ('lin', 0.1100, 0.0240, 0.0140, 6, 1, False),
    ('round', 0.0340, 0.0340, 0.0180, 2, 2, True),
]

# renk -> tonlar: (ad, dogrusal RGB)
COLORS = {
    'red':    [('Kırmızı 625 nm', (1.0, 0.0, 0.015)), ('Turuncu-kırmızı 615 nm', (1.0, 0.045, 0.0)), ('Gül kırmızısı', (1.0, 0.0, 0.09))],
    'blue':   [('Polis mavisi 470 nm', (0.0, 0.0747, 1.0)), ('Derin mavi 455 nm', (0.035, 0.0, 1.0)), ('Buz mavisi 480 nm', (0.0, 0.19, 1.0))],
    'white':  [('Beyaz 6000 K', (1.0, 0.901, 0.8766)), ('Nötr beyaz 5000 K', (1.0, 0.7973, 0.6303)), ('Sıcak beyaz 4000 K', (1.0, 0.6605, 0.3791))],
    'amber':  [('Amber 590 nm', (1.0, 0.2305, 0.0)), ('Sarı 585 nm', (1.0, 0.3159, 0.0)), ('Turuncu 600 nm', (1.0, 0.085, 0.0))],
    'green':  [('Yeşil 505 nm', (0.0, 1.0, 0.25)), ('Saf yeşil 525 nm', (0.0, 1.0, 0.04)), ('Limon yeşili 555 nm', (0.16, 1.0, 0.0))],
    'purple': [('Mor', (0.55, 0.0, 1.0)), ('Macenta', (1.0, 0.0, 0.75)), ('Menekşe', (0.2, 0.0, 1.0))],
}
LEVELS = 7      # 4 = 200000 nit


# ----------------------------------------------------------------------------------------- geometri
def sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def normalize(a):
    l = math.sqrt(dot(a, a)) or 1.0
    return (a[0] / l, a[1] / l, a[2] / l)


class Mesh:
    def __init__(self):
        self.groups = {}        # materyal -> [(pos, normal, uv) x 3, ...]

    def tri(self, mat, a, b, c, n, ua=(0, 0), ub=(0, 0), uc=(0, 0)):
        n = normalize(n)
        if dot(cross(sub(b, a), sub(c, a)), n) < 0:
            b, c, ub, uc = c, b, uc, ub
        self.groups.setdefault(mat, []).append(((a, n, ua), (b, n, ub), (c, n, uc)))

    def quad(self, mat, a, b, c, d, n, ua=(0, 0), ub=(0, 0), uc=(0, 0), ud=(0, 0)):
        self.tri(mat, a, b, c, n, ua, ub, uc)
        self.tri(mat, a, c, d, n, ua, uc, ud)

    def count(self):
        return sum(len(v) for v in self.groups.values())


def lens_y(d):
    return -d / 2 + 0.0010


def build_head(t, lens_mat, housing_mat='bcfp_led_housing'):
    tid, w, h, d, cols, rows, rnd = t
    m = Mesh()
    hw, hh, hd = w / 2, h / 2, d / 2
    yf, yb = -hd, hd
    yl = lens_y(d)
    if not rnd:
        bz = max(0.0018, min(0.0030, 0.07 * h))
        iw, ih = hw - bz, hh - bz
        H = housing_mat
        # arka, ust, alt, sol, sag
        m.quad(H, (-hw, yb, -hh), (hw, yb, -hh), (hw, yb, hh), (-hw, yb, hh), (0, 1, 0))
        m.quad(H, (-hw, yf, hh), (hw, yf, hh), (hw, yb, hh), (-hw, yb, hh), (0, 0, 1))
        m.quad(H, (-hw, yf, -hh), (hw, yf, -hh), (hw, yb, -hh), (-hw, yb, -hh), (0, 0, -1))
        m.quad(H, (hw, yf, -hh), (hw, yb, -hh), (hw, yb, hh), (hw, yf, hh), (1, 0, 0))
        m.quad(H, (-hw, yf, -hh), (-hw, yb, -hh), (-hw, yb, hh), (-hw, yf, hh), (-1, 0, 0))
        # on cerceve
        m.quad(H, (-hw, yf, hh), (hw, yf, hh), (iw, yf, ih), (-iw, yf, ih), (0, -1, 0))
        m.quad(H, (-hw, yf, -hh), (hw, yf, -hh), (iw, yf, -ih), (-iw, yf, -ih), (0, -1, 0))
        m.quad(H, (-hw, yf, -hh), (-hw, yf, hh), (-iw, yf, ih), (-iw, yf, -ih), (0, -1, 0))
        m.quad(H, (hw, yf, -hh), (hw, yf, hh), (iw, yf, ih), (iw, yf, -ih), (0, -1, 0))
        # ic duvarlar (lens yuvasi)
        m.quad(H, (-iw, yf, ih), (iw, yf, ih), (iw, yl, ih), (-iw, yl, ih), (0, 0, -1))
        m.quad(H, (-iw, yf, -ih), (iw, yf, -ih), (iw, yl, -ih), (-iw, yl, -ih), (0, 0, 1))
        m.quad(H, (-iw, yf, -ih), (-iw, yf, ih), (-iw, yl, ih), (-iw, yl, -ih), (1, 0, 0))
        m.quad(H, (iw, yf, -ih), (iw, yf, ih), (iw, yl, ih), (iw, yl, -ih), (-1, 0, 0))
        add_lens(m, t, lens_mat, yl)
    else:
        r = hw
        ri = r - 0.0026
        seg = 20
        H = housing_mat
        pts = [(math.cos(2 * math.pi * i / seg), math.sin(2 * math.pi * i / seg)) for i in range(seg)]
        for i in range(seg):
            c0, s0 = pts[i]
            c1, s1 = pts[(i + 1) % seg]
            # yan yuzey
            n = (c0 + c1, 0, s0 + s1)
            m.quad(H, (r * c0, yf, r * s0), (r * c1, yf, r * s1), (r * c1, yb, r * s1), (r * c0, yb, r * s0), n)
            # arka
            m.tri(H, (0, yb, 0), (r * c0, yb, r * s0), (r * c1, yb, r * s1), (0, 1, 0))
            # on halka
            m.quad(H, (r * c0, yf, r * s0), (r * c1, yf, r * s1), (ri * c1, yf, ri * s1), (ri * c0, yf, ri * s0), (0, -1, 0))
            # ic duvar
            n2 = (-(c0 + c1), 0, -(s0 + s1))
            m.quad(H, (ri * c0, yf, ri * s0), (ri * c1, yf, ri * s1), (ri * c1, yl, ri * s1), (ri * c0, yl, ri * s0), n2)
        add_lens(m, t, lens_mat, yl)
    return m


def add_lens(m, t, mat, y):
    tid, w, h, d, cols, rows, rnd = t
    hw, hh = w / 2, h / 2
    u1, v1 = cols / 8.0, rows / 2.0
    if not rnd:
        bz = max(0.0018, min(0.0030, 0.07 * h))
        iw, ih = hw - bz, hh - bz
        m.quad(mat, (-iw, y, -ih), (iw, y, -ih), (iw, y, ih), (-iw, y, ih), (0, -1, 0), (0, 0), (u1, 0), (u1, v1), (0, v1))
    else:
        ri = hw - 0.0026
        seg = 20
        for i in range(seg):
            a0, a1 = 2 * math.pi * i / seg, 2 * math.pi * (i + 1) / seg
            c0, s0, c1, s1 = math.cos(a0), math.sin(a0), math.cos(a1), math.sin(a1)
            uv = lambda c, s: ((0.5 + 0.5 * c) * u1, (0.5 + 0.5 * s) * v1)
            m.tri(mat, (0, y, 0), (ri * c0, y, ri * s0), (ri * c1, y, ri * s1), (0, -1, 0), (0.5 * u1, 0.5 * v1), uv(c0, s0), uv(c1, s1))


def build_overlay(t, mat):
    m = Mesh()
    add_lens(m, t, mat, lens_y(t[3]) - 0.0005)
    return m


def fmt(v):
    s = ('%.5f' % v).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


def write_dae(path, meshes, materials):
    now = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')
    o = []
    o.append('<?xml version="1.0" encoding="utf-8"?>')
    o.append('<COLLADA xmlns="http://www.collada.org/2005/11/COLLADASchema" version="1.4.1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">')
    o.append('  <asset>\n    <contributor><author>BCFP PRO</author><authoring_tool>BCFP PRO mesh generator</authoring_tool></contributor>')
    o.append('    <created>%s</created>\n    <modified>%s</modified>\n    <unit name="meter" meter="1"/>\n    <up_axis>Z_UP</up_axis>\n  </asset>' % (now, now))
    o.append('  <library_effects>')
    for mat in materials:
        o.append('    <effect id="%s-effect">\n      <profile_COMMON><technique sid="common"><lambert>\n        <emission><color sid="emission">0 0 0 1</color></emission>\n'
                 '        <diffuse><color sid="diffuse">0.8 0.8 0.8 1</color></diffuse>\n      </lambert></technique></profile_COMMON>\n    </effect>' % mat)
    o.append('  </library_effects>')
    o.append('  <library_materials>')
    for mat in materials:
        o.append('    <material id="%s-material" name="%s"><instance_effect url="#%s-effect"/></material>' % (mat, mat, mat))
    o.append('  </library_materials>')
    o.append('  <library_geometries>')
    for name, m in meshes:
        pos, nor, uvs = [], [], []
        prim = []
        idx = 0
        for mat, tris in m.groups.items():
            p = []
            for tri in tris:
                for (pp, nn, uu) in tri:
                    pos.extend(pp); nor.extend(nn); uvs.extend(uu)
                    p.append('%d %d %d' % (idx, idx, idx))
                    idx += 1
            prim.append((mat, len(tris), ' '.join(p)))
        o.append('    <geometry id="%s-mesh" name="%s">\n      <mesh>' % (name, name))
        o.append('        <source id="%s-mesh-positions"><float_array id="%s-mesh-positions-array" count="%d">%s</float_array>' % (name, name, len(pos), ' '.join(fmt(v) for v in pos)))
        o.append('          <technique_common><accessor source="#%s-mesh-positions-array" count="%d" stride="3"><param name="X" type="float"/><param name="Y" type="float"/><param name="Z" type="float"/></accessor></technique_common></source>' % (name, len(pos) // 3))
        o.append('        <source id="%s-mesh-normals"><float_array id="%s-mesh-normals-array" count="%d">%s</float_array>' % (name, name, len(nor), ' '.join(fmt(v) for v in nor)))
        o.append('          <technique_common><accessor source="#%s-mesh-normals-array" count="%d" stride="3"><param name="X" type="float"/><param name="Y" type="float"/><param name="Z" type="float"/></accessor></technique_common></source>' % (name, len(nor) // 3))
        o.append('        <source id="%s-mesh-map-0"><float_array id="%s-mesh-map-0-array" count="%d">%s</float_array>' % (name, name, len(uvs), ' '.join(fmt(v) for v in uvs)))
        o.append('          <technique_common><accessor source="#%s-mesh-map-0-array" count="%d" stride="2"><param name="S" type="float"/><param name="T" type="float"/></accessor></technique_common></source>' % (name, len(uvs) // 2))
        o.append('        <vertices id="%s-mesh-vertices"><input semantic="POSITION" source="#%s-mesh-positions"/></vertices>' % (name, name))
        for mat, cnt, p in prim:
            o.append('        <triangles material="%s-material" count="%d">' % (mat, cnt))
            o.append('          <input semantic="VERTEX" source="#%s-mesh-vertices" offset="0"/>' % name)
            o.append('          <input semantic="NORMAL" source="#%s-mesh-normals" offset="1"/>' % name)
            o.append('          <input semantic="TEXCOORD" source="#%s-mesh-map-0" offset="2" set="0"/>' % name)
            o.append('          <p>%s</p>' % p)
            o.append('        </triangles>')
        o.append('      </mesh>\n    </geometry>')
    o.append('  </library_geometries>')
    o.append('  <library_visual_scenes>\n    <visual_scene id="Scene" name="Scene">')
    for name, m in meshes:
        o.append('      <node id="%s" name="%s" type="NODE">' % (name, name))
        o.append('        <matrix sid="transform">1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1</matrix>')
        o.append('        <instance_geometry url="#%s-mesh" name="%s">' % (name, name))
        o.append('          <bind_material><technique_common>')
        for mat in m.groups.keys():
            o.append('            <instance_material symbol="%s-material" target="#%s-material"><bind_vertex_input semantic="UVMap" input_semantic="TEXCOORD" input_set="0"/></instance_material>' % (mat, mat))
        o.append('          </technique_common></bind_material>')
        o.append('        </instance_geometry>\n      </node>')
    o.append('    </visual_scene>\n  </library_visual_scenes>')
    o.append('  <scene><instance_visual_scene url="#Scene"/></scene>\n</COLLADA>')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(o) + '\n')


# ----------------------------------------------------------------------------------------- dokular
def make_textures():
    C = 64
    W, Hh = C * 8, C * 2
    S = 4                                   # ust ornekleme
    col = Image.new('RGB', (W * S, Hh * S), (16, 16, 18))
    glow = Image.new('L', (W * S, Hh * S), 18)
    dc, dg = ImageDraw.Draw(col), ImageDraw.Draw(glow)
    for cy in range(2):
        for cx in range(8):
            x0, y0 = cx * C * S, cy * C * S
            cs = C * S
            pad = int(0.055 * cs)
            # yansitici kap: kenardan merkeze acilan gri
            steps = 26
            for i in range(steps):
                t = i / (steps - 1)
                ins = pad + int(t * (cs / 2 - pad) * 0.86)
                g = int(58 + 120 * (t ** 0.8))
                dc.rounded_rectangle([x0 + ins, y0 + ins, x0 + cs - ins, y0 + cs - ins], radius=max(2, int(0.12 * cs * (1 - t) + 2)), fill=(g, g, int(g * 1.03)))
            # optik halkalari
            for rr, gg in ((0.40, 150), (0.30, 172), (0.20, 196)):
                r = int(rr * cs)
                cxp, cyp = x0 + cs // 2, y0 + cs // 2
                dc.ellipse([cxp - r, cyp - r, cxp + r, cyp + r], outline=(gg, gg, gg + 4), width=max(1, cs // 90))
            # LED cipi
            e = int(0.075 * cs)
            cxp, cyp = x0 + cs // 2, y0 + cs // 2
            dc.rounded_rectangle([cxp - e, cyp - e, cxp + e, cyp + e], radius=e // 3, fill=(232, 222, 150))
            # parlama maskesi: kabin tamami + parlak cekirdek
            dg.rounded_rectangle([x0 + pad, y0 + pad, x0 + cs - pad, y0 + cs - pad], radius=int(0.12 * cs), fill=120)
            for i in range(30):
                t = i / 29.0
                r = int((0.44 - 0.40 * t) * cs)
                v = int(120 + 135 * (t ** 1.6))
                dg.ellipse([cxp - r, cyp - r, cxp + r, cyp + r], fill=v)
    col = col.resize((W, Hh), Image.LANCZOS)
    glow = glow.filter(ImageFilter.GaussianBlur(S * 1.2)).resize((W, Hh), Image.LANCZOS)
    col.save(os.path.join(OUT, 'bcfp_cell.color.png'), optimize=True)
    Image.merge('RGB', (glow, glow, glow)).save(os.path.join(OUT, 'bcfp_cell_glow.data.png'), optimize=True)


# ----------------------------------------------------------------------------------------- materyaller
def base(name, stage, extra=None):
    d = {'name': name, 'mapTo': name, 'class': 'Material', 'Stages': [stage, {}, {}, {}], 'dynamicCubemap': True, 'version': 1.5,
         'materialTag0': 'beamng', 'materialTag1': 'vehicle'}
    if extra: d.update(extra)
    return d


INVIS = {'translucent': True, 'translucentBlendOp': 'PreMulAlpha', 'castShadows': False, 'alphaTest': True, 'alphaRef': 255}


def make_materials():
    path = os.path.join(OUT, 'main.materials.json')
    old = json.load(open(path, encoding='utf-8'))
    out = {}
    # cubuk (multicolor bar) ve genel materyaller aynen kalir
    for k, v in old.items():
        if k.startswith('bcfp_ml') or k in ('bcfp_invis', 'bcfp_led_housing'):
            out[k] = v
    cell, glow = TEX + 'bcfp_cell.color.png', TEX + 'bcfp_cell_glow.data.png'
    white = TEX + 'bcfp_white.color.png'
    out['bcfp_led_housing'] = base('bcfp_led_housing', {'baseColorMap': white, 'baseColorFactor': [0.022, 0.022, 0.025, 1], 'metallicFactor': 0.05, 'roughnessFactor': 0.42})
    out['bcfp_led_broken'] = base('bcfp_led_broken', {'baseColorMap': cell, 'baseColorFactor': [0.10, 0.10, 0.10, 1], 'metallicFactor': 0.2, 'roughnessFactor': 0.9})
    out['bcfp_led_off_clear'] = base('bcfp_led_off_clear', {'baseColorMap': cell, 'baseColorFactor': [0.82, 0.82, 0.85, 1], 'metallicFactor': 0.55, 'roughnessFactor': 0.14})
    tint = {'red': [0.45, 0.03, 0.04], 'blue': [0.03, 0.08, 0.5], 'white': [0.82, 0.82, 0.85], 'amber': [0.5, 0.2, 0.02], 'green': [0.03, 0.42, 0.12], 'purple': [0.3, 0.03, 0.5]}
    for cid, tones in COLORS.items():
        out['bcfp_led_off_' + cid] = base('bcfp_led_off_' + cid, {'baseColorMap': cell, 'baseColorFactor': tint[cid] + [1], 'metallicFactor': 0.4, 'roughnessFactor': 0.15})
        for ti, (tname, lin) in enumerate(tones, 1):
            key = cid if ti == 1 else '%st%d' % (cid, ti)
            bc = [round(0.03 + 0.5 * c, 4) for c in lin] + [1]
            for L in range(1, LEVELS + 1):
                nits = int(200000 * 2 ** (L - 4))
                n = 'bcfp_on_%s_%d' % (key, L)
                out[n] = base(n, {'baseColorMap': cell, 'baseColorFactor': bc, 'emissive': True, 'emissiveFactor': list(lin), 'emissiveIntensityNits': nits,
                                  'emissiveMap': glow, 'metallicFactor': 0.0, 'roughnessFactor': 0.25})
    # lens anahtarlari: A kanali (sonuk lens), B kanali (gorunmez)
    for n in range(1, MAXU + 1):
        for s in 'LR':
            k = 'bcfp_k_u%d_%s' % (n, s)
            out[k] = base(k, {'baseColorMap': cell, 'baseColorFactor': [0.82, 0.82, 0.85, 1], 'metallicFactor': 0.55, 'roughnessFactor': 0.14})
            k2 = k + '2'
            out[k2] = base(k2, {'baseColorMap': white, 'opacityFactor': 0.0}, INVIS)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=1, ensure_ascii=False)
    return out


def main():
    meshes, mats = [], ['bcfp_led_housing']
    for n in range(1, MAXU + 1):
        for s in 'LR':
            mats.append('bcfp_k_u%d_%s' % (n, s))
            mats.append('bcfp_k_u%d_%s2' % (n, s))
    for t in TYPES:
        for n in range(1, MAXU + 1):
            for s in 'LR':
                meshes.append(('bcfp_hd_%s_%d_%s' % (t[0], n, s), build_head(t, 'bcfp_k_u%d_%s' % (n, s))))
                meshes.append(('bcfp_hb_%s_%d_%s' % (t[0], n, s), build_overlay(t, 'bcfp_k_u%d_%s2' % (n, s))))
    write_dae(os.path.join(OUT, 'bcfp_heads.dae'), meshes, mats)
    make_textures()
    m = make_materials()
    print('meshes', len(meshes), 'tris/head', {t[0]: build_head(t, 'x').count() for t in TYPES}, 'materials', len(m),
          'dae MB', round(os.path.getsize(os.path.join(OUT, 'bcfp_heads.dae')) / 1e6, 2))


if __name__ == '__main__':
    main()
