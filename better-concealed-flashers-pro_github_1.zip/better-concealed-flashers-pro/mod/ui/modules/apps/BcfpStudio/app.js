"use strict";
// Better Concealed Flashers PRO 3 — "Concealed Flashers PRO / Gizli Çakar PRO" UI app (English + Türkçe)
//
// Protocol (lua/ge/extensions/bcfpPro.lua -> bcfp/ui.lua):
//   UI -> game : bcfpPro.ui("<command>", {...})
//   game -> UI : BcfpProState (vehicle + settings + zones), BcfpProStatus (mode / levels, from the vehicle),
//                BcfpProLibrary (lightbar library), BcfpProScan (scan progress), BcfpProError
// Speed: colour / tone / brightness / pattern edits are applied live without reloading the vehicle. Position, count
// and head-type edits first show ghost boxes; the vehicle is reloaded once after a short pause.
// The game sends ids only; every visible text lives in the L10N dictionaries below.
(function () {
  const APP_PATH = "/ui/modules/apps/BcfpStudio/";

  // ------------------------------------------------------------------------------------------- texts
  const L10N = {
    tr: {
      appTitle: "GİZLİ ÇAKAR PRO", vehWait: "Araç bekleniyor…", language: "Dil",
      off: "KAPALI", flash: "ÇAKAR", siren: "SİREN", prevMode: "Önceki mod", nextMode: "Sonraki mod", modeList: "Mod listesi",
      night: "GECE", nightTip: "Gece seviyesi (kısık)", tkd: "TKD", tkdTip: "Takedown: öne sabit beyaz", aly: "YAN", alyTip: "Yan aydınlatma (alley)",
      tabPlace: "Yerleşim", tabPattern: "Desen", tabLight: "Işık", tabBar: "Lightbar", tabProfile: "Profil",
      kitLbl: "Hazır kit", kitClear: "Temizle", kitClearTip: "Tüm gizli çakarları kaldır", colorLbl: "Renk",
      keep: "mevcutları koru", keepTip: "Kit uygularken mevcut bölgeleri koru, yalnızca eksikleri ekle",
      addBar: "+ LED bar", addBarTip: "Kit ile birlikte tavana LED bar da ekle",
      capFront: "ÖN", capRear: "ARKA", freeZone: "＋ Serbest konum", freeTip: "İstediğin yere elle yerleştir (aracın merkezine göre)",
      legendFac: "fabrika konumu", legendScan: "yüzey taraması", scanning: "araç taranıyor…",
      hintTitle: "Bir bölge seç",
      hintP1: "Haritada bölgeye tıkla: çakarlar oraya kendiliğinden yerleşir. Yeşil noktalı bölgelerde aracı yapanın kendi çakar konumları kullanılır; diğerlerinde aracın 3B modeli taranır ve başlıklar yüzeye oturtulur.",
      hintP2a: "En hızlısı: yukarıdan bir ", hintP2b: "hazır kit", hintP2c: " seç, sonra istediğin bölgeyi düzenle.",
      hiddenFac: "Aynı yere denk gelen {n} fabrika çakarı gizlendi.",
      rowTip: "{n}. sıra", addRowTip: "Bu bölgeye bir sıra daha ekle", removeRowTip: "Bu sırayı kaldır", applyingTag: "UYGULANIYOR…",
      countLbl: "Adet / yan", gapLbl: "Aralık cm", x0Lbl: "Merkezden cm", auto: "oto",
      headType: "Başlık tipi", colorTone: "Renk ve ton", swap: "⇄ sol / sağ değiştir", swapTip: "Sol ve sağ rengi değiştir",
      left: "Sol", right: "Sağ", second: "2. renk", noSecond: "İkinci renk yok", secondPrefix: "2. renk: ",
      brightness: "Parlaklık", brightTip: "Başlık tipinin temel kandelası × {k}", custom: "Özel değer",
      cd: "Kandela", cdTip: "Başlık başına ışık şiddeti", lm: "Lümen", lmTip: "Başlık başına ışık akısı", lux: "Lüks", luxTip: "Belirli mesafede aydınlık düzeyi",
      slHead: "Başlık", slIllum: "Aydınlık", slDist: "Mesafe",
      perHead: "cd / başlık", perSide: "cd / yan", at10: "10 m'de", rangeW: "menzil",
      pattern: "Desen", grpTip: "Faz grubu: B grubu, A grubunun karşı fazında çakar",
      sideAlt: "Sol ve sağ dönüşümlü", sideSync: "İki yan birlikte", sideRev: "Sıra ters", level: "Seviye", phase: "Faz kayması",
      fine: "İnce ayar", resetPos: "otomatik konuma dön",
      up: "Yukarı", inward: "İçe (merkeze doğru)", outward: "Dışa", down: "Aşağı",
      depth: "Derinlik", fwd: "öne", fwdTip: "Aracın önüne doğru", back: "arkaya", backTip: "Aracın arkasına doğru",
      turn: "Dönüş", turnIn: "İçe çevir", turnOut: "Dışa çevir", tilt: "Eğim", tiltUp: "Yukarı baktır", tiltDown: "Aşağı baktır", step: "Adım",
      wLateral: "yanal", wDepth: "derinlik", wHeight: "yükseklik", wYaw: "dönüş", wTilt: "eğim", autoPos: "otomatik konumda",
      advanced: "Gelişmiş", srcLbl: "Konum kaynağı",
      srcAuto: "Oto", srcAutoTip: "Varsa fabrika konumu, yoksa yüzey taraması", srcScan: "Tarama", srcScanTip: "Fabrika konumunu yok say, yüzeyi tara",
      srcApprox: "Yaklaşık", srcApproxTip: "Yalnızca yaklaşık konum (model okunamıyorsa)",
      arrange: "Diziliş", axX: "Yan yana", axZ: "Üst üste", axY: "Arka arkaya",
      facing: "Bakış yönü", fFront: "Öne", fRear: "Arkaya", fSide: "Yanlara",
      follow: "Yüzeyi izle", followTip: "Tampon / panjur kıvrımına göre yatay açı ver", ftilt: "Eğimi izle", ftiltTip: "Yüzeyin dikey eğimine göre eğ",
      single: "Tek taraf", singleTip: "Yalnızca sol tarafa yerleştir", adv: "Ok üyesi", advTip: "Trafik oku modlarında sırayla yanar (arkaya bakan bölgeler)",
      lpl: "Başlık başına ışık", lplTip: "Her başlığa ayrı ışık kaynağı (daha gerçekçi, daha ağır)",
      white: "Takedown bölgesi", whiteTip: "Yalnızca takedown / sahne ışığı olarak çalışır",
      sink: "Gömme", size: "Boyut", beam: "Işık açısı", rangeLbl: "Menzil", rangeAutoTip: "Şiddete göre hesaplanır", meter: "Metre",
      bound: "Bağlı gövde grubu: ",
      modeGroups: ["Takip", "Sahne · Seyir", "Trafik oku", "Lightbar efektleri"],
      setDefault: "Bu modu varsayılan yap", setDefaultTip: "Araç her açıldığında bu modla başlar",
      wigwag: "Far wig-wag", wigwagTip: "Farlar da dönüşümlü çakar", nightSensor: "Gece sensörü", nightSensorTip: "Gece kendiliğinden kısılır",
      speed: "Hız", dayLvl: "Gündüz seviyesi", nightLvl: "Gece seviyesi", cruiseLvl: "Seyir seviyesi",
      patternNote: "Bölgeye özel desen, faz ve seviye için Yerleşim sekmesinde bölgeyi seç. Trafik oku modları \"Ok üyesi\" işaretli arka bölgeleri sırayla yakar; \"Trafik oku\" kiti bunu hazır kurar.",
      allBright: "Tüm gizli çakarların parlaklığı",
      brightNote: "Kandela ölçeği oyunun kendi ışık parçalarıyla aynıdır: oyunun 4 başlıklı gizli çakar grubu yaklaşık 4.200 cd. \"Fabrika\" o seviyedir; \"Yüksek\" gündüz uzaktan görünürlük içindir.",
      glow: "Lens parlaması", flareL: "Hale (flare)", flareType: "Hale tipi", cookie: "Işık dokusu", colorProfile: "Renk profili",
      cpReal: "Gerçekçi LED", cpRealTip: "Gerçek LED dalga boylarına göre renkler", cpVivid: "Canlı", cpOrig: "Orijinal", cpOrigTip: "Diğer ışıkların rengine dokunma",
      props: "Çevreyi aydınlat", propsTip: "Kapalıyken yalnızca lensler parlar (en hafif)", shadows: "Gölgeler", shadowsTip: "Işıklar gölge düşürür (ağır)",
      lens: "Renkli lens", lensTip: "Sönükken lens renkli görünür",
      studio: "Işık Stüdyosu — araçtaki tüm uyarı ışıkları", all: "Tümü", groupTip: "{n} ışık · {a}–{b} cd",
      noGroups: "Bu araçta henüz işlenmiş uyarı ışığı yok: önce bir bölge ya da lightbar ekle.",
      intensity: "Şiddet", iOrig: "Orijinal", iMult: "Çarpan", distance: "Mesafe",
      rOrig: "Orijinal", rMult: "Çarpan", rMeter: "Metre", rAuto: "Otomatik", threshold: "Eşik", original: "orijinal", flareS: "Hale",
      photometric: "Fotometrik denge", photometricTip: "Renkli ışıkta gözün algıladığı (fotometrik) şiddeti korur",
      resetAll: "Tümünü sıfırla", resetGroup: "Bu grubu sıfırla", vehLights: "Araç ışıkları (far, stop …)",
      groupArray: "{z} (dizi {n})", groupBar: "LED bar {n}", groupCopy: "Kopya {n}: {name}",
      mlTitle: "Multicolor hoparlörlü LED bar (tavan)", roofTag: "tavan", copyTag: "kopya", ledBar: "LED bar", remove: "Kaldır",
      length: "Uzunluk", third: "3. renk", arrowCol: "Ok rengi", fwdBack: "İleri / geri", height: "Yükseklik",
      moduleCd: "Modül şiddeti", whiteCd: "Beyaz şiddeti", mount: "Yer", lateral: "Yanal", yaw: "Dönüş", scale: "Ölçek",
      anchors: {orig: "Orijinal", roof: "Tavan", custom: "Serbest"},
      anchorTips: {orig: "Kopyalanan parçanın kendi yeri", roof: "Tavan (otomatik)", custom: "Serbest (aracın merkezine göre)"},
      installedTitle: "Araçtaki tepe lambaları", copies: "kopya adedi", copyBtn: "Kopyala", lightsW: "ışık",
      noInstalled: "Bu araçta takılı tepe lambası yok. Aşağıdaki kütüphaneden ekleyebilirsin.",
      libTitle: "Kütüphane — diğer araçlardan ve modlardan", scanBtn: "Tara", deepScan: "Derin tara", deepTip: "Tüm araçların tüm parçaları (yavaş)",
      scanningN: "Taranıyor… {d} / {t}", search: "Ara: ad, parça, araç…", addBtn: "Ekle",
      libEmpty: "Kütüphane boş: \"Tara\" ile yüklü araçlardaki tepe lambalarını bul.",
      profThis: "Bu aracın profilleri — {m}", profName: "Profil adı", save: "Kaydet", load: "Yükle", del: "Sil",
      profGlobal: "Genel profiller — her araçta kullanılır",
      profNote: "Ayarlar aracın konfigürasyonunda durur: Araç Ayarları ekranından konfigürasyonu kaydedersen çakarlar da onunla birlikte kaydedilir.",
      autoTitle: "Bindiğim her araca otomatik uygula", on: "AÇIK", offW: "KAPALI",
      autoNote: "Açıkken, çakar ayarı olmayan bir araca bindiğinde seçili kit kendiliğinden yerleştirilir (yalnızca otomobil ve kamyonlar).",
      other: "Diğer", hideFac: "Çakışan fabrika çakarlarını gizle", hideFacTip: "Aynı yere denk gelen oyunun kendi gizli çakarları çizilmez",
      markers: "Önizleme kutuları", markersTip: "Seçili bölgenin başlıklarını araç üzerinde tel kutu olarak gösterir",
      autoApply: "Otomatik uygula", autoApplyTip: "Konum değişikliklerini kısa bir beklemeden sonra kendiliğinden uygular",
      rescan: "Aracı yeniden tara", clearAll: "Bu araçtan tümünü kaldır",
      surface: "Yüzey modeli: ", tris: "üçgen", unread: "okunamadı", sec: "sn", facPart: "Fabrika parçası: ", installedTag: "(takılı)",
      applying: "Uygulanıyor…", unapplied: "Uygulanmamış değişiklik var", apply: "Uygula", summary: "{a} bölge · {b} bar · {c} kopya",
      emptyHint: "Bir araca bin: çakarlar otomatik yerleştirilir.",
      msg: {noVehicle: "Araç yok: bir araca bin.", noData: "Araç verisi yok.", error: "Hata: "},
      err: {maxArrays: "En fazla {n} dizi eklenebilir.", kitNone: "Bu araçta kitin bölgeleri bulunamadı."},
      warn: {envFail: "Araç ortamı kurulamadı: {v}", noPart: "Parça bulunamadı: {v}", noZone: "Bu araçta bölge yok: {v}",
             itemFail: "Öğe eklenemedi: {v}", scanFail: "Yüzey taraması yapılamadı: {v}", hintFail: "Fabrika konumları okunamadı: {v}",
             bigFile: "Çok büyük model dosyası atlandı: {v}"},
      src: {factory: "FABRİKA KONUMU", scan: "YÜZEY TARAMASI", approx: "YAKLAŞIK", none: "BU ARAÇTA YOK"},
      zones: {windshield: "Ön cam içi (üst)", dash: "Torpido üstü", grille: "Ön panjur", bumperF: "Ön tampon", hood: "Kaput önü",
              hideF: "Far içi (hideaway)", mirrors: "Yan aynalar", sideF: "Ön çamurluk (kavşak)", skirt: "Marşpiyel (yan)",
              sideRear: "Arka yan cam içi", rearglass: "Arka cam içi (üst)", reardeck: "Arka raf (cam altı)", trunk: "Bagaj kapağı (plaka yanı)",
              bumperR: "Arka tampon", hideR: "Stop içi (hideaway)", roof: "Tavan", custom: "Serbest konum"},
      zoneShort: {windshield: "Ön cam üstü", dash: "Torpido", grille: "Panjur", bumperF: "Ön tampon", hood: "Kaput", hideF: "Far içi",
                  mirrors: "Ayna", sideF: "Ön yan", skirt: "Marşpiyel", sideRear: "Yan cam", rearglass: "Arka cam üstü", reardeck: "Arka raf",
                  trunk: "Bagaj", bumperR: "Arka tampon", hideR: "Stop içi", roof: "Tavan", custom: "Serbest"},
      zoneNA: " — bu araçta yok", zoneFac: " — fabrika konumu", zoneScan: " — yüzey taraması",
      headShort: {std: "Standart", slim: "İnce", wide: "Geniş", mini: "Mini", lin: "Lineer", round: "Hideaway"},
      headLong: {std: "Standart modül (8 LED)", slim: "İnce modül (4 LED)", wide: "Geniş modül (12 LED)", mini: "Mini modül (3 LED)",
                 lin: "Lineer çubuk (6 LED)", round: "Hideaway (yuvarlak)"},
      kits: {undercover: "Sivil ekip", full: "Tam donanım", front: "Sadece ön", rear: "Sadece arka", slicktop: "İç lightbar", hideaway: "Hideaway",
             traffic: "Trafik oku"},
      kitDesc: {undercover: "Ön cam üstü, panjur, arka cam, bagaj", full: "Tüm bölgeler; ön camda beyaz takedown, arkada amber ok",
                front: "Ön cam üstü, panjur, ön tampon", rear: "Arka cam, bagaj, arka tampon",
                slicktop: "Ön ve arka camı boydan boya dolduran sıra (slicktop)", hideaway: "Far ve stop içi, panjur",
                traffic: "Arka camda 3 kademeli amber ok + ön/arka amber ikaz"},
      colors: {1: "Kırmızı", 2: "Mavi", 3: "Beyaz", 4: "Amber", 5: "Yeşil", 6: "Mor"},
      tones: {1: ["Kırmızı 625 nm", "Turuncu-kırmızı 615 nm", "Gül kırmızısı"], 2: ["Polis mavisi 470 nm", "Derin mavi 455 nm", "Buz mavisi 480 nm"],
              3: ["Beyaz 6000 K", "Nötr beyaz 5000 K", "Sıcak beyaz 4000 K"], 4: ["Amber 590 nm", "Sarı 585 nm", "Turuncu 600 nm"],
              5: ["Yeşil 505 nm", "Saf yeşil 525 nm", "Limon yeşili 555 nm"], 6: ["Mor", "Macenta", "Menekşe"]},
      bright: {1: "Fabrika (oyun)", 2: "Standart", 3: "Yüksek", 4: "Çok yüksek"},
      bfn: {1: "Takedown", 2: "Sahne", 3: "Dönüşümlü", 4: "Trafik oku", 5: "Seyir"},
      bfnLong: {1: "Takedown (beyaz aydınlatma tuşuyla sabit yanar)", 2: "Sahne / park modlarında sabit yanar", 3: "Ana renkle dönüşümlü çakar",
                4: "Trafik oku modlarında ok rengi", 5: "Seyir modlarında kısık sabit yanar"},
      modes: ["Normal (Orijinal)", "Takip – Çift Flaş", "Takip – Dörtlü", "Takip – Hızlı", "Karışık (Combo)", "Takedown",
              "Sahne / Park", "Seyir 1 (Sabit)", "Seyir 2", "Trafik Oku – Sol", "Trafik Oku – Sağ", "Trafik Oku – Orta",
              "Avrupa (ECE)", "Dalga", "Tam Beyaz Aydınlatma", "Tarama (Soldan Sağa)", "Tarama (Ping-Pong)", "Çapraz",
              "Dönen Işık (360°)", "Ortadan Dışa", "Dıştan Ortaya", "Xenon Strobe", "Hızlı Dörtlü Strobe", "Yavaş Dalga",
              "Rastgele Pırıltı", "Çift + Üçlü", "Sabit + Çakar (Steady Burn)", "Hiper Flaş", "Üçlü + Tek", "Eş Zamanlı Dörtlü",
              "Yavaş İkaz (1 Hz)"],
      patterns: ["Moda göre", "Orijinal", "Çift flaş", "Üçlü flaş", "Dörtlü flaş", "Tekli", "Hızlı", "Eş zamanlı çift", "ECE",
                 "Combo", "Sahne (yavaş)", "Sabit", "Kapalı", "Xenon strobe", "Hızlı dörtlü", "Çift + üçlü", "Yavaş", "Steady burn",
                 "Hiper flaş", "Üçlü + tek", "Eş zamanlı dörtlü", "Yavaş ikaz 1 Hz"],
      flare: ["Orijinal", "Yumuşak", "Far", "Yıldız", "Işınsal", "Geniş hale", "Kapalı"],
      cookieT: ["", "Lightbar", "Genel LED", "Yok"],
      ml: {1: "Kırmızı", 2: "Mavi", 3: "Beyaz", 4: "Amber"},
      dec: ",", thou: ".",
    },
    en: {
      appTitle: "CONCEALED FLASHERS PRO", vehWait: "Waiting for a vehicle…", language: "Language",
      off: "OFF", flash: "LIGHTS", siren: "SIREN", prevMode: "Previous mode", nextMode: "Next mode", modeList: "Mode list",
      night: "NIGHT", nightTip: "Night level (dimmed)", tkd: "TKD", tkdTip: "Takedown: steady white to the front", aly: "ALLEY", alyTip: "Alley lights",
      tabPlace: "Placement", tabPattern: "Patterns", tabLight: "Light", tabBar: "Lightbar", tabProfile: "Profiles",
      kitLbl: "Kits", kitClear: "Clear", kitClearTip: "Remove all concealed flashers", colorLbl: "Colors",
      keep: "keep existing", keepTip: "Keep the zones you already have and only add the missing ones",
      addBar: "+ LED bar", addBarTip: "Also add an LED bar on the roof",
      capFront: "FRONT", capRear: "REAR", freeZone: "＋ Free position", freeTip: "Place it anywhere by hand (relative to the vehicle center)",
      legendFac: "factory position", legendScan: "surface scan", scanning: "scanning the vehicle…",
      hintTitle: "Pick a zone",
      hintP1: "Click a zone on the map and the flashers are placed there automatically. Zones with a green dot use the vehicle author's own flasher positions; everywhere else the vehicle's 3D model is scanned and the heads are seated on the surface.",
      hintP2a: "Fastest: pick a ", hintP2b: "kit", hintP2c: " above, then fine-tune any zone.",
      hiddenFac: "{n} factory flashers at the same spots are hidden.",
      rowTip: "row {n}", addRowTip: "Add another row to this zone", removeRowTip: "Remove this row", applyingTag: "APPLYING…",
      countLbl: "Per side", gapLbl: "Spacing cm", x0Lbl: "From center cm", auto: "auto",
      headType: "Head type", colorTone: "Color and tone", swap: "⇄ swap left / right", swapTip: "Swap the left and right colors",
      left: "Left", right: "Right", second: "2nd color", noSecond: "No second color", secondPrefix: "2nd: ",
      brightness: "Brightness", brightTip: "Head type base candela × {k}", custom: "Custom value",
      cd: "Candela", cdTip: "Luminous intensity per head", lm: "Lumen", lmTip: "Luminous flux per head", lux: "Lux", luxTip: "Illuminance at a given distance",
      slHead: "Per head", slIllum: "Illuminance", slDist: "Distance",
      perHead: "cd / head", perSide: "cd / side", at10: "at 10 m", rangeW: "range",
      pattern: "Pattern", grpTip: "Phase group: group B flashes in counter-phase to group A",
      sideAlt: "Left and right alternate", sideSync: "Both sides together", sideRev: "Reversed", level: "Level", phase: "Phase offset",
      fine: "Fine tuning", resetPos: "back to the automatic position",
      up: "Up", inward: "Inward (towards the center)", outward: "Outward", down: "Down",
      depth: "Depth", fwd: "forward", fwdTip: "Towards the front of the vehicle", back: "backward", backTip: "Towards the rear of the vehicle",
      turn: "Yaw", turnIn: "Turn inward", turnOut: "Turn outward", tilt: "Tilt", tiltUp: "Aim up", tiltDown: "Aim down", step: "Step",
      wLateral: "lateral", wDepth: "depth", wHeight: "height", wYaw: "yaw", wTilt: "tilt", autoPos: "at the automatic position",
      advanced: "Advanced", srcLbl: "Position source",
      srcAuto: "Auto", srcAutoTip: "Factory position when available, otherwise surface scan", srcScan: "Scan", srcScanTip: "Ignore the factory position, scan the surface",
      srcApprox: "Approx.", srcApproxTip: "Approximate position only (if the model cannot be read)",
      arrange: "Arrangement", axX: "Side by side", axZ: "Stacked", axY: "In line",
      facing: "Facing", fFront: "Front", fRear: "Rear", fSide: "Sides",
      follow: "Follow surface", followTip: "Angle the heads along the bumper / grille curve", ftilt: "Follow slope", ftiltTip: "Tilt with the surface's vertical slope",
      single: "One side only", singleTip: "Place on the left side only", adv: "Arrow member", advTip: "Lights up in sequence in traffic advisor modes (rear-facing zones)",
      lpl: "Light per head", lplTip: "A separate light source for every head (more realistic, heavier)",
      white: "Takedown zone", whiteTip: "Works only as takedown / scene light",
      sink: "Recess", size: "Size", beam: "Beam angle", rangeLbl: "Range", rangeAutoTip: "Calculated from the intensity", meter: "Meters",
      bound: "Attached to body group: ",
      modeGroups: ["Pursuit", "Scene · Cruise", "Traffic advisor", "Lightbar effects"],
      setDefault: "Make this the default mode", setDefaultTip: "The vehicle starts in this mode every time",
      wigwag: "Headlight wig-wag", wigwagTip: "The headlights flash alternately too", nightSensor: "Night sensor", nightSensorTip: "Dims automatically at night",
      speed: "Speed", dayLvl: "Day level", nightLvl: "Night level", cruiseLvl: "Cruise level",
      patternNote: "For a zone's own pattern, phase and level, select the zone on the Placement tab. Traffic advisor modes light the rear zones marked \"Arrow member\" in sequence; the \"Traffic advisor\" kit sets this up for you.",
      allBright: "Brightness of all concealed flashers",
      brightNote: "The candela scale matches the game's own light parts: the game's 4-head concealed flasher group is about 4,200 cd. \"Factory\" is that level; \"High\" is for daytime visibility from far away.",
      glow: "Lens glow", flareL: "Flare", flareType: "Flare type", cookie: "Light texture", colorProfile: "Color profile",
      cpReal: "Realistic LED", cpRealTip: "Colors based on real LED wavelengths", cpVivid: "Vivid", cpOrig: "Original", cpOrigTip: "Leave the other lights' colors untouched",
      props: "Light up surroundings", propsTip: "When off, only the lenses glow (lightest)", shadows: "Shadows", shadowsTip: "Lights cast shadows (heavy)",
      lens: "Tinted lens", lensTip: "The lens looks colored when the light is off",
      studio: "Light Studio — all warning lights on the vehicle", all: "All", groupTip: "{n} lights · {a}–{b} cd",
      noGroups: "No processed warning lights on this vehicle yet: add a zone or a lightbar first.",
      intensity: "Intensity", iOrig: "Original", iMult: "Multiplier", distance: "Distance",
      rOrig: "Original", rMult: "Multiplier", rMeter: "Meters", rAuto: "Automatic", threshold: "Threshold", original: "original", flareS: "Flare",
      photometric: "Photometric balance", photometricTip: "Keeps the perceived (photometric) intensity of colored light",
      resetAll: "Reset all", resetGroup: "Reset this group", vehLights: "Vehicle lights (headlights, brakes …)",
      groupArray: "{z} (array {n})", groupBar: "LED bar {n}", groupCopy: "Copy {n}: {name}",
      mlTitle: "Multicolor speaker LED bar (roof)", roofTag: "roof", copyTag: "copy", ledBar: "LED bar", remove: "Remove",
      length: "Length", third: "3rd color", arrowCol: "Arrow color", fwdBack: "Fore / aft", height: "Height",
      moduleCd: "Module intensity", whiteCd: "White intensity", mount: "Mount", lateral: "Lateral", yaw: "Yaw", scale: "Scale",
      anchors: {orig: "Original", roof: "Roof", custom: "Free"},
      anchorTips: {orig: "Where the copied part normally sits", roof: "Roof (automatic)", custom: "Free (relative to the vehicle center)"},
      installedTitle: "Lightbars on this vehicle", copies: "copies", copyBtn: "Copy", lightsW: "lights",
      noInstalled: "No lightbar is fitted to this vehicle. You can add one from the library below.",
      libTitle: "Library — from other vehicles and mods", scanBtn: "Scan", deepScan: "Deep scan", deepTip: "Every part of every vehicle (slow)",
      scanningN: "Scanning… {d} / {t}", search: "Search: name, part, vehicle…", addBtn: "Add",
      libEmpty: "The library is empty: press \"Scan\" to find the lightbars of the installed vehicles.",
      profThis: "Profiles for this vehicle — {m}", profName: "Profile name", save: "Save", load: "Load", del: "Delete",
      profGlobal: "Global profiles — usable on any vehicle",
      profNote: "Settings live in the vehicle's configuration: when you save the configuration in Vehicle Config, the flashers are saved with it.",
      autoTitle: "Apply automatically to every vehicle I drive", on: "ON", offW: "OFF",
      autoNote: "When on, the selected kit is placed automatically whenever you get into a vehicle without flasher settings (cars and trucks only).",
      other: "Other", hideFac: "Hide overlapping factory flashers", hideFacTip: "The game's own concealed flashers at the same spots are not drawn",
      markers: "Preview boxes", markersTip: "Shows the heads of the selected zone as wire boxes on the vehicle",
      autoApply: "Auto apply", autoApplyTip: "Applies position changes automatically after a short pause",
      rescan: "Rescan vehicle", clearAll: "Remove everything from this vehicle",
      surface: "Surface model: ", tris: "triangles", unread: "could not be read", sec: "s", facPart: "Factory part: ", installedTag: "(installed)",
      applying: "Applying…", unapplied: "Unapplied changes", apply: "Apply", summary: "{a} zones · {b} bars · {c} copies",
      emptyHint: "Get into a vehicle: the flashers are placed automatically.",
      msg: {noVehicle: "No vehicle: get into one.", noData: "No vehicle data.", error: "Error: "},
      err: {maxArrays: "At most {n} arrays can be added.", kitNone: "None of the kit's zones exist on this vehicle."},
      warn: {envFail: "Vehicle environment failed: {v}", noPart: "Part not found: {v}", noZone: "Zone not available on this vehicle: {v}",
             itemFail: "Item failed: {v}", scanFail: "Surface scan failed: {v}", hintFail: "Factory positions could not be read: {v}",
             bigFile: "Very large model file skipped: {v}"},
      src: {factory: "FACTORY POSITION", scan: "SURFACE SCAN", approx: "APPROXIMATE", none: "NOT ON THIS VEHICLE"},
      zones: {windshield: "Windshield (top, inside)", dash: "Dashboard", grille: "Grille", bumperF: "Front bumper", hood: "Hood front",
              hideF: "Headlights (hideaway)", mirrors: "Side mirrors", sideF: "Front fenders (intersection)", skirt: "Side skirts",
              sideRear: "Rear side windows", rearglass: "Rear window (top, inside)", reardeck: "Rear deck", trunk: "Trunk lid (by the plate)",
              bumperR: "Rear bumper", hideR: "Tail lights (hideaway)", roof: "Roof", custom: "Free position"},
      zoneShort: {windshield: "Windshield", dash: "Dash", grille: "Grille", bumperF: "Front bumper", hood: "Hood", hideF: "Headlights",
                  mirrors: "Mirrors", sideF: "Fenders", skirt: "Skirts", sideRear: "Side glass", rearglass: "Rear window", reardeck: "Rear deck",
                  trunk: "Trunk", bumperR: "Rear bumper", hideR: "Tail lights", roof: "Roof", custom: "Free"},
      zoneNA: " — not on this vehicle", zoneFac: " — factory position", zoneScan: " — surface scan",
      headShort: {std: "Standard", slim: "Slim", wide: "Wide", mini: "Mini", lin: "Linear", round: "Hideaway"},
      headLong: {std: "Standard module (8 LED)", slim: "Slim module (4 LED)", wide: "Wide module (12 LED)", mini: "Mini module (3 LED)",
                 lin: "Linear stick (6 LED)", round: "Hideaway (round)"},
      kits: {undercover: "Undercover", full: "Full package", front: "Front only", rear: "Rear only", slicktop: "Interior lightbar", hideaway: "Hideaway",
             traffic: "Traffic advisor"},
      kitDesc: {undercover: "Windshield, grille, rear window, trunk", full: "All zones; white takedown in the windshield, amber arrow at the rear",
                front: "Windshield, grille, front bumper", rear: "Rear window, trunk, rear bumper",
                slicktop: "Full-width rows across the windshield and the rear window (slicktop)", hideaway: "Headlights, tail lights, grille",
                traffic: "3-step amber arrow in the rear window + amber warning front and rear"},
      colors: {1: "Red", 2: "Blue", 3: "White", 4: "Amber", 5: "Green", 6: "Purple"},
      tones: {1: ["Red 625 nm", "Orange-red 615 nm", "Rose red"], 2: ["Police blue 470 nm", "Deep blue 455 nm", "Ice blue 480 nm"],
              3: ["White 6000 K", "Neutral white 5000 K", "Warm white 4000 K"], 4: ["Amber 590 nm", "Yellow 585 nm", "Orange 600 nm"],
              5: ["Green 505 nm", "Pure green 525 nm", "Lime 555 nm"], 6: ["Purple", "Magenta", "Violet"]},
      bright: {1: "Factory (game)", 2: "Standard", 3: "High", 4: "Very high"},
      bfn: {1: "Takedown", 2: "Scene", 3: "Alternating", 4: "Traffic arrow", 5: "Cruise"},
      bfnLong: {1: "Takedown (steady with the takedown switch)", 2: "Steady in scene / park modes", 3: "Flashes alternating with the main color",
                4: "Arrow color in traffic advisor modes", 5: "Dim steady in cruise modes"},
      modes: ["Normal (Original)", "Pursuit – Double Flash", "Pursuit – Quad", "Pursuit – Fast", "Mixed (Combo)", "Takedown",
              "Scene / Park", "Cruise 1 (Steady)", "Cruise 2", "Traffic Advisor – Left", "Traffic Advisor – Right", "Traffic Advisor – Center",
              "European (ECE)", "Wave", "Full White Flood", "Scan (Left to Right)", "Scan (Ping-Pong)", "Cross",
              "Rotator (360°)", "Center Out", "Outside In", "Xenon Strobe", "Fast Quad Strobe", "Slow Wave",
              "Random Sparkle", "Double + Triple", "Steady Burn + Flash", "Hyper Flash", "Triple + Single", "Simultaneous Quad",
              "Slow Beacon (1 Hz)"],
      patterns: ["By mode", "Original", "Double flash", "Triple flash", "Quad flash", "Single", "Fast", "Simultaneous double", "ECE",
                 "Combo", "Scene (slow)", "Steady", "Off", "Xenon strobe", "Fast quad", "Double + triple", "Slow", "Steady burn",
                 "Hyper flash", "Triple + single", "Simultaneous quad", "Slow beacon 1 Hz"],
      flare: ["Original", "Soft", "Headlight", "Star", "Spokes", "Wide halo", "Off"],
      cookieT: ["", "Lightbar", "Generic LED", "None"],
      ml: {1: "Red", 2: "Blue", 3: "White", 4: "Amber"},
      dec: ".", thou: ",",
    },
  };

  // mode groups (Patterns tab); names come from T.modeGroups by index
  const MODE_GROUPS = [
    {ids: [1, 2, 3, 4, 5, 26, 27, 28, 29, 30, 22, 23]},
    {ids: [6, 7, 15, 8, 9, 31, 13]},
    {ids: [10, 11, 12]},
    {ids: [14, 16, 17, 18, 19, 20, 21, 24, 25]},
  ];
  // zone chips on the map (percent): top, left; side zones are shown on both sides
  const ZONE_POS = [
    {id: "bumperF", top: 3.4, left: 50}, {id: "grille", top: 10.2, left: 50},
    {id: "hideF", top: 8.2, side: "l"}, {id: "hideF", top: 8.2, side: "r"},
    {id: "hood", top: 19.5, left: 50},
    {id: "sideF", top: 19.5, side: "l"}, {id: "sideF", top: 19.5, side: "r"},
    {id: "dash", top: 30.2, left: 50}, {id: "windshield", top: 37.6, left: 50},
    {id: "mirrors", top: 31.4, side: "l"}, {id: "mirrors", top: 31.4, side: "r"},
    {id: "roof", top: 51.5, left: 50},
    {id: "skirt", top: 46.5, side: "l"}, {id: "skirt", top: 46.5, side: "r"},
    {id: "sideRear", top: 58, side: "l"}, {id: "sideRear", top: 58, side: "r"},
    {id: "rearglass", top: 65.4, left: 50}, {id: "reardeck", top: 72.8, left: 50},
    {id: "trunk", top: 82.6, left: 50},
    {id: "hideR", top: 91.6, side: "l"}, {id: "hideR", top: 91.6, side: "r"},
    {id: "bumperR", top: 96.8, left: 50},
  ];
  const ML_HEX = {1: "#ff0021", 2: "#0a56ff", 3: "#fff4f1", 4: "#ff8400"};
  const CLASS_HEX = {red: "#ff0021", blue: "#0a56ff", white: "#f4f0ea", amber: "#ff8400", green: "#00ff89", purple: "#c400ff", multi: "#ffb000"};
  // fields applied without reloading the vehicle (same as the Lua side)
  const LIVE = {colL: 1, colR: 1, toneL: 1, toneR: 1, toneB: 1, bright: 1, pat: 1, phase: 1, side: 1, lvl: 1, grp: 1, bfn: 1, adv: 1, kind2: 1};
  const UI_KEY = "bcfpStudio3.ui";

  function toLuaLiteral(v) {
    if (v === null || v === undefined) return "nil";
    if (typeof v === "boolean") return v ? "true" : "false";
    if (typeof v === "number") return isFinite(v) ? String(v) : "0";
    if (typeof v === "string") {
      return '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r") + '"';
    }
    if (Array.isArray(v)) return "{" + v.map(toLuaLiteral).join(",") + "}";
    if (typeof v === "object") {
      const parts = [];
      Object.keys(v).forEach((k) => {
        if (k.charAt(0) === "$" || k.charAt(0) === "_") return;
        parts.push("[" + toLuaLiteral(k) + "]=" + toLuaLiteral(v[k]));
      });
      return "{" + parts.join(",") + "}";
    }
    return "nil";
  }

  function asArray(v) {
    if (Array.isArray(v)) return v;
    if (v && typeof v === "object") {
      return Object.keys(v).sort((a, b) => Number(a) - Number(b)).map((k) => v[k]);
    }
    return [];
  }
  function num(v, d) { const n = parseFloat(v); return isFinite(n) ? n : (d === undefined ? 0 : d); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function round(v, d) { const k = Math.pow(10, d || 0); return Math.round(v * k) / k; }
  function fill(s, o) { return String(s || "").replace(/\{(\w+)\}/g, (m, k) => (o && o[k] !== undefined ? o[k] : m)); }

  angular.module("beamng.apps").directive("bcfpStudio", ["$interval", "$timeout", function ($interval, $timeout) {
    return {
      templateUrl: APP_PATH + "app.html",
      replace: false,
      restrict: "EA",
      scope: true,
      link: function (S, element) {
        S.st = {}; S.cfg = {}; S.master = {}; S.items = []; S.arrays = []; S.bars = []; S.copies = [];
        S.groups = []; S.installed = []; S.status = {}; S.zinfo = {}; S.enums = {}; S.zoneState = {}; S.zoneItems = {};
        S.library = {state: "idle", results: []}; S.libFiltered = [];
        S.sel = null; S.edit = null; S.gsel = "*"; S.sedit = null; S.err = null;
        S.MODE_GROUPS = MODE_GROUPS; S.ZONE_POS = ZONE_POS; S.ML_HEX = ML_HEX;
        S.colorIdx = [1, 2, 3, 4, 5, 6]; S.mlIdx = [1, 2, 3, 4]; S.steps = [0.5, 1, 2, 5, 20];
        S.ui = {tab: "place", autoApply: true, markers: true, adv: false, step: 1, copies: 1, filter: "", profileName: "",
                globalName: "", patOpen: false, modeOpen: false, kitKeep: false, kitBar: false, lang: null};
        try {
          const saved = JSON.parse(window.localStorage.getItem(UI_KEY) || "{}");
          ["tab", "autoApply", "markers", "adv", "step", "kitKeep", "kitBar", "lang"].forEach((k) => { if (saved[k] !== undefined) S.ui[k] = saved[k]; });
        } catch (e) { /* no browser storage */ }
        function remember() {
          try {
            window.localStorage.setItem(UI_KEY, JSON.stringify({tab: S.ui.tab, autoApply: S.ui.autoApply, markers: S.ui.markers,
              adv: S.ui.adv, step: S.ui.step, kitKeep: S.ui.kitKeep, kitBar: S.ui.kitBar, lang: S.lang}));
          } catch (e) { /* no browser storage */ }
        }
        S.remember = remember;

        const touched = {};
        let applyTimer = null;
        const sendTimers = {};

        function lua(cmd, args) {
          if (typeof bngApi === "undefined") return;
          bngApi.engineLua("if not bcfpPro then extensions.load('bcfpPro') end; if bcfpPro then bcfpPro.ui(" +
            toLuaLiteral(cmd) + "," + toLuaLiteral(args || {}) + ") end");
        }
        S.lua = lua;

        // --------------------------------------------------------------------- language
        // The game keeps the choice (/settings/bcfp_pro/prefs.json); until its state arrives the last choice of this
        // browser (or the system language) is used so the app does not flicker.
        function useLang(l) {
          S.lang = L10N[l] ? l : "en";
          S.T = L10N[S.lang];
        }
        useLang(S.ui.lang || ((navigator.language || "").toLowerCase().indexOf("tr") === 0 ? "tr" : "en"));
        S.setLang = (l) => {
          if (!L10N[l]) return;
          useLang(l);
          touched.lang = Date.now();
          remember();
          lua("setLang", {lang: l});
        };
        S.tf = (key, o) => fill(S.T[key], o);

        // --------------------------------------------------------------------- formatting
        function fixed(n, d) {
          const s = n.toFixed(d || 0);
          return S.T.dec === "." ? s : s.replace(".", S.T.dec);
        }
        S.fmt = (v, d) => { const n = parseFloat(v); return isFinite(n) ? fixed(n, d) : "–"; };
        S.signed = (v, d) => { const n = num(v); return (n > 0 ? "+" : "") + fixed(n, d); };
        S.big = (v) => {
          const n = num(v);
          if (n >= 100000) return fixed(n / 1000, 0) + " k";
          if (n >= 10000) return fixed(n / 1000, 1) + " k";
          return n.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, S.T.thou);
        };
        S.hasVehicle = () => !!(S.st && S.st.ok);
        S.colorHex = (idx, tone) => {
          const c = (S.enums.colors || [])[idx - 1];
          if (!c) return "#888";
          const t = asArray(c.tones)[(tone || 1) - 1];
          return (t && t.hex) || c.hex;
        };
        S.colorName = (idx, tone) => {
          if (tone) { const t = (S.T.tones[idx] || [])[tone - 1]; if (t) return t; }
          return S.T.colors[idx] || "";
        };
        S.schemeName = (s) => S.colorName(s.L) + " – " + S.colorName(s.R);
        S.tonesOf = (idx) => { const c = (S.enums.colors || [])[idx - 1]; return c ? asArray(c.tones) : []; };
        S.zoneName = (id) => S.T.zones[id] || id;
        S.zoneShort = (id) => S.T.zoneShort[id] || id;
        S.zoneKind = (id) => { const z = (S.enums.zones || []).find((q) => q.id === id); return z ? z.kind : ""; };
        S.headOf = (id) => (S.enums.heads || []).find((h) => h.id === id) || {};
        S.headTip = (h) => (S.T.headLong[h.id] || h.id) + " — " + S.fmt(h.w, 1) + " × " + S.fmt(h.h, 1) + " × " + S.fmt(h.d, 1) + " mm";
        S.stMsg = () => {
          const st = S.st || {};
          if (st.msgCode === "error") return S.T.msg.error + (st.msg || "");
          return (st.msgCode && S.T.msg[st.msgCode]) || st.msg || S.T.vehWait;
        };
        S.warnText = (w) => {
          if (!w || typeof w !== "object") return String(w || "");
          let v = w.v;
          if (w.k === "noZone") v = S.zoneName(v);
          return fill(S.T.warn[w.k] || (w.k + ": {v}"), {v: v});
        };
        S.groupName = (g) => {
          if (g.kind === "veh") return S.T.vehLights;
          const it = g.item && S.items.find((i) => i.id === g.item);
          if (it) {
            const n = String(it.id).replace(/^\D+/, "");
            if (it.kind === "array") return fill(S.T.groupArray, {z: S.zoneName(it.anchor), n: n});
            if (it.kind === "mlbar") return fill(S.T.groupBar, {n: n});
            if (it.kind === "copy") return fill(S.T.groupCopy, {n: n, name: it.name || it.part});
          }
          return g.name || g.key;
        };
        S.groupTip = (g) => fill(S.T.groupTip, {n: g.count, a: S.big(g.cd[0]), b: S.big(g.cd[1])});

        S.setTab = (t) => {
          S.ui.tab = t;
          S.ui.modeOpen = false;
          remember();
          if (t === "bar" && S.library.state === "idle") lua("library");
          syncMarkers();
        };

        // --------------------------------------------------------------------- state
        function recently(key) { return touched[key] && Date.now() - touched[key] < 1500; }

        function applyState(data) {
          S.st = data || {};
          if (S.st.lang && S.st.lang !== S.lang && !recently("lang")) { useLang(S.st.lang); remember(); }
          const en = S.st.enums || {};
          ["zones", "heads", "colors", "mlColors", "flareTypes", "modes", "patterns", "mlLengths", "bright", "bfn", "schemes", "kits", "anchors"]
            .forEach((k) => { en[k] = asArray(en[k]); });
          S.enums = en;
          const cfg = S.st.cfg || {};
          S.cfg = cfg;
          const m = cfg.master || {};
          Object.keys(m).forEach((k) => { if (!recently("m." + k)) S.master[k] = m[k]; });
          S.items = asArray(cfg.items);
          S.arrays = S.items.filter((i) => i.kind === "array");
          S.bars = S.items.filter((i) => i.kind === "mlbar");
          S.copies = S.items.filter((i) => i.kind === "copy");
          const rt = (S.st.runtime && asArray(S.st.runtime.items)) || [];
          S.rtById = {};
          rt.forEach((r) => { S.rtById[r.id] = r; });
          S.zinfo = (S.st.env && S.st.env.zones) || {};
          S.envReady = !!(S.st.env && S.st.env.ready);
          S.groups = asArray(S.st.groups).map((g) => {
            g.colorList = [];
            Object.keys(g.colors || {}).forEach((c) => g.colorList.push({c: c, n: g.colors[c], hex: CLASS_HEX[c] || "#888"}));
            g.cd = asArray(g.cd); g.range = asArray(g.range); g.angle = asArray(g.angle);
            return g;
          });
          S.installed = asArray(S.st.installed);
          S.profiles = asArray(S.st.profiles);
          S.globalProfiles = asArray(S.st.globalProfiles);
          S.factory = asArray(S.st.env && S.st.env.factory);
          S.warnings = asArray(S.st.runtime && S.st.runtime.warnings).concat(asArray(S.st.env && S.st.env.warnings));
          if (S.st.status && Object.keys(S.st.status).length) S.status = S.st.status;
          if (S.sel && !S.items.find((i) => i.id === S.sel)) S.sel = null;
          if (S.wantZone) {
            const it = S.arrays.find((i) => i.anchor === S.wantZone);
            if (it) { S.sel = it.id; S.wantZone = null; }
          }
          buildZoneState();
          syncEdit();
          syncStudio();
          syncMarkers();
          // a structural change is waiting: apply it automatically
          if (S.st.pending && S.ui.autoApply && !applyTimer) scheduleApply();
        }

        function buildZoneState() {
          const by = {};
          S.arrays.forEach((it) => { (by[it.anchor] = by[it.anchor] || []).push(it); });
          S.zoneItems = by;
          S.zoneState = {};
          (S.enums.zones || []).forEach((z) => {
            const info = S.zinfo[z.id] || {};
            const list = by[z.id] || [];
            S.zoneState[z.id] = {avail: S.envReady ? (info.avail || false) : "wait", on: list.length > 0, count: list.length,
              first: list[0] || null, part: info.part, active: info.active};
          });
        }

        function syncEdit() {
          const it = S.items.find((i) => i.id === S.sel);
          if (!it) { S.edit = null; return; }
          if (!S.edit || S.edit.id !== it.id || S.edit.__vid !== S.st.vid) {
            S.edit = angular.copy(it);
            S.edit.__vid = S.st.vid;
          } else {
            Object.keys(it).forEach((k) => { if (!recently("i." + k)) S.edit[k] = angular.copy(it[k]); });
          }
          if (S.edit && !S.edit.light) S.edit.light = {};
          if (S.edit && S.edit.kind === "mlbar" && !S.edit.disable) S.edit.disable = {r: false, b: false, w: false, a: false};
        }

        const STUDIO_DEFAULT = {imode: 0, imult: 100, cd: 5000, lm: 1500, lux: 50, luxd: 10, comp: 1, rmode: 0, rmult: 100,
          rng: 40, rlux: 2, ang: 0, inner: 12, flareType: 0, flare: 100, glow: 100, color: -1, shadow: 0};

        function syncStudio() {
          const st = (S.cfg && S.cfg.studio) || {};
          const cur = st[S.gsel] || st["*"] || STUDIO_DEFAULT;
          if (!S.sedit || S.sedit.__key !== S.gsel) {
            S.sedit = Object.assign({}, STUDIO_DEFAULT, angular.copy(cur));
            S.sedit.__key = S.gsel;
          } else {
            Object.keys(cur).forEach((k) => { if (!recently("s." + k)) S.sedit[k] = cur[k]; });
          }
        }

        function syncMarkers() {
          const show = S.ui.markers && S.ui.tab === "place" && S.edit && S.edit.kind === "array";
          const key = (show ? "1" : "0") + (S.sel || "");
          if (key === S._mk) return;
          S._mk = key;
          lua("markers", {on: !!S.ui.markers, item: show ? S.sel : false, all: false});
        }

        S.$on("BcfpProState", (e, data) => { S.$evalAsync(() => applyState(data)); });
        S.$on("BcfpProStatus", (e, data) => { S.$evalAsync(() => { S.status = data || {}; }); });
        S.$on("BcfpProScan", (e, data) => { S.$evalAsync(() => { Object.assign(S.library, data || {}); }); });
        S.$on("BcfpProLibrary", (e, data) => {
          S.$evalAsync(() => {
            S.library = data || {state: "idle", results: []};
            S.library.results = asArray(S.library.results);
            S.refilter();
          });
        });
        S.$on("BcfpProError", (e, data) => {
          S.$evalAsync(() => {
            data = data || {};
            S.err = (data.code && S.T.err[data.code]) ? fill(S.T.err[data.code], data) : data.err;
            $timeout(() => { S.err = null; }, 6000);
          });
        });

        // --------------------------------------------------------------------- apply (reload) timing
        function scheduleApply() {
          if (applyTimer) $timeout.cancel(applyTimer);
          if (!S.ui.autoApply) { applyTimer = null; return; }
          applyTimer = $timeout(() => {
            applyTimer = null;
            lua("apply");
          }, 700);
        }
        S.applyNow = () => {
          if (applyTimer) { $timeout.cancel(applyTimer); applyTimer = null; }
          lua("apply");
        };
        S.toggleAuto = () => { S.ui.autoApply = !S.ui.autoApply; remember(); if (S.ui.autoApply && S.st.pending) scheduleApply(); };
        S.toggleMarkers = () => { S.ui.markers = !S.ui.markers; remember(); S._mk = null; syncMarkers(); };

        // --------------------------------------------------------------------- control
        S.ctrl = (cmd, value) => lua("ctrl", {cmd: cmd, value: value});
        S.lightbar = () => num(S.status.lightbar, 0);
        S.modeIdx = () => num(S.status.mode, num(S.master.mode, 1));
        S.modeName = () => S.T.modes[S.modeIdx() - 1] || ("#" + S.modeIdx());
        S.setMode = (i) => { S.status.mode = i; S.ui.modeOpen = false; S.ctrl("mode", i); };

        // --------------------------------------------------------------------- zones
        S.zoneClick = (id) => {
          const zs = S.zoneState[id];
          if (!zs || zs.avail === false || zs.avail === "wait") return;
          if (zs.on) { S.select(zs.first.id); return; }
          S.wantZone = id;
          lua("zoneToggle", {zone: id});
        };
        S.zoneOff = (id) => { lua("zoneToggle", {zone: id}); if (S.edit && S.edit.anchor === id) S.sel = null; };
        S.select = (id) => { S.sel = id; S.edit = null; syncEdit(); syncMarkers(); S.ui.patOpen = false; };
        S.zoneCls = (id) => {
          const zs = (S.zoneState || {})[id] || {};
          return {off: !zs.on, on: zs.on, na: zs.avail === false, wait: zs.avail === "wait", fac: zs.avail === "factory",
                  sel: S.edit && S.edit.kind === "array" && S.edit.anchor === id};
        };
        // side chips hug the map edge so long labels never spill out of the map
        S.zoneStyle = (z) => {
          if (z.side === "l") return {top: z.top + "%", left: "3px"};
          if (z.side === "r") return {top: z.top + "%", right: "3px"};
          return {top: z.top + "%", left: z.left + "%"};
        };
        S.zoneTitle = (id) => {
          const zs = (S.zoneState || {})[id] || {};
          const t = S.zoneName(id);
          if (zs.avail === false) return t + S.T.zoneNA;
          if (zs.avail === "factory") return t + S.T.zoneFac + (zs.part ? " (" + zs.part + ")" : "");
          if (zs.avail === "scan") return t + S.T.zoneScan;
          return t;
        };
        S.kit = (id) => {
          if (id === "clear") { lua("kit", {id: "clear"}); S.sel = null; return; }
          lua("kit", {id: id, scheme: S.st.scheme, keep: !!S.ui.kitKeep, lightbar: !!S.ui.kitBar});
        };
        S.scheme = (id) => { S.st.scheme = id; lua("scheme", {id: id}); };

        // --------------------------------------------------------------------- editing the selected item
        function sendItem(fields, structural) {
          if (!S.edit) return;
          Object.keys(fields).forEach((k) => { touched["i." + k] = Date.now(); });
          lua("updateItem", {id: S.edit.id, fields: fields, apply: false});
          if (structural) scheduleApply();
        }
        S.set = (k, v) => {
          if (!S.edit) return;
          let structural = !LIVE[k];
          if (k === "colB") structural = (num(S.edit.colB) > 0) !== (num(v) > 0);
          S.edit[k] = v;
          const f = {}; f[k] = v;
          sendItem(f, structural || S.edit.kind !== "array");
        };
        // sliders: send sparsely while dragging
        S.slide = (k) => {
          if (!S.edit) return;
          touched["i." + k] = Date.now();
          if (sendTimers[k]) return;
          sendTimers[k] = $timeout(() => {
            sendTimers[k] = null;
            const f = {}; f[k] = num(S.edit[k]);
            sendItem(f, !LIVE[k] || S.edit.kind !== "array");
          }, 120);
        };
        S.setLight = (k, v) => {
          if (!S.edit) return;
          S.edit.light[k] = v;
          touched["i.light"] = Date.now();
          const live = (k === "cd" || k === "unit" || k === "lm" || k === "lux" || k === "luxd") && S.edit.kind === "array";
          const f = {}; f[k] = v;
          lua("updateItem", {id: S.edit.id, fields: {light: f}, apply: false});
          if (!live) scheduleApply();
        };
        // brightness preset (head type candela × factor)
        S.setBright = (id) => {
          if (!S.edit) return;
          S.edit.bright = id; S.edit.light.unit = 1; S.edit.light.cd = -1;
          touched["i.bright"] = touched["i.light"] = Date.now();
          lua("updateItem", {id: S.edit.id, fields: {bright: id, light: {unit: 1, cd: -1}}, apply: false});
        };
        // 0 = preset, 1 = candela, 2 = lumen, 3 = lux at a distance
        S.customUnit = () => {
          const l = (S.edit && S.edit.light) || {};
          if (num(l.unit, 1) === 2) return 2;
          if (num(l.unit, 1) === 3) return 3;
          return num(l.cd, -1) > 0 ? 1 : 0;
        };
        S.setCustom = (unit) => {
          if (!S.edit) return;
          const ph = S.photo();
          const cd = Math.max(50, Math.round(num(ph.cd, 1400) / 50) * 50);
          const f = {unit: unit};
          if (unit === 1) f.cd = num(S.edit.light.cd, -1) > 0 ? S.edit.light.cd : cd;
          if (unit === 2) f.lm = Math.max(10, Math.round(num(ph.lm, 800) / 10) * 10);
          if (unit === 3) { f.luxd = 10; f.lux = Math.max(0.5, round(cd / 100, 1)); }
          Object.assign(S.edit.light, f);
          touched["i.light"] = Date.now();
          lua("updateItem", {id: S.edit.id, fields: {light: f}, apply: false});
        };
        S.slideLight = (k) => {
          if (!S.edit) return;
          touched["i.light"] = Date.now();
          const key = "l." + k;
          if (sendTimers[key]) return;
          sendTimers[key] = $timeout(() => {
            sendTimers[key] = null;
            S.setLight(k, num(S.edit.light[k]));
          }, 120);
        };
        S.step = (k, d, lo, hi, dec) => {
          if (!S.edit) return;
          const v = clamp(round(num(S.edit[k]) + d, dec === undefined ? 1 : dec), lo, hi);
          S.set(k, v);
        };
        // spacing / distance from center: when leaving "auto" (-1) start from the real value
        S.stepAuto = (k, d, lo, hi) => {
          if (!S.edit) return;
          let cur = num(S.edit[k], -1);
          if (cur < 0) {
            const rt = (S.rtById || {})[S.edit.id] || {};
            const zi = S.zinfo[S.edit.anchor] || {};
            cur = num(rt[k], num(zi[k], k === "gap" ? 6.5 : 30));
          }
          S.set(k, clamp(round(cur + d, 1), lo, hi));
        };
        S.autoVal = (k) => {
          if (!S.edit) return "";
          const v = num(S.edit[k], -1);
          if (v >= 0) return S.fmt(v, 1);
          const rt = (S.rtById || {})[S.edit.id] || {};
          const zi = S.zinfo[S.edit.anchor] || {};
          const a = num(rt[k], num(zi[k], NaN));
          return isFinite(a) ? S.fmt(a, 1) : S.T.auto;
        };
        S.isAuto = (k) => S.edit && num(S.edit[k], -1) < 0;
        S.nudge = (k, sign) => {
          if (!S.edit) return;
          const lim = S.edit.anchor === "custom" ? 600 : 80;
          S.set(k, clamp(round(num(S.edit[k]) + sign * num(S.ui.step, 1), 1), -lim, lim));
        };
        S.nudgeAng = (k, sign) => {
          if (!S.edit) return;
          const lim = k === "yaw" ? 180 : 80;
          S.set(k, clamp(round(num(S.edit[k]) + sign * 2.5, 1), -lim, lim));
        };
        S.resetItem = () => { if (S.edit) lua("resetItem", {id: S.edit.id}); };
        S.remove = (id) => { lua("removeItem", {id: id}); if (S.sel === id) S.sel = null; };
        S.duplicate = (id) => lua("duplicateItem", {id: id});
        S.swapColors = () => {
          if (!S.edit) return;
          const f = {colL: S.edit.colR, colR: S.edit.colL, toneL: S.edit.toneR, toneR: S.edit.toneL};
          Object.assign(S.edit, f);
          sendItem(f, false);
        };
        S.setColor = (side, idx) => {
          if (!S.edit) return;
          const f = {};
          f["col" + side] = idx; f["tone" + side] = 1;
          const structural = side === "B" && (num(S.edit.colB) > 0) !== (idx > 0);
          Object.assign(S.edit, f);
          sendItem(f, structural);
        };
        S.srcOf = (it) => { const r = (S.rtById || {})[it.id]; return (r && r.src) || ""; };
        S.photo = () => (S.edit && S.st.photo && S.st.photo[S.edit.id]) || {};
        S.offsetsText = () => {
          const e = S.edit;
          if (!e) return "";
          const T = S.T;
          const p = [];
          if (num(e.x)) p.push(T.wLateral + " " + S.signed(e.x, 1) + " cm");
          if (num(e.y)) p.push(T.wDepth + " " + S.signed(e.y, 1) + " cm");
          if (num(e.z)) p.push(T.wHeight + " " + S.signed(e.z, 1) + " cm");
          if (num(e.yaw)) p.push(T.wYaw + " " + S.signed(e.yaw, 1) + "°");
          if (num(e.tilt)) p.push(T.wTilt + " " + S.signed(e.tilt, 1) + "°");
          return p.length ? p.join(" · ") : T.autoPos;
        };
        S.allArrays = (fields) => lua("allArrays", {fields: fields});

        // --------------------------------------------------------------------- global settings
        S.setMaster = (k, v, noApply) => {
          S.master[k] = v;
          touched["m." + k] = Date.now();
          const f = {}; f[k] = v;
          lua("masterSet", {fields: f, apply: !noApply});
        };
        S.slideMaster = (k) => {
          touched["m." + k] = Date.now();
          const key = "m." + k;
          if (sendTimers[key]) $timeout.cancel(sendTimers[key]);
          sendTimers[key] = $timeout(() => {
            sendTimers[key] = null;
            const f = {}; f[k] = num(S.master[k]);
            lua("masterSet", {fields: f, apply: true});
          }, 250);
        };

        // --------------------------------------------------------------------- light studio
        S.gselect = (key) => { S.gsel = key; S.sedit = null; syncStudio(); };
        S.sset = (k, v) => {
          if (!S.sedit) return;
          if (v !== undefined) S.sedit[k] = v;
          touched["s." + k] = Date.now();
          const key = "s";
          if (sendTimers[key]) $timeout.cancel(sendTimers[key]);
          sendTimers[key] = $timeout(() => {
            sendTimers[key] = null;
            const p = angular.copy(S.sedit);
            delete p.__key;
            lua("studioSet", {key: S.gsel, params: p, all: S.gsel === "*"});
          }, 140);
        };
        S.sreset = () => { lua("studioReset", S.gsel === "*" ? {} : {key: S.gsel}); S.sedit = null; };
        S.warnGroups = () => S.groups.filter((g) => g.kind !== "veh");

        // --------------------------------------------------------------------- lightbar / copies / library
        S.addBar = (len) => lua("addItem", {kind: "mlbar", item: {len: len, anchor: "roof"}});
        S.copyInstalled = (part) => lua("copyInstalled", {part: part, count: num(S.ui.copies, 1)});
        S.copyLibrary = (entry) => lua("copyLibrary", {entry: {part: entry.part, ns: entry.ns, file: entry.file, name: entry.name},
          count: num(S.ui.copies, 1), roof: true});
        S.scan = (deep) => lua("scan", {deep: !!deep});
        S.refilter = () => {
          const f = (S.ui.filter || "").toLowerCase();
          const res = S.library.results || [];
          S.libFiltered = (f ? res.filter((r) => ((r.name || "") + " " + (r.part || "") + " " + (r.model || "")).toLowerCase().indexOf(f) >= 0) : res).slice(0, 120);
        };
        S.toggleDisable = (code) => {
          if (!S.edit || S.edit.kind !== "mlbar") return;
          S.edit.disable[code] = !S.edit.disable[code];
          sendItem({disable: S.edit.disable}, true);
        };

        // --------------------------------------------------------------------- profiles / automatic
        S.profileSave = (global) => {
          const name = ((global ? S.ui.globalName : S.ui.profileName) || "").trim();
          if (!name) return;
          lua("profileSave", {name: name, global: !!global});
          if (global) S.ui.globalName = ""; else S.ui.profileName = "";
        };
        S.profileLoad = (name, global) => lua("profileLoad", {name: name, global: !!global});
        S.profileDelete = (name, global) => lua("profileDelete", {name: name, global: !!global});
        S.setAuto = (f) => { Object.assign(S.st.auto || {}, f); lua("auto", f); };
        S.clearAll = () => { lua("clearAll"); S.sel = null; };
        S.rescan = () => lua("rescan");

        // --------------------------------------------------------------------- life cycle
        lua("hello");
        const ping = $interval(() => lua("ping"), 9000);
        S.$on("$destroy", () => {
          $interval.cancel(ping);
          lua("markers", {on: false, item: false});
          lua("bye");
        });
      },
    };
  }]);
})();
