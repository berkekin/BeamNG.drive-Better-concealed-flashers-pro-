Better Concealed Flashers PRO 3 — Concealed Flashers PRO / Gizli Çakar PRO
==========================================================================

EN  Put this zip, unextracted, into  %LOCALAPPDATA%\BeamNG\BeamNG.drive\current\mods\
    In game add the UI app "Concealed Flashers PRO", get into any vehicle and click a zone or a kit.
    TR / EN language switch in the app header. Settings are saved with the vehicle configuration.

TR  Bu zip'i açmadan  %LOCALAPPDATA%\BeamNG\BeamNG.drive\current\mods\  klasörüne koy.
    Oyunda "Gizli Çakar PRO" arayüz uygulamasını ekle, herhangi bir araca bin, bir bölgeye ya da kite tıkla.
    Dil: uygulamanın üst şeridindeki TR / EN düğmesi. Ayarlar aracın konfigürasyonuyla birlikte kaydedilir.
