-- Better Concealed Flashers PRO 3: loads the game-engine extension / oyun motoru eklentisini yukler
setExtensionUnloadMode("bcfpPro", "manual")
if extensions.isExtensionLoaded("bcfpPro") then
  extensions.reload("bcfpPro")
else
  extensions.load("bcfpPro")
end
