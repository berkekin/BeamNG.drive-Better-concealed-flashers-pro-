-- Better Concealed Flashers PRO 3 - canli isik ayari (arac tarafi eklenti)
-- Isik Studyosu'ndan gelen degerleri aracin isik (prop) verisine ve lens parlamasi tetikleyicilerine yazar.
-- Isiklari arac yeniden yuklenmeden aninda gunceller.
local M = {}

local pidMap = nil

local function buildMap()
  pidMap = {}
  for _, p in pairs(v.data.props or {}) do
    if type(p) == 'table' and p.pid then pidMap[p.pid] = p end
  end
end

local function apply(payload)
  if type(payload) ~= 'table' then return end
  if not pidMap then buildMap() end
  local refreshCtrl = false
  for _, u in ipairs(payload.props or {}) do
    local p = pidMap[u.pid]
    if p then
      if type(u.b) == 'number' then p.lightBrightness = u.b end
      if type(u.f) == 'number' then p.flareScale = u.f end
      if u.ph ~= 1 and type(u.c) == 'table' then
        p.lightColor = {r = u.c[1], g = u.c[2], b = u.c[3], a = u.c[4] or 255}
      end
      p.lastVal = math.huge
      if u.ph == 1 then refreshCtrl = true end
    end
  end
  local gl = payload.glow
  local mats = v.data._materials
  if type(gl) == 'table' and next(gl) and mats and mats.triggers then
    for _, t in pairs(mats.triggers) do
      local g = gl[t.orgMat]
      if g then
        if type(g.on) == 'string' then t.on = g.on end
        if type(g.m) == 'number' then
          t.scaleEmissiveMaterial = true
          t.scaleEmissiveMaterialOnMax = g.m
        end
      end
    end
    if material and material.forceReset then material.forceReset() end
  end
  if refreshCtrl then
    for _, c in pairs(controller.getControllersByType('bcfp_flasher')) do
      if c.bcfpRefresh then c.bcfpRefresh() end
    end
  end
end

local function onReset()
  pidMap = nil
end

M.apply = apply
M.onReset = onReset
M.onExtensionLoaded = function() pidMap = nil end

return M
