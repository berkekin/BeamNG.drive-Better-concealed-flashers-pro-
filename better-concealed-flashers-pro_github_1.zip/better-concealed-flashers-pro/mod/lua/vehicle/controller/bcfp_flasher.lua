-- Better Concealed Flashers PRO 3 - desen motoru (arac tarafi controller)
-- Iki rolde calisir:
--   role = "master" : gizli LED bolgelerini (bcfpZones), far wig-wag'i ve mod yonetimini yapar
--   role = "mlbar"  : multicolor hoparlorlu LED bar(lar)i (bcfpML) surer; master varsa onun modunu izler
-- Oyunun kendi lightbar dugmesi (electrics.values.lightbar 0/1/2) sistemi acar/kapatir, 2 = siren.
-- Ayni aracta birden fazla ornek varsa lider: master, yoksa adi en kucuk mlbar.

local M = {}
M.type = "auxiliary"

local min, max, floor, abs = math.min, math.max, math.floor, math.abs

-----------------------------------------------------------------------------------------------
-- Desen kutuphanesi: L ve R kanali, {deger, sure(sn)} adimlari (hiz = 1 iken)
-----------------------------------------------------------------------------------------------
local function rep(t, n)
  local out = {}
  for _ = 1, n do for _, s in ipairs(t) do out[#out + 1] = s end end
  return out
end

local function cat(...)
  local out = {}
  for _, t in ipairs({...}) do for _, s in ipairs(t) do out[#out + 1] = s end end
  return out
end

-- orijinal "Better Concealed Flashers" (Modern Undercover Lights 2.2) dizileri
local ORIG_RED   = {{0,.1},{1,.3},{0,.1},{1,.15},{0,.1},{1,.15},{0,.2},{1,.1},{0,.25}}
local ORIG_BLUE  = {{1,.15},{0,.2},{1,.1},{0,.25},{1,.1},{0,.1},{1,.3},{0,.1},{1,.15}}
local ORIG_W1    = {{1,.1},{0,.3},{1,.1},{0,.15},{1,.1},{0,.15},{1,.2},{0,.1},{1,.25}}
local ORIG_W2    = {{0,.15},{1,.2},{0,.1},{1,.25},{0,.1},{1,.1},{0,.3},{1,.1},{1,.15}}

local DOUBLE_L = {{1,.06},{0,.06},{1,.06},{0,.42}}
local DOUBLE_R = {{0,.30},{1,.06},{0,.06},{1,.06},{0,.12}}
local TRIPLE_L = {{1,.05},{0,.04},{1,.05},{0,.04},{1,.05},{0,.42}}
local TRIPLE_R = {{0,.325},{1,.05},{0,.04},{1,.05},{0,.04},{1,.05},{0,.095}}
local QUAD_L   = cat(rep({{1,.04},{0,.035}}, 4), {{0,.40}})
local QUAD_R   = cat({{0,.35}}, rep({{1,.04},{0,.035}}, 4), {{0,.05}})
local ECE      = {{1,.05},{0,.05},{1,.05},{0,.35}}
local STROBE_L = {{1,.03},{0,.07},{1,.03},{0,.37}}
local STROBE_R = {{0,.25},{1,.03},{0,.07},{1,.03},{0,.12}}
local QFAST_L  = cat(rep({{1,.025},{0,.025}}, 4), {{0,.2}})
local QFAST_R  = cat({{0,.2}}, rep({{1,.025},{0,.025}}, 4))

local RAW = {
  orig      = {L = ORIG_RED, R = ORIG_BLUE},
  orig_w    = {L = ORIG_W1,  R = ORIG_W2},
  double    = {L = DOUBLE_L, R = DOUBLE_R},
  triple    = {L = TRIPLE_L, R = TRIPLE_R},
  quad      = {L = QUAD_L,   R = QUAD_R},
  single    = {L = {{1,.25},{0,.25}}, R = {{0,.25},{1,.25}}},
  fast      = {L = {{1,.05},{0,.15}}, R = {{0,.10},{1,.05},{0,.05}}},
  simdouble = {L = DOUBLE_L, R = DOUBLE_L},
  ece       = {L = ECE, R = ECE},
  combo     = {L = cat(DOUBLE_L, DOUBLE_L, QUAD_L, QUAD_L), R = cat(DOUBLE_R, DOUBLE_R, QUAD_R, QUAD_R)},
  combo2    = {L = cat(DOUBLE_L, DOUBLE_L, TRIPLE_L, TRIPLE_L), R = cat(DOUBLE_R, DOUBLE_R, TRIPLE_R, TRIPLE_R)},
  scene     = {L = {{1,.5},{0,.5}}, R = {{0,.5},{1,.5}}},
  slow      = {L = {{1,.8},{0,.8}}, R = {{0,.8},{1,.8}}},
  steady    = {L = {{1,1}}, R = {{1,1}}},
  off       = {L = {{0,1}}, R = {{0,1}}},
  alt_w     = {L = {{1,.25},{0,.25}}, R = {{0,.25},{1,.25}}},
  wig_orig  = {L = {{1,.4},{0,.4}}, R = {{0,.4},{1,.4}}},
  wig_fast  = {L = {{1,.2},{0,.2}}, R = {{0,.2},{1,.2}}},
  strobe    = {L = STROBE_L, R = STROBE_R},
  qfast     = {L = QFAST_L, R = QFAST_R},
  -- "steady burn": sol sabit yanar, sag cift flas (Kaliforniya tipi on kirmizi)
  calsteady = {L = {{1,1}}, R = {{1,.06},{0,.06},{1,.06},{0,.32}}},
  -- hiper flas: 12 Hz donusumlu
  hyper     = {L = {{1,.042},{0,.042}}, R = {{0,.042},{1,.042}}},
  -- uclu flas + tek uzun
  tripleone = {L = cat(TRIPLE_L, {{1,.22},{0,.28}}), R = cat(TRIPLE_R, {{0,.25},{1,.22},{0,.03}})},
  -- es zamanli dortlu (iki yan birlikte)
  simquad   = {L = QUAD_L, R = QUAD_L},
  -- yavas donusumlu (1 Hz; ikaz / yol calismasi)
  beacon    = {L = {{1,.5},{0,.5}}, R = {{0,.5},{1,.5}}},
}

-- bolge basina desen secimi (arayuzdeki "Desen" listesi; 0 = moda gore)
local PATTERN_BY_INDEX = {"orig", "double", "triple", "quad", "single", "fast", "simdouble", "ece", "combo", "scene",
                          "steady", "off", "strobe", "qfast", "combo2", "slow", "calsteady", "hyper", "tripleone", "simquad", "beacon"}

local function compileSeq(steps)
  local s = {v = {}, t = {}, T = 0}
  for i, st in ipairs(steps) do
    s.T = s.T + max(st[2], 0.001)
    s.v[i] = st[1]
    s.t[i] = s.T
  end
  return s
end

local PAT = {}
for name, p in pairs(RAW) do PAT[name] = {L = compileSeq(p.L), R = compileSeq(p.R)} end

local function seqValue(seq, time)
  local tm = time % seq.T
  local t, v = seq.t, seq.v
  for i = 1, #t do if tm < t[i] then return v[i] end end
  return v[#v]
end

-----------------------------------------------------------------------------------------------
-- Modlar (GE arayuzundeki liste ile ayni sira)
-- color: gizli renkli bolgeler, white: beyaz bolgeler, phaseB: B grubuna faz kaymasi, cruise: seyir seviyesi,
-- wig: far wig-wag deseni, ml: LED bar deseni, tkd/aly/fld: LED bar alt sira beyazlari
-----------------------------------------------------------------------------------------------
local MODES = {
  {name = "Normal (Orijinal)",  color = "orig",   white = "orig_w", phaseB = 0,   wig = "wig_orig", ml = "orig"},
  {name = "Takip - Cift Flas",  color = "double", white = "off",    phaseB = 0.5, wig = "single",   ml = "double"},
  {name = "Takip - Dortlu",     color = "quad",   white = "off",    phaseB = 0.5, wig = "single",   ml = "quad"},
  {name = "Takip - Hizli",      color = "fast",   white = "off",    phaseB = 0.5, wig = "wig_fast", ml = "fast"},
  {name = "Karisik (Combo)",    color = "combo",  white = "off",    phaseB = 0.5, wig = "single",   ml = "combo"},
  {name = "Takedown",           color = "orig",   white = "steady", phaseB = 0,   wig = "wig_orig", ml = "split", tkd = true},
  {name = "Sahne / Park",       color = "scene",  white = "steady", phaseB = 0.5, wig = nil,        ml = "scene", tkd = true, aly = true, fld = true},
  {name = "Seyir 1 (Sabit)",    color = "steady", white = "steady", phaseB = 0,   wig = nil,        ml = "steady", cruise = true},
  {name = "Seyir 2",            color = "steady", white = "alt_w",  phaseB = 0,   wig = nil,        ml = "steady", cruise = true},
  {name = "Trafik Ok - Sol",    color = "double", white = "off",    phaseB = 0.5, wig = nil,        ml = "arrowL"},
  {name = "Trafik Ok - Sag",    color = "double", white = "off",    phaseB = 0.5, wig = nil,        ml = "arrowR"},
  {name = "Trafik Ok - Orta",   color = "double", white = "off",    phaseB = 0.5, wig = nil,        ml = "arrowC"},
  {name = "Avrupa (ECE)",       color = "ece",    white = "off",    phaseB = 0,   wig = nil,        ml = "ece"},
  {name = "Dalga",              color = "triple", white = "off",    phaseB = 0.5, wig = "single",   ml = "wave"},
  {name = "Tam Beyaz Aydinlatma", color = "off",  white = "steady", phaseB = 0,   wig = nil,        ml = "white", tkd = true, aly = true, fld = true},
  {name = "Tarama (Soldan Saga)", color = "double", white = "off",  phaseB = 0.5, wig = "single",   ml = "scan"},
  {name = "Tarama (Ping-Pong)", color = "double", white = "off",    phaseB = 0.5, wig = "single",   ml = "pingpong"},
  {name = "Capraz",             color = "quad",   white = "off",    phaseB = 0.5, wig = "single",   ml = "cross"},
  {name = "Donen Isik (360)",   color = "single", white = "off",    phaseB = 0.5, wig = nil,        ml = "rotate"},
  {name = "Ortadan Disa",       color = "triple", white = "off",    phaseB = 0.5, wig = "single",   ml = "centerOut"},
  {name = "Disten Ortaya",      color = "triple", white = "off",    phaseB = 0.5, wig = "single",   ml = "outCenter"},
  {name = "Xenon Strobe",       color = "strobe", white = "off",    phaseB = 0.5, wig = "wig_fast", ml = "strobe"},
  {name = "Hizli Dortlu Strobe", color = "qfast", white = "off",    phaseB = 0.5, wig = "wig_fast", ml = "qfast"},
  {name = "Yavas Dalga",        color = "slow",   white = "off",    phaseB = 0.5, wig = nil,        ml = "slowWave"},
  {name = "Rastgele Pirilti",   color = "fast",   white = "off",    phaseB = 0.5, wig = "single",   ml = "sparkle"},
  {name = "Cift + Uclu",        color = "combo2", white = "off",    phaseB = 0.5, wig = "single",   ml = "combo2"},
  {name = "Sabit + Cakar (Steady Burn)", color = "calsteady", white = "off", phaseB = 0, wig = "single", ml = "double"},
  {name = "Hiper Flas",         color = "hyper",  white = "off",    phaseB = 0.5, wig = "wig_fast", ml = "fast"},
  {name = "Uclu + Tek",         color = "tripleone", white = "off", phaseB = 0.5, wig = "single",   ml = "triple"},
  {name = "Es Zamanli Dortlu",  color = "simquad", white = "off",   phaseB = 0,   wig = "single",   ml = "quad"},
  {name = "Yavas Ikaz (1 Hz)",  color = "beacon", white = "off",    phaseB = 0,   wig = nil,        ml = "scene"},
}

-----------------------------------------------------------------------------------------------
-- Durum
-----------------------------------------------------------------------------------------------
local role = "master"
local cfg = {}

-- bildirim dili ('tr' | 'en'): GE tarafi uretilen parcaya yazar, arayuzden canli degisir
local lang = "tr"
local MODE_NAMES = {
  tr = {"Normal (Orijinal)", "Takip – Çift Flaş", "Takip – Dörtlü", "Takip – Hızlı", "Karışık (Combo)", "Takedown",
        "Sahne / Park", "Seyir 1 (Sabit)", "Seyir 2", "Trafik Oku – Sol", "Trafik Oku – Sağ", "Trafik Oku – Orta",
        "Avrupa (ECE)", "Dalga", "Tam Beyaz Aydınlatma", "Tarama (Soldan Sağa)", "Tarama (Ping-Pong)", "Çapraz",
        "Dönen Işık (360°)", "Ortadan Dışa", "Dıştan Ortaya", "Xenon Strobe", "Hızlı Dörtlü Strobe", "Yavaş Dalga",
        "Rastgele Pırıltı", "Çift + Üçlü", "Sabit + Çakar (Steady Burn)", "Hiper Flaş", "Üçlü + Tek", "Eş Zamanlı Dörtlü",
        "Yavaş İkaz (1 Hz)"},
  en = {"Normal (Original)", "Pursuit – Double Flash", "Pursuit – Quad", "Pursuit – Fast", "Mixed (Combo)", "Takedown",
        "Scene / Park", "Cruise 1 (Steady)", "Cruise 2", "Traffic Advisor – Left", "Traffic Advisor – Right", "Traffic Advisor – Center",
        "European (ECE)", "Wave", "Full White Flood", "Scan (Left to Right)", "Scan (Ping-Pong)", "Cross",
        "Rotator (360°)", "Center Out", "Outside In", "Xenon Strobe", "Fast Quad Strobe", "Slow Wave",
        "Random Sparkle", "Double + Triple", "Steady Burn + Flash", "Hyper Flash", "Triple + Single", "Simultaneous Quad",
        "Slow Beacon (1 Hz)"},
}
local TXT = {
  tr = {app = "Gizli Çakar PRO", night = "Gece seviyesi", day = "Gündüz seviyesi", tkdOn = "Takedown ışıkları AÇIK",
        tkdOff = "Takedown ışıkları KAPALI", alyOn = "Yan aydınlatma (alley) AÇIK", alyOff = "Yan aydınlatma (alley) KAPALI",
        qNight = "Gece seviyesi", qDay = "Gündüz seviyesi", qTkdOn = "Takedown aç", qTkdOff = "Takedown kapat",
        qAlyOn = "Yan aydınlatma aç", qAlyOff = "Yan aydınlatma kapat"},
  en = {app = "Concealed Flashers PRO", night = "Night level", day = "Day level", tkdOn = "Takedown lights ON",
        tkdOff = "Takedown lights OFF", alyOn = "Alley lights ON", alyOff = "Alley lights OFF",
        qNight = "Night level", qDay = "Day level", qTkdOn = "Takedown on", qTkdOff = "Takedown off",
        qAlyOn = "Alley lights on", qAlyOff = "Alley lights off"},
}
local function T(k) return (TXT[lang] or TXT.en)[k] or k end
local function modeName(i)
  local list = MODE_NAMES[lang] or MODE_NAMES.en
  return list[i] or (MODES[i] and MODES[i].name) or tostring(i)
end
local zones = {}
local mlMods = {}
local mlProps = {}
local mlWhite = {}
local allElectrics = {}
local modeIndex = 1
local time = 0
local active = false
local night = false
local tkdToggle = false
local alyToggle = false
local hasRegisteredQuickAccess = false
local registerQuickAccess
local stateData
local stateKeyMode, stateKeyFlags
local disabledColors = {}
local statusDirty = true
local statusT = 0
local lastLb = -1
local mlDriver = nil

local ML_CODES = {"r", "b", "w", "a"} -- 1 kirmizi, 2 mavi, 3 beyaz, 4 amber
-- gercekci LED paleti (dogrusal), Y = bagil parlaklik (fotometrik dengeleme icin)
local ML_COLOR_LIN = {
  r = {1.0, 0.0, 0.015},
  b = {0.0, 0.0747, 1.0},
  w = {1.0, 0.901, 0.8766},
  a = {1.0, 0.2305, 0.0},
}
local ML_COLOR_Y = {r = 0.2138, b = 0.1256, w = 0.9203, a = 0.3775}

local function num(v, d)
  v = tonumber(v)
  if v == nil or v ~= v then return d end
  return v
end

local function siblings()
  local list = controller.getControllersByType("bcfp_flasher") or {}
  return list
end

-- lider: master; yoksa adi en kucuk mlbar
local function getLeader()
  local best, bestName
  for _, c in ipairs(siblings()) do
    if type(c.bcfpIsMaster) == "function" then
      if c.bcfpIsMaster() then return c end
      local n = tostring(c.name)
      if not bestName or n < bestName then best, bestName = c, n end
    end
  end
  return best or M
end

local function isLeader()
  return getLeader() == M
end

-- LED bar elektriklerini tek bir ornek surer: adi en kucuk mlbar; mlbar yoksa master
local function isMLDriver()
  local best, bestName
  for _, c in ipairs(siblings()) do
    if type(c.bcfpRole) == "function" and c.bcfpRole() == "mlbar" then
      local n = tostring(c.name)
      if not bestName or n < bestName then best, bestName = c, n end
    end
  end
  if best then return best == M end
  return role == "master"
end

local function getMaster()
  local l = getLeader()
  if l == M then return M end
  return l
end

local function setE(name, val)
  if name and name ~= "" then electrics.values[name] = val end
end

local function zeroAll()
  for name in pairs(allElectrics) do electrics.values[name] = 0 end
  for _, p in pairs(mlProps) do p.lastKey = nil end
end

local function currentMode()
  return MODES[modeIndex] or MODES[1]
end

local function isNightNow()
  local m = getMaster()
  local n = night
  if m and m ~= M then n = m.bcfpGetNight() end
  if num(cfg.autoNight, 0) >= 0.5 and (electrics.values.bcfp_env_night or 0) >= 0.5 then n = not n end
  return n
end

local function globalLevel()
  if isNightNow() then return num(cfg.nightLevel, 0.35) end
  return num(cfg.dayLevel, 1)
end

-----------------------------------------------------------------------------------------------
-- Gizli LED bolgeleri
-----------------------------------------------------------------------------------------------
local function updateZones(mode, lvl)
  local m = getMaster()
  local tkdOn = tkdToggle or (m and m ~= M and m.bcfpGetTkd())
  local ml = mode.ml
  local arrow = (ml == "arrowL" or ml == "arrowR" or ml == "arrowC") and ml or nil
  local cruiseLvl = num(cfg.cruiseLevel, 0.2)
  local front = 2
  if arrow then
    local u = time % 1.0
    if u < 0.75 then front = u / 0.75 end
  end
  for _, z in ipairs(zones) do
    local patName
    if z.pat > 0 and PATTERN_BY_INDEX[z.pat] then
      patName = PATTERN_BY_INDEX[z.pat]
    elseif z.kind == "white" then
      patName = mode.white
    else
      patName = mode.color
    end
    local p = PAT[patName] or PAT.off
    if z.kind == "white" and patName == "orig" then p = PAT.orig_w end
    local ph = z.phase + ((z.grp == "B") and (mode.phaseB or 0) or 0)
    local tz = time + ph * p.L.T
    local sL, sR = p.L, p.R
    if z.side == 1 then sR = sL
    elseif z.side == 2 then sL, sR = sR, sL end
    if ml == "cross" and z.grp == "B" then sL, sR = sR, sL end
    local vl, vr = seqValue(sL, tz), seqValue(sR, tz)
    local full = lvl * z.lvl
    local k = full
    if mode.cruise then k = k * cruiseLvl end
    local al, ar, bl, br = vl * k, vr * k, 0, 0
    if z.kind == "white" and tkdOn then al, ar = full, full end
    if arrow and z.adv and z.face == "R" then
      -- trafik oku: arkaya bakan uye bolgeler, yanal konumlarina gore sirayla yanar
      local onL, onR = false, false
      if front <= 1 then
        local pos = z.xn
        if arrow == "arrowL" then
          onL, onR = ((pos + 1) / 2) <= front + 0.001, ((1 - pos) / 2) <= front + 0.001
        elseif arrow == "arrowR" then
          onL, onR = ((1 - pos) / 2) <= front + 0.001, ((pos + 1) / 2) <= front + 0.001
        else
          onL = pos <= front + 0.001
          onR = onL
        end
      end
      if z.hasB and z.bfn == 4 then
        al, ar, bl, br = 0, 0, onL and full or 0, onR and full or 0
      else
        al, ar = onL and full or 0, onR and full or 0
      end
    elseif z.hasB then
      local f = z.bfn
      if f == 1 then
        if tkdOn or mode.tkd then al, ar, bl, br = 0, 0, full, full end
      elseif f == 2 then
        if mode.tkd or mode.fld then al, ar, bl, br = 0, 0, full, full end
      elseif f == 3 then
        -- donusumlu: ana rengin sonuk oldugu anlarda ikinci renk ayni deseni yarim periyot kayik calar
        local tb = tz + 0.5 * p.L.T
        if al <= 0 then bl = seqValue(sL, tb) * k end
        if ar <= 0 then br = seqValue(sR, tb) * k end
      elseif f == 5 then
        if mode.cruise then al, ar, bl, br = 0, 0, full * cruiseLvl, full * cruiseLvl end
      end
    end
    setE(z.eL, al)
    setE(z.eR, ar)
    if z.hasB then
      setE(z.eL2, bl)
      setE(z.eR2, br)
    end
  end
end

local function updateWigwag(mode)
  if num(cfg.wigwag, 1) < 0.5 or not mode.wig then
    electrics.values.wigwag_L = 0
    electrics.values.wigwag_R = 0
    return
  end
  local p = PAT[mode.wig] or PAT.wig_orig
  electrics.values.wigwag_L = seqValue(p.L, time) >= 0.5 and 1 or 0
  electrics.values.wigwag_R = seqValue(p.R, time) >= 0.5 and 1 or 0
end

-----------------------------------------------------------------------------------------------
-- Multicolor LED bar
-----------------------------------------------------------------------------------------------
local function mlColorCode(idx, default)
  idx = floor(num(idx, 0))
  return ML_CODES[idx] or default
end

-- modulun bar uzerindeki konumu: xn (0 sol uc .. 1 sag uc), ring (360 derece sira)
local function modGeometry(mod)
  local n = max(mod.n, 1)
  if mod.face == "E" then
    mod.xn = (mod.side == "L") and 0 or 1
  else
    if mod.side == "L" then mod.xn = (n - mod.k + 0.5) / (2 * n) else mod.xn = (n + mod.k - 0.5) / (2 * n) end
  end
end

local function sidePattern(mod, patName, t, colA, colB)
  local p = PAT[patName] or PAT.double
  local seq = (mod.side == "L") and p.L or p.R
  local v = seqValue(seq, t)
  if v <= 0 then return nil, 0 end
  return (mod.side == "L") and colA or colB, v
end

local function hash01(a, b)
  local h = (a * 73856093 + b * 19349663) % 1000003
  return (h % 1000) / 1000
end

local function mlEval(mode, t, colA, colB, colC, arrowCol)
  local ml = mode.ml or "double"
  local res = {}
  if ml == "off" then return res end
  local nMax = 1
  for _, mod in ipairs(mlMods) do nMax = max(nMax, mod.n) end
  for i, mod in ipairs(mlMods) do
    local c, v = nil, 0
    local sideCol = (mod.side == "L") and colA or colB
    if ml == "steady" then
      c, v = sideCol, 1
    elseif ml == "white" then
      c, v = "w", 1
    elseif ml == "split" then
      local inner = mod.face == "E" or mod.k <= math.ceil(mod.n / 2)
      if inner then
        c, v = sidePattern(mod, "double", t, colA, colB)
      else
        local p = PAT.double
        local seq = (mod.side == "L") and p.R or p.L
        v = seqValue(seq, t)
        c = v > 0 and colC or nil
      end
    elseif ml == "wave" or ml == "slowWave" then
      local P = (ml == "wave") and 0.9 or 1.8
      local u = (t % P) / P
      local half = (mod.side == "L") and 0 or 0.5
      local local01 = (u - half)
      if local01 >= 0 and local01 < 0.5 then
        local steps = mod.n + 1
        local step = floor(local01 / 0.5 * (steps + 1))
        local kk = (mod.face == "E") and steps or mod.k
        if kk <= step then c, v = sideCol, 1 end
      end
    elseif ml == "scan" or ml == "pingpong" then
      local P = 1.1
      local u = (t % P) / P
      if ml == "pingpong" then u = (u < 0.5) and (u * 2) or (2 - u * 2) end
      local w = 0.5 / max(nMax, 1) + 0.04
      if abs(mod.xn - u) < w then c, v = sideCol, 1 end
    elseif ml == "centerOut" or ml == "outCenter" then
      local P = 0.8
      local u = (t % P) / P
      local d = abs(mod.xn - 0.5) * 2
      if ml == "outCenter" then d = 1 - d end
      if d <= u + 0.001 and d >= u - 0.35 then c, v = sideCol, 1 end
    elseif ml == "rotate" then
      -- 360: on yuz soldan saga, sag uc, arka yuz sagdan sola, sol uc
      local P = 0.75
      local u = (t % P) / P
      local ring
      if mod.face == "F" then ring = mod.xn * 0.45
      elseif mod.face == "B" then ring = 0.5 + (1 - mod.xn) * 0.45
      elseif mod.side == "R" then ring = 0.475
      else ring = 0.975 end
      local d = abs(ring - u)
      d = min(d, 1 - d)
      if d < 0.12 then c, v = (u < 0.5) and colA or colB, 1 end
    elseif ml == "cross" then
      local p = PAT.quad
      local useL = (mod.side == "L") == (mod.face ~= "B")
      local seq = useL and p.L or p.R
      v = seqValue(seq, t)
      c = v > 0 and sideCol or nil
    elseif ml == "sparkle" then
      local slot = floor(t * 9)
      local h = hash01(i, slot)
      if h < 0.33 then c, v = sideCol, 1 end
    elseif ml == "arrowL" or ml == "arrowR" or ml == "arrowC" then
      if mod.face == "B" then
        local pos = (mod.side == "L" and 1 or -1) * (mod.k / max(mod.n, 1))
        local P = 1.0
        local u = (t % P) / P
        local front
        if u < 0.75 then front = u / 0.75 else front = 2 end
        local lit = false
        if ml == "arrowL" then
          lit = front <= 1 and ((pos + 1) / 2) <= front + 0.001
        elseif ml == "arrowR" then
          lit = front <= 1 and ((1 - pos) / 2) <= front + 0.001
        else
          lit = front <= 1 and abs(pos) <= front + 0.001
        end
        if lit then c, v = arrowCol, 1 end
      else
        c, v = sidePattern(mod, "double", t, colA, colB)
      end
    else
      c, v = sidePattern(mod, ml, t, colA, colB)
    end
    if c and disabledColors[c] then c, v = nil, 0 end
    res[i] = {c = c, v = v}
  end
  return res
end

local function updateML(mode, lvl)
  if #mlMods == 0 then return end
  local colA = mlColorCode(cfg.colA, "r")
  local colB = mlColorCode(cfg.colB, "b")
  local colC = mlColorCode(cfg.colC, "w")
  local arrowCol = mlColorCode(cfg.arrowCol, "a")
  local cruiseK = mode.cruise and num(cfg.cruiseLevel, 0.25) or 1
  local res = mlEval(mode, time, colA, colB, colC, arrowCol)
  local k = lvl * num(cfg.mlLevel, 1) * cruiseK
  local groupState = {}
  for i, mod in ipairs(mlMods) do
    local r = res[i]
    for _, code in ipairs(ML_CODES) do
      local on = r and r.c == code
      setE(mod.e[code], on and (r.v * k) or 0)
    end
    if r and r.c then
      local gkey = mod.side .. "_" .. mod.face
      local g = groupState[gkey]
      if not g then
        groupState[gkey] = {c = r.c, v = r.v * k, n = 1}
      else
        g.n = g.n + 1
        if r.v * k > g.v then g.v = r.v * k end
      end
    end
  end
  local photometric = num(cfg.photometric, 1) >= 0.5
  for key, p in pairs(mlProps) do
    local g = groupState[key]
    if g and g.v > 0.001 then
      setE(p.func, 1)
      local q = floor(g.v * 20 + 0.5) / 20
      local lk = g.c .. q
      if p.lastKey ~= lk then
        p.lastKey = lk
        local lin = ML_COLOR_LIN[g.c] or ML_COLOR_LIN.w
        local comp = photometric and (1 / max(ML_COLOR_Y[g.c] or 1, 0.05)) or 1
        local col = color(floor(lin[1] * 255 + 0.5), floor(lin[2] * 255 + 0.5), floor(lin[3] * 255 + 0.5), 255)
        for _, pr in ipairs(p.props) do
          if pr.pid then
            obj:setPropLight(pr.pid, (pr.lightBrightness or 1) * q * comp, (pr.flareScale or 0) * (q > 0.6 and 1 or 0), col)
          end
        end
      end
    else
      setE(p.func, 0)
      p.lastKey = nil
    end
  end
  local m = getMaster()
  local tkd = mode.tkd or tkdToggle or (m and m ~= M and m.bcfpGetTkd())
  local aly = mode.aly or alyToggle or (m and m ~= M and m.bcfpGetAly())
  local fld = mode.fld
  local wk = lvl * num(cfg.mlWhiteLevel, 1)
  for _, w in ipairs(mlWhite) do
    local on = (w.kind == "tkd" and tkd) or (w.kind == "aly" and aly) or (w.kind == "fld" and fld)
    setE(w.e, on and wk or 0)
  end
end

-----------------------------------------------------------------------------------------------
-- GE'ye durum bildirimi (arayuz icin)
-----------------------------------------------------------------------------------------------
local function sendStatus()
  if not isLeader() then return end
  local names = {}
  for i, md in ipairs(MODES) do names[i] = md.name end
  local st = {mode = modeIndex, night = night, tkd = tkdToggle, aly = alyToggle, lightbar = electrics.values.lightbar or 0,
              autoNight = num(cfg.autoNight, 0) >= 0.5, envNight = (electrics.values.bcfp_env_night or 0) >= 0.5,
              modes = names, role = role, speed = num(cfg.speed, 1)}
  obj:queueGameEngineLua("if bcfpPro then bcfpPro.onVehicleStatus(" .. tostring(obj:getId()) .. "," .. serialize(st) .. ") end")
end

-----------------------------------------------------------------------------------------------
-- Ana dongu
-----------------------------------------------------------------------------------------------
local function updateGFX(dt)
  statusT = statusT + dt
  local lb = electrics.values.lightbar or 0
  if lb ~= lastLb then
    lastLb = lb
    statusDirty = true
  end
  if statusDirty and statusT > 0.25 then
    statusT = 0
    statusDirty = false
    sendStatus()
  end
  if not hasRegisteredQuickAccess and isLeader() then registerQuickAccess(cfg.cid) end
  if lb <= 0 then
    if active then
      zeroAll()
      if role == "master" then
        electrics.values.wigwag_L = 0
        electrics.values.wigwag_R = 0
      end
      active = false
    end
    return
  end
  if not active then
    active = true
    time = 0
  end
  local master = getMaster()
  if master and master ~= M then
    modeIndex = master.bcfpGetMode()
    time = master.bcfpGetTime()
  else
    time = time + dt * max(num(cfg.speed, 1), 0.05)
  end
  local mode = currentMode()
  local lvl = globalLevel()
  if role == "master" then
    updateZones(mode, lvl)
    updateWigwag(mode)
  end
  if mlDriver == nil then mlDriver = isMLDriver() end
  if mlDriver then updateML(mode, lvl) end
end

-----------------------------------------------------------------------------------------------
-- Mod / ac-kapa fonksiyonlari
-----------------------------------------------------------------------------------------------
local function msg(text)
  guihooks.message(text, 4, "vehicle.bcfp.mode")
end

local function setModeIndex(i)
  i = floor(num(i, 1))
  if not MODES[i] then return end
  local l = getLeader()
  if l ~= M then return l.setModeIndex(i) end
  modeIndex = i
  time = 0
  statusDirty = true
  msg(T("app") .. ": " .. modeName(i))
end

local function nextMode()
  local l = getLeader()
  if l ~= M then return l.nextMode() end
  setModeIndex((modeIndex % #MODES) + 1)
end

local function prevMode()
  local l = getLeader()
  if l ~= M then return l.prevMode() end
  setModeIndex(((modeIndex - 2) % #MODES) + 1)
end

local function toggleMode() nextMode() end

local function toggleNight()
  local l = getLeader()
  if l ~= M then return l.toggleNight() end
  night = not night
  statusDirty = true
  msg(T("app") .. ": " .. (night and T("night") or T("day")))
end

local function toggleTakedown()
  local l = getLeader()
  if l ~= M then return l.toggleTakedown() end
  tkdToggle = not tkdToggle
  statusDirty = true
  msg(tkdToggle and T("tkdOn") or T("tkdOff"))
end

local function toggleAlley()
  local l = getLeader()
  if l ~= M then return l.toggleAlley() end
  alyToggle = not alyToggle
  statusDirty = true
  msg(alyToggle and T("alyOn") or T("alyOff"))
end

-- arayuzden canli ayar (hiz, seviyeler)
local function setLive(f)
  if type(f) ~= "table" then return end
  if f.speed then cfg.speed = num(f.speed, 100) / 100 end
  if f.day then cfg.dayLevel = num(f.day, 100) / 100 end
  if f.night then cfg.nightLevel = num(f.night, 35) / 100 end
  if f.cruise then cfg.cruiseLevel = num(f.cruise, 20) / 100 end
  if f.wigwag ~= nil then cfg.wigwag = num(f.wigwag, 1) end
  if f.autoNight ~= nil then cfg.autoNight = num(f.autoNight, 1) end
  for _, p in pairs(mlProps) do p.lastKey = nil end
  statusDirty = true
end

-- arayuzden canli bolge ayari (desen, faz, yan, seviye, grup, ikinci renk islevi, ok uyeligi)
local function setZone(id, f)
  if type(f) ~= "table" then return end
  local maxX = 0
  for _, z in ipairs(zones) do
    if z.id == id then
      if f.pat ~= nil then z.pat = floor(num(f.pat, 0)) end
      if f.phase ~= nil then z.phase = num(f.phase, 0) end
      if f.side ~= nil then z.side = floor(num(f.side, 0)) end
      if f.lvl ~= nil then z.lvl = num(f.lvl, 1) end
      if f.grp ~= nil then z.grp = (num(f.grp, 1) >= 2) and "B" or "A" end
      if f.bfn ~= nil then z.bfn = floor(num(f.bfn, 1)) end
      if f.adv ~= nil then z.adv = num(f.adv, 0) >= 0.5 end
      if f.kind ~= nil then z.kind = (f.kind == "white") and "white" or "color" end
    end
    if z.adv and z.face == "R" and z.x > maxX then maxX = z.x end
  end
  for _, z in ipairs(zones) do
    z.xn = (maxX > 0.001) and min(z.x / maxX, 1) or 1
  end
end

-----------------------------------------------------------------------------------------------
-- Hizli erisim (radyal menu)
-----------------------------------------------------------------------------------------------
registerQuickAccess = function(cid)
  if hasRegisteredQuickAccess or not core_quickAccess then return end
  if not isLeader() then return end
  core_quickAccess.addEntry({
    level = "/root/playerVehicle/lights/",
    uniqueID = "bcfp_pro",
    title = T("app"),
    icon = "wigwags",
    ["goto"] = "/root/playerVehicle/lights/bcfp_pro/"
  })
  core_quickAccess.addEntry({
    level = "/root/playerVehicle/lights/bcfp_pro/",
    generator = function(entries)
      for k, v in ipairs(MODES) do
        local e = {
          uniqueID = "bcfp_mode_" .. k .. "_" .. tostring(cid),
          title = modeName(k),
          icon = "wigwags",
          onSelect = function()
            setModeIndex(k)
            return {"reload"}
          end
        }
        if modeIndex == k then e.color = "#ff6600" end
        table.insert(entries, e)
      end
      table.insert(entries, {uniqueID = "bcfp_night_" .. tostring(cid), title = night and T("qDay") or T("qNight"), icon = "lights", onSelect = function() toggleNight() return {"reload"} end})
      table.insert(entries, {uniqueID = "bcfp_tkd_" .. tostring(cid), title = tkdToggle and T("qTkdOff") or T("qTkdOn"), icon = "lights", onSelect = function() toggleTakedown() return {"reload"} end})
      table.insert(entries, {uniqueID = "bcfp_aly_" .. tostring(cid), title = alyToggle and T("qAlyOff") or T("qAlyOn"), icon = "lights", onSelect = function() toggleAlley() return {"reload"} end})
    end
  })
  hasRegisteredQuickAccess = true
end

-----------------------------------------------------------------------------------------------
-- Kurulum
-----------------------------------------------------------------------------------------------
local function rowsOf(section)
  local out = {}
  if type(section) ~= "table" then return out end
  for _, row in pairs(section) do
    if type(row) == "table" then
      local id = row.id
      if id == nil then id = row.name end
      if id ~= nil then
        row.id = id
        out[#out + 1] = row
      end
    end
  end
  table.sort(out, function(a, b)
    local ia, ib = tostring(a.id), tostring(b.id)
    if ia == ib then return tostring(a.partPath or "") < tostring(b.partPath or "") end
    return ia < ib
  end)
  return out
end

local function buildZones()
  zones = {}
  local seen = {}
  local maxX = 0
  for _, r in ipairs(rowsOf(v.data.bcfpZones)) do
    local key = tostring(r.eL) .. "|" .. tostring(r.eR)
    if not seen[key] then
      seen[key] = true
      local z = {
        id = tostring(r.id), eL = r.eL, eR = r.eR, eL2 = r.eL2, eR2 = r.eR2,
        kind = r.kind or "color",
        grp = (num(r.grp, 1) >= 2) and "B" or "A",
        pat = floor(num(r.pat, 0)),
        phase = num(r.phase, 0),
        side = floor(num(r.side, 0)),
        lvl = num(r.lvl, 1),
        bfn = floor(num(r.bfn, 1)),
        face = r.face or "F",
        x = abs(num(r.x, 0)),
        adv = num(r.adv, 0) >= 0.5,
        zone = r.zone,
      }
      z.hasB = (type(z.eL2) == "string" and z.eL2 ~= "") or (type(z.eR2) == "string" and z.eR2 ~= "")
      zones[#zones + 1] = z
      for _, e in ipairs({z.eL, z.eR, z.eL2, z.eR2}) do
        if type(e) == "string" and e ~= "" then allElectrics[e] = true end
      end
      if z.adv and z.face == "R" and z.x > maxX then maxX = z.x end
    end
  end
  for _, z in ipairs(zones) do
    z.xn = (maxX > 0.001) and min(z.x / maxX, 1) or 1
  end
end

local function buildML()
  mlMods, mlProps, mlWhite = {}, {}, {}
  local byId, whiteSeen = {}, {}
  for _, r in ipairs(rowsOf(v.data.bcfpML)) do
    local kind = r.face
    if kind == "tkd" or kind == "aly" or kind == "fld" then
      local e = "bcfp_ml_" .. kind .. "_" .. tostring(r.side)
      if not whiteSeen[e] then
        whiteSeen[e] = true
        mlWhite[#mlWhite + 1] = {kind = kind, e = e}
        allElectrics[e] = true
      end
    else
      local id = tostring(r.id)
      local prev = byId[id]
      if prev then
        prev.n = max(prev.n, num(r.n, 1))
        modGeometry(prev)
      else
        local mod = {id = id, side = r.side, face = r.face, k = num(r.k, 1), n = num(r.n, 1), e = {}}
        for _, code in ipairs(ML_CODES) do
          mod.e[code] = "bcfp_ml_" .. mod.id .. "_" .. code
          allElectrics[mod.e[code]] = true
        end
        modGeometry(mod)
        mlMods[#mlMods + 1] = mod
        byId[id] = mod
      end
    end
  end
  if #mlMods > 0 and type(v.data.props) == "table" then
    for _, pr in pairs(v.data.props) do
      if type(pr) == "table" and type(pr.func) == "string" then
        local side, face = pr.func:match("^bcfp_mlp_([LR])_([FBE])$")
        if side then
          local key = side .. "_" .. face
          mlProps[key] = mlProps[key] or {func = pr.func, props = {}}
          table.insert(mlProps[key].props, pr)
          allElectrics[pr.func] = true
        end
      end
    end
  end
end

local function init(jbeamData)
  cfg = jbeamData or {}
  role = (cfg.role == "mlbar") and "mlbar" or "master"
  lang = (cfg.lang == "en" or cfg.lang == "tr") and cfg.lang or "tr"
  allElectrics = {}
  stateData = {}
  stateKeyMode = M.name .. "_mode"
  stateKeyFlags = M.name .. "_flags"
  disabledColors = {}
  if type(cfg.disabledColors) == "string" then
    for code in cfg.disabledColors:gmatch("[^,]+") do disabledColors[code] = true end
  end
  if role == "master" then buildZones() end
  buildML()
  if role == "master" then
    allElectrics.wigwag_L = true
    allElectrics.wigwag_R = true
  end
  modeIndex = floor(num(cfg.defaultMode, 1))
  if not MODES[modeIndex] then modeIndex = 1 end
  night = num(cfg.nightDefault, 0) >= 0.5
  tkdToggle, alyToggle = false, false
  time, active = 0, false
  for name in pairs(allElectrics) do electrics.values[name] = 0 end
  hasRegisteredQuickAccess = false
  statusDirty = true
  lastLb = -1
  mlDriver = nil
end

local function reset(jbeamData)
  time, active = 0, false
  tkdToggle, alyToggle = false, false
  for name in pairs(allElectrics) do electrics.values[name] = 0 end
  for _, p in pairs(mlProps) do p.lastKey = nil end
  statusDirty = true
  mlDriver = nil
end

local function getState()
  stateData[stateKeyMode] = modeIndex
  stateData[stateKeyFlags] = (night and 1 or 0) + (tkdToggle and 2 or 0) + (alyToggle and 4 or 0)
  return stateData
end

local function setState(data)
  if not data then return end
  local mi = data[stateKeyMode]
  if type(mi) == "number" and MODES[mi] then modeIndex = mi end
  local f = data[stateKeyFlags]
  if type(f) == "number" then
    night = (f % 2) >= 1
    tkdToggle = (floor(f / 2) % 2) >= 1
    alyToggle = (floor(f / 4) % 2) >= 1
  end
end

-- kardes ornekler arasi paylasim
M.bcfpIsMaster = function() return role == "master" end
M.bcfpRole = function() return role end
M.bcfpIsLeader = isLeader
M.bcfpGetMode = function() return modeIndex end
M.bcfpGetTime = function() return time end
M.bcfpGetNight = function() return night end
M.bcfpGetTkd = function() return tkdToggle end
M.bcfpGetAly = function() return alyToggle end
M.bcfpSetLive = setLive
M.bcfpSetZone = setZone
M.bcfpSetLang = function(l) if l == "en" or l == "tr" then lang = l end end
M.bcfpRefresh = function() for _, p in pairs(mlProps) do p.lastKey = nil end statusDirty = true end
M.bcfpModeNames = function()
  local names = {}
  for i, md in ipairs(MODES) do names[i] = md.name end
  return names
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX
M.toggleMode = toggleMode
M.setModeIndex = setModeIndex
M.nextMode = nextMode
M.prevMode = prevMode
M.toggleNight = toggleNight
M.toggleTakedown = toggleTakedown
M.toggleAlley = toggleAlley
M.getState = getState
M.setState = setState

return M
