-- Better Concealed Flashers PRO 3 - oyun motoru (GE) eklentisi
-- Evrensel: oyundaki tum araclarda (ve modlu araclarda) calisir. Ayarlar aracin kendi konfigurasyonunda
-- (vehicleConfig.bcfp) durur ve "Gizli Cakar PRO" arayuz uygulamasindan yonetilir.
--  - Gizli LED dizileri: aracin gercek 3B modeli taranarak (cam ici, panjur, tamponlar, bagaj, aynalar ...) ve
--    oyunun o araca ozel hazirladigi cakar konumlari okunarak otomatik, yuzeye tam oturan yerlesim
--  - Multicolor hoparlorlu LED bar, tepe lambasi kopyalari (araca takili ya da kurulu herhangi bir moddan)
--  - Isik Studyosu: tum uyari isiklarinin siddeti (kandela / lumen / luks), menzili, acisi, parlamasi,
--    gercekci LED renk ve tonlari; canli onizleme
-- Oyun dosyalarina dokunmaz; sadece arac yuklenirken bellekteki veriyi duzenler.

local M = {}

local MODULES = {'util', 'palette', 'geom', 'dae', 'scan', 'place', 'units', 'config', 'gen', 'catalog', 'studio', 'hints', 'env', 'inject', 'ui'}

-- mod guncellendiginde (eklenti yeniden yuklenince) eski modul kopyalari kullanilmasin
for _, name in ipairs(MODULES) do
  for _, p in ipairs({'bcfp/' .. name, 'lua/ge/extensions/bcfp/' .. name, '/lua/ge/extensions/bcfp/' .. name}) do
    package.loaded[p] = nil
  end
end

local function requireMod(name)
  local last
  for _, p in ipairs({'bcfp/' .. name, 'lua/ge/extensions/bcfp/' .. name, '/lua/ge/extensions/bcfp/' .. name}) do
    local ok, mod = pcall(require, p)
    if ok and type(mod) == 'table' then return mod end
    if not ok and not tostring(mod):find('not found', 1, true) then error(mod, 0) end
    last = mod
  end
  error('bcfpPro: modul yuklenemedi ' .. name .. ': ' .. tostring(last))
end

local U = requireMod('util')
local P = requireMod('palette')
local G = requireMod('geom')
local D = requireMod('dae')
local Sc = requireMod('scan')
local Pl = requireMod('place')
local Un = requireMod('units')
local C = requireMod('config')
local Gn = requireMod('gen')
local Cat = requireMod('catalog')
local S = requireMod('studio')
local H = requireMod('hints')
local E = requireMod('env')
local I = requireMod('inject')
local UI = requireMod('ui')

local mods = {U = U, P = P, G = G, D = D, Sc = Sc, Pl = Pl, Un = Un, C = C, Gn = Gn, Cat = Cat, S = S, H = H, E = E, I = I, UI = UI}
G.init(U)
Sc.init({U = U, D = D})
Pl.init({U = U, S = Sc})
C.init(mods)
Gn.init(mods)
Cat.init(mods)
S.init(mods)
H.init(mods)
E.init(mods)
I.init(mods)
UI.init(mods)

M._mods = mods
M.version = '3.0.0'

-----------------------------------------------------------------------------------------------
-- jbeam yukleyici kancalari
-----------------------------------------------------------------------------------------------
local function patchSlotSystem()
  local ok, ss = pcall(require, 'jbeam/slotSystem')
  if not ok or type(ss) ~= 'table' or type(ss.findParts) ~= 'function' then
    U.log('W', 'jbeam/slotSystem bulunamadi, evrensel parca eklemesi devre disi')
    return
  end
  if not ss.__bcfpOrigFindParts then ss.__bcfpOrigFindParts = ss.findParts end
  local orig = ss.__bcfpOrigFindParts
  ss.findParts = function(ioCtx, vehicleConfig)
    local r1, r2, r3, r4, r5, r6, r7 = orig(ioCtx, vehicleConfig)
    if r1 and type(vehicleConfig) == 'table' and type(vehicleConfig.bcfp) == 'table' then
      local okR, err = pcall(I.run, ioCtx, vehicleConfig, {r1, r2, r3, r4, r5, r6, r7})
      if not okR then U.log('E', 'parca ekleme hatasi: ' .. tostring(err)) end
    end
    return r1, r2, r3, r4, r5, r6, r7
  end
end

local function unpatchSlotSystem()
  local ok, ss = pcall(require, 'jbeam/slotSystem')
  if ok and type(ss) == 'table' and ss.__bcfpOrigFindParts then
    ss.findParts = ss.__bcfpOrigFindParts
    ss.__bcfpOrigFindParts = nil
  end
  -- v1 yamasi kaldiysa geri al
  if ok and type(ss) == 'table' and ss.__bcfpOrigUnify then
    ss.unifyPartJournal = ss.__bcfpOrigUnify
    ss.__bcfpOrigUnify = nil
  end
end

local function onJbeamLoadingPhase1(loadingProgress, objID, vehicle, unifyJournal, vehicleConfig, vars)
  if type(vehicleConfig) ~= 'table' or type(vehicleConfig.bcfp) ~= 'table' then return end
  local ok, err = pcall(I.phase1, vehicle, vehicleConfig)
  if not ok then U.log('E', 'baglanti kirisi hatasi: ' .. tostring(err)) end
end

local function onJbeamLoadingPhase2(loadingProgress, objID, vehicle, unifyJournal, vehicleConfig, vars)
  if type(vehicleConfig) ~= 'table' or type(vehicleConfig.bcfp) ~= 'table' then return end
  local cfg = C.sanitize(vehicleConfig.bcfp)
  if not cfg or not cfg.enabled then return end
  local ok, err = pcall(I.phase2, vehicle, vehicleConfig)
  if not ok then U.log('E', 'Phase2 hatasi: ' .. tostring(err)) end
  local ok2, groups, glowAssigned = pcall(S.phase2, vehicle, cfg)
  if not ok2 then
    U.log('E', 'isik studyosu hatasi: ' .. tostring(groups))
    groups, glowAssigned = nil, nil
  end
  vehicle.bcfpRuntime = vehicle.bcfpRuntime or {v = 3, items = {}}
  vehicle.bcfpRuntime.groups = groups or {}
  vehicle.bcfpRuntime.glowAssigned = glowAssigned or {}
  -- canli onizleme icin isik gruplarinin isim etiketleri (kopya / kendi ogelerimiz)
  local names = {}
  for _, it in ipairs(vehicle.bcfpRuntime.items or {}) do names['bcfp:' .. it.id] = it end
  for _, g in ipairs(vehicle.bcfpRuntime.groups) do
    local it = names[g.key]
    if it then
      if it.kind == 'copy' then g.name = 'Kopya ' .. it.id:sub(2) .. ': ' .. tostring(it.name or it.part)
      elseif it.kind == 'array' then g.name = ((Pl.zoneById[it.anchor or ''] or {}).tr or tostring(it.anchor)) .. ' (dizi ' .. it.id:sub(2) .. ')'
      elseif it.kind == 'mlbar' then g.name = 'Multicolor LED bar ' .. it.id:sub(2) end
      g.item = it.id
    end
  end
end

-----------------------------------------------------------------------------------------------
-- arayuz
-----------------------------------------------------------------------------------------------
function M.ui(cmd, args)
  UI.dispatch(cmd, args)
end

-- arac tarafindaki kontrolcu durum bildirir
function M.onVehicleStatus(vid, st)
  UI.onVehicleStatus(tonumber(vid), st)
end

local function onVehicleSpawned(vid)
  UI.onVehicleSpawned(vid)
end

local function onVehicleSwitched(oldId, newId)
  UI._state.vid = nil
  UI.markDirty()
end

local function onVehicleDestroyed(vid)
  UI.markDirty()
end

local function onFileChanged(filename)
  if type(filename) ~= 'string' then return end
  local f = filename:lower()
  if f:find('%.jbeam$') then
    Cat.invalidate()
    E.invalidate()
  elseif f:find('%.dae$') then
    E.invalidate()
  end
end

-----------------------------------------------------------------------------------------------
local function onExtensionLoaded()
  patchSlotSystem()
  U.log('I', 'Better Concealed Flashers PRO ' .. M.version .. ' yuklendi (evrensel)')
end

local function onExtensionUnloaded()
  unpatchSlotSystem()
end

local function onUpdate(dtReal, dtSim, dtRaw)
  UI.onUpdate(dtReal)
end

local function onPreRender(dt)
  UI.onPreRender()
end

M.onExtensionLoaded = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded
M.onJbeamLoadingPhase1 = onJbeamLoadingPhase1
M.onJbeamLoadingPhase2 = onJbeamLoadingPhase2
M.onVehicleSpawned = onVehicleSpawned
M.onVehicleSwitched = onVehicleSwitched
M.onVehicleDestroyed = onVehicleDestroyed
M.onFileChanged = onFileChanged
M.onUpdate = onUpdate
M.onPreRender = onPreRender

return M
