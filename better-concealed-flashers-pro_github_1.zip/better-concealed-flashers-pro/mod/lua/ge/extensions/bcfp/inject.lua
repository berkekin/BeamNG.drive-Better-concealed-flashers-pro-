-- Better Concealed Flashers PRO 3 - evrensel jbeam enjeksiyonu
--  * Oyunun parca agaci kurulduktan hemen sonra (slotSystem.findParts) aracin konfigurasyonundaki
--    vehicleConfig.bcfp ogelerini parca gunlugune (unifyJournal) ekler:
--      - kopya   : araca takili ya da kurulu herhangi bir moddan bir tepe lambasi / LED bar parcasinin
--                  tam kopyasi (ayni isiklar, ayni flas desenleri, ayni modeller). Dugum/grup/kontrolcu
--                  adlari soneklenir, konum/aci slot donusumleriyle (nodeMove / nodeRotate) verilir.
--      - dizi    : gizli LED dizisi (on cam ici, izgara, tampon, bagaj, ayna ...)
--      - mlbar   : multicolor hoparlorlu LED bar
--      - ana sistem: mod yonetimi + gizli bolgeler (bcfp_flasher)
--  * Phase1: eklenen parcalari en yakin govde dugumlerine yeni kirislerle baglar (her araca uyum).
--  * Phase2: kopyalardaki isiklarin yatay acisini duzeltir, yabanci (baska aracin) klasorlerini
--    model / materyal arama yoluna ekler ve arayuz icin calisma bilgisini kaydeder.
local I = {}
local U, P, G, C, Gn, Cat, S, E, Pl, Un

local jbeamIO, ss, jbeamUtils, EP

local min, max, abs, floor, sqrt = math.min, math.max, math.abs, math.floor, math.sqrt

I.ctxByConfig = setmetatable({}, {__mode = 'k'})
I.lastReport = nil

function I.init(mods)
  U, P, G, C, Gn, Cat, S = mods.U, mods.P, mods.G, mods.C, mods.Gn, mods.Cat, mods.S
  E, Pl, Un = mods.E, mods.Pl, mods.Un
  jbeamIO = require('jbeam/io')
  ss = require('jbeam/slotSystem')
  jbeamUtils = require('jbeam/utils')
  EP = require('jbeam/expressionParser')
end

local isList = function(t) return type(t) == 'table' and t[1] ~= nil end

-----------------------------------------------------------------------------------------------
-- ham dugum bulutu (degiskenler henuz islenmeden; sayisal konumlar + slot donusumleri)
-----------------------------------------------------------------------------------------------
local function evalNum(v, vars)
  if type(v) == 'number' then return v end
  if type(v) == 'string' and vars then
    local b1, b2 = v:byte(1), v:byte(2)
    if b1 == 36 and b2 == 61 then -- "$="
      local ok, r = pcall(EP.parse, v, vars)
      if ok and type(r) == 'number' and r == r then return r end
    elseif b1 == 36 then
      local x = vars[v]
      if type(x) == 'table' then x = x.val end
      if type(x) == 'number' then return x end
    end
  end
  return nil
end
I.evalNum = evalNum

local function numericOps(so)
  -- sadece sayisal donusum anahtarlarini al (henuz cozumlenmemis "$..." degerleri atla)
  if type(so) ~= 'table' then return nil end
  local out, any = {}, false
  for k, v in pairs(so) do
    if type(k) == 'string' and k:sub(1, 4) == 'node' and type(v) == 'table'
      and type(v.x) == 'number' and type(v.y) == 'number' and type(v.z) == 'number' then
      out[k] = v
      any = true
    end
  end
  return any and out or nil
end

local function collectPartNodes(part, so, out, path, vars)
  local nodes = part and part.nodes
  if not isList(nodes) or not isList(nodes[1]) then return end
  local header = nodes[1]
  local ci = {}
  for i, h in ipairs(header) do if type(h) == 'string' then ci[h] = i end end
  local iid, ix, iy, iz = ci.id or 1, ci.posX or 2, ci.posY or 3, ci.posZ or 4
  local igroup = ci.group
  local state = {}
  local ops = numericOps(so)
  for r = 2, #nodes do
    local row = nodes[r]
    if type(row) == 'table' then
      if row[1] == nil then
        for k, v in pairs(row) do state[k] = v end
      else
        local name = row[iid]
        local x, y, z = evalNum(row[ix], vars), evalNum(row[iy], vars), evalNum(row[iz], vars)
        if type(name) == 'string' and x and y and z then
          local opts = U.rowOptions(row)
          local g = state.group
          if igroup and row[igroup] ~= nil then g = row[igroup] end
          if opts and opts.group ~= nil then g = opts.group end
          if ops then x, y, z = jbeamUtils.getPosAfterNodeRotateOffsetMove(ops, x, y, z) end
          out[name] = {name = name, x = x, y = y, z = z, group = g, path = path}
        end
      end
    end
  end
end
I.collectPartNodes = collectPartNodes

function I.collectCloud(rootPart, journal, vars)
  local out = {}
  collectPartNodes(rootPart, nil, out, '/' .. tostring(rootPart.partName), vars)
  for _, j in ipairs(journal or {}) do
    if type(j[2]) == 'table' and not (type(j[5]) == 'string' and j[5]:find('^/bcfp_')) then
      collectPartNodes(j[2], j[4], out, j[5], vars)
    end
  end
  return out
end

-----------------------------------------------------------------------------------------------
-- yardimcilar: parca ici adlar, gruplar, degisken referanslari
-----------------------------------------------------------------------------------------------
local function definedNodes(part, set, groups)
  local nodes = part.nodes
  if not isList(nodes) or not isList(nodes[1]) then return end
  local gcol
  for ci, h in ipairs(nodes[1]) do if h == 'group' then gcol = ci end end
  local cur
  for i = 2, #nodes do
    local row = nodes[i]
    if type(row) == 'table' then
      if isList(row) then
        if type(row[1]) == 'string' then set[row[1]] = true end
        local g = cur
        if gcol and row[gcol] ~= nil then g = row[gcol] end
        local o = U.rowOptions(row)
        if o and o.group ~= nil then g = o.group end
        if groups then
          if type(g) == 'string' and g ~= '' then groups[g] = true
          elseif type(g) == 'table' then for _, x in pairs(g) do if type(x) == 'string' and x ~= '' then groups[x] = true end end end
        end
      elseif row.group ~= nil then
        cur = row.group
      end
    end
  end
end

local function literalVars(slotDef, parent)
  local out = {}
  for k, v in pairs(parent or {}) do out[k] = v end
  local sv = type(slotDef) == 'table' and slotDef.variables
  if type(sv) == 'table' then
    for k, v in pairs(sv) do
      if type(v) ~= 'string' or v:byte(1) ~= 36 then out[k] = v
      else
        local n = evalNum(v, out)
        if n then out[k] = n end
      end
    end
  end
  return out
end

local function resolveRef(v, vars)
  if type(v) == 'string' and v:byte(1) == 36 and v:byte(2) ~= 61 then
    local x = vars and vars[v]
    if type(x) == 'table' then x = x.val end
    if type(x) == 'string' then return x end
    return nil -- bilinmiyor: harici sayma
  end
  return v
end

-- parcanin araca ait (kopyanin disindaki) grup / dugumlere bagli gorsel ogesi var mi
local function usesExternal(part, own, ownGroups, vars)
  local fb = part.flexbodies
  if isList(fb) and isList(fb[1]) then
    local gcol
    for i, h in ipairs(fb[1]) do if h == '[group]:' then gcol = i end end
    if gcol then
      for r = 2, #fb do
        local row = fb[r]
        if isList(row) then
          local g = row[gcol]
          local list = type(g) == 'table' and g or {g}
          for _, gn in ipairs(list) do
            gn = resolveRef(gn, vars)
            if type(gn) == 'string' and gn ~= '' and gn:byte(1) ~= 36 and not ownGroups[gn] then return true end
          end
        end
      end
    end
  end
  local pr = part.props
  if isList(pr) and isList(pr[1]) then
    local icol
    for i, h in ipairs(pr[1]) do if h == 'idRef:' then icol = i end end
    if icol then
      for r = 2, #pr do
        local row = pr[r]
        if isList(row) then
          local n = resolveRef(row[icol], vars)
          if type(n) == 'string' and n ~= '' and n:byte(1) ~= 36 and not own[n] then return true end
        end
      end
    end
  end
  return false
end

local function hasVisual(part)
  return (isList(part.flexbodies) and #part.flexbodies > 1) or (isList(part.props) and #part.props > 1)
end

-----------------------------------------------------------------------------------------------
-- yeniden adlandirma (v1'den; oyunda dogrulandi)
-----------------------------------------------------------------------------------------------
local SKIP_SECTIONS = {
  information = true, slotType = true, slots = true, slots2 = true, variables = true,
  glowMap = true, controller = true, components = true, partName = true,
}

local function addNames(set, v)
  if type(v) == 'string' then
    if v ~= '' then set[v] = true end
  elseif type(v) == 'table' then
    for _, x in pairs(v) do if type(x) == 'string' and x ~= '' then set[x] = true end end
  end
end

function I.renameParts(parts, suffix, extraSlotDefs)
  local defined, groups, dgroups = {}, {}, {}
  local function isVar(v) return type(v) == 'string' and v:byte(1) == 36 end
  local function addDG(v)
    if type(v) == 'string' then
      if v ~= '' and not isVar(v) then dgroups[v] = true end
    elseif type(v) == 'table' then
      for _, x in pairs(v) do if type(x) == 'string' and x ~= '' and not isVar(x) then dgroups[x] = true end end
    end
  end
  local function scanDG(t, depth)
    if type(t) ~= 'table' or depth > 8 then return end
    for k, v in pairs(t) do
      if k == 'breakGroup' or k == 'deformGroup' then addDG(v)
      elseif type(v) == 'table' then scanDG(v, depth + 1) end
    end
  end
  for _, part in ipairs(parts) do
    local nodes = part.nodes
    if isList(nodes) then
      local groupCol
      if isList(nodes[1]) then
        for ci, h in ipairs(nodes[1]) do if h == 'group' then groupCol = ci end end
      end
      for i, row in ipairs(nodes) do
        if i > 1 and type(row) == 'table' then
          if isList(row) then
            if type(row[1]) == 'string' and not isVar(row[1]) then defined[row[1]] = true end
            if groupCol then addNames(groups, row[groupCol]) end
            local o = U.rowOptions(row)
            if o then addNames(groups, o.group) end
          else
            addNames(groups, row.group)
          end
        end
      end
    end
    for secName, sec in pairs(part) do
      if type(sec) == 'table' and not SKIP_SECTIONS[secName] then scanDG(sec, 0) end
    end
  end
  for g in pairs(groups) do if isVar(g) then groups[g] = nil end end
  local function ren(v)
    if type(v) == 'string' and defined[v] then return v .. suffix end
    return v
  end
  local function renSet(set, v)
    if type(v) == 'string' then
      if set[v] then return v .. suffix end
      return v
    end
    if type(v) == 'table' then
      for k, x in pairs(v) do if type(x) == 'string' and set[x] then v[k] = x .. suffix end end
    end
    return v
  end
  local function renAll(v)
    if type(v) == 'string' then
      if v ~= '' and not isVar(v) then return v .. suffix end
      return v
    end
    if type(v) == 'table' then
      for k, x in pairs(v) do if type(x) == 'string' and x ~= '' and not isVar(x) then v[k] = x .. suffix end end
    end
    return v
  end
  local function renValue(v)
    if type(v) == 'string' then return ren(v) end
    if type(v) == 'table' then
      for k, x in pairs(v) do if type(x) == 'string' then v[k] = ren(x) end end
    end
    return v
  end
  local function renDict(d)
    for k, v in pairs(d) do
      if type(k) == 'string' then
        if k:sub(-1) == ':' and k:sub(1, 1) ~= '[' then
          d[k] = renValue(v)
        elseif k == 'group' then
          d[k] = renSet(groups, v)
        elseif k == 'breakGroup' or k == 'deformGroup' then
          d[k] = renAll(v)
        end
      end
    end
  end
  local function renDictRecursive(d, depth)
    if depth > 6 then return end
    renDict(d)
    for _, v in pairs(d) do
      if type(v) == 'table' and not isList(v) then renDictRecursive(v, depth + 1) end
    end
  end
  for _, part in ipairs(parts) do
    for secName, sec in pairs(part) do
      if type(sec) == 'table' and not SKIP_SECTIONS[secName] then
        if isList(sec) and isList(sec[1]) then
          local linkCols, groupCols = {}, {}
          for ci, h in ipairs(sec[1]) do
            if type(h) == 'string' then
              if h:sub(-1) == ':' and h:sub(1, 1) ~= '[' then linkCols[ci] = true
              elseif h == '[group]:' or h == 'group' then groupCols[ci] = true end
            end
          end
          local isNodes = (secName == 'nodes')
          for ri = 2, #sec do
            local row = sec[ri]
            if type(row) == 'table' then
              if isList(row) then
                if isNodes and type(row[1]) == 'string' then row[1] = ren(row[1]) end
                for ci in pairs(linkCols) do if row[ci] ~= nil then row[ci] = renValue(row[ci]) end end
                for ci in pairs(groupCols) do if row[ci] ~= nil then row[ci] = renSet(groups, row[ci]) end end
                local o = U.rowOptions(row)
                if o then renDict(o) end
              else
                renDict(row)
              end
            end
          end
        elseif not isList(sec) then
          renDictRecursive(sec, 0)
        end
      end
    end
  end
  -- slot degiskenleri: kopyanin kendi dugum / grup / kirilma grubu adlarini tasiyan degerler
  -- (ornek: vanilya lamba ampulleri "$nodeRef":"lightbar_2", "$deformGroup":"lightbar_break")
  local function renVar(val)
    if type(val) == 'string' and not isVar(val) and (defined[val] or groups[val] or dgroups[val]) then return val .. suffix end
    if type(val) == 'table' then
      for k, x in pairs(val) do
        if type(x) == 'string' and not isVar(x) and (defined[x] or groups[x] or dgroups[x]) then val[k] = x .. suffix end
      end
    end
    return val
  end
  local function renSlotDefs(slots)
    if type(slots) ~= 'table' then return end
    for _, sd in ipairs(slots) do
      if type(sd) == 'table' and type(sd.variables) == 'table' then
        for k, v in pairs(sd.variables) do sd.variables[k] = renVar(v) end
      end
    end
  end
  for _, part in ipairs(parts) do renSlotDefs(part.slots2 or part.slots) end
  if extraSlotDefs then renSlotDefs(extraSlotDefs) end
  for _, part in ipairs(parts) do
    local ctrl = part.controller
    if isList(ctrl) then
      for ri = 2, #ctrl do
        local row = ctrl[ri]
        if isList(row) and type(row[1]) == 'string' then
          local opts = row[2]
          if type(opts) ~= 'table' or isList(opts) then
            opts = {}
            table.insert(row, 2, opts)
          end
          opts.name = tostring(opts.name or row[1]) .. suffix
        end
      end
    end
  end
  local newDefined, newGroups = {}, {}
  for n in pairs(defined) do newDefined[n .. suffix] = true end
  for g in pairs(groups) do newGroups[g .. suffix] = true end
  return newDefined, newGroups
end

-----------------------------------------------------------------------------------------------
-- kontrolcu / ses tekrar onleme
-----------------------------------------------------------------------------------------------
local function controllerSig(row)
  local cfg = (type(row[2]) == 'table' and not isList(row[2])) and row[2] or {}
  local c = {}
  for k, v in pairs(cfg) do
    if k ~= 'name' and k ~= 'cid' and k ~= 'partOrigin' and k ~= 'partPath' then c[k] = v end
  end
  return tostring(row[1]) .. '|' .. U.signature(c)
end

local function collectVehicleSigs(rootPart, journal)
  local ctrl, sound = {}, {}
  local function scan(part)
    local c = part.controller
    if isList(c) then
      for r = 2, #c do
        local row = c[r]
        if isList(row) and type(row[1]) == 'string' then ctrl[controllerSig(row)] = true end
      end
    end
    local s = part.soundscape
    if isList(s) then
      for r = 2, #s do
        local row = s[r]
        if isList(row) and type(row[1]) == 'string' then sound[row[1]] = true end
      end
    end
  end
  scan(rootPart)
  for _, j in ipairs(journal) do
    if type(j[2]) == 'table' and not (type(j[5]) == 'string' and j[5]:find('^/bcfp_')) then scan(j[2]) end
  end
  return ctrl, sound
end

local function dedupeControllers(part, sigs, keepAll)
  local c = part.controller
  if not isList(c) then return 0 end
  local removed = 0
  for r = #c, 2, -1 do
    local row = c[r]
    if isList(row) and type(row[1]) == 'string' then
      local sig = controllerSig(row)
      if sigs[sig] and not keepAll then
        table.remove(c, r)
        removed = removed + 1
      else
        sigs[sig] = true
      end
    end
  end
  if #c <= 1 then part.controller = nil end
  return removed
end

local function dedupeSounds(part, names)
  local s = part.soundscape
  if not isList(s) then return 0 end
  local removed = 0
  for r = #s, 2, -1 do
    local row = s[r]
    if isList(row) and type(row[1]) == 'string' then
      if names[row[1]] then
        table.remove(s, r)
        removed = removed + 1
      else
        names[row[1]] = true
      end
    end
  end
  local rows = 0
  for r = 2, #s do if isList(s[r]) then rows = rows + 1 end end
  if rows == 0 then part.soundscape = nil end
  return removed
end

-----------------------------------------------------------------------------------------------
-- yabanci (baska aracta) parca baglantilarini hedef araca uyarlama
-----------------------------------------------------------------------------------------------
local function nearestNodes(cloud, px, py, pz, k, excludeFn)
  local best = {}
  for name, n in pairs(cloud) do
    if not (excludeFn and excludeFn(n)) then
      local dx, dy, dz = n.x - px, n.y - py, n.z - pz
      local d = dx * dx + dy * dy + dz * dz
      if #best < k then
        best[#best + 1] = {n = n, d = d}
        table.sort(best, function(a, b) return a.d < b.d end)
      elseif d < best[#best].d then
        best[#best] = {n = n, d = d}
        table.sort(best, function(a, b) return a.d < b.d end)
      end
    end
  end
  local out = {}
  for i, b in ipairs(best) do out[i] = b.n end
  return out
end
I.nearestNodes = nearestNodes

local LINK_SKIP = {nodes = true, flexbodies = true, props = true, glowMap = true, controller = true, variables = true,
                   slots = true, slots2 = true, information = true, components = true}

local function fixExternalRefs(parts, own, cloud, cross, T, report, vehNames, vehGroups)
  local function known(name) return own[name] or (not cross and vehNames[name] ~= nil) end
  for _, part in ipairs(parts) do
    for secName, sec in pairs(part) do
      if type(sec) == 'table' and isList(sec) and isList(sec[1]) and not LINK_SKIP[secName] then
        local linkCols = {}
        for ci, h in ipairs(sec[1]) do
          if type(h) == 'string' and h:sub(-1) == ':' and h:sub(1, 1) ~= '[' and h ~= 'nodeArm:' then linkCols[#linkCols + 1] = ci end
        end
        if #linkCols > 0 then
          for ri = #sec, 2, -1 do
            local row = sec[ri]
            if isList(row) then
              for _, ci in ipairs(linkCols) do
                local v = row[ci]
                if type(v) == 'string' and v ~= '' and v:byte(1) ~= 36 and not known(v) then
                  table.remove(sec, ri)
                  report.droppedRows = (report.droppedRows or 0) + 1
                  break
                end
              end
            end
          end
        end
      end
    end
    -- isik / prop referans dugumleri
    local pr = part.props
    if isList(pr) and isList(pr[1]) then
      local cols = {}
      for i, h in ipairs(pr[1]) do if h == 'idRef:' or h == 'idX:' or h == 'idY:' then cols[#cols + 1] = i end end
      for ri = 2, #pr do
        local row = pr[ri]
        if isList(row) then
          local bad = false
          for _, ci in ipairs(cols) do
            local v = row[ci]
            if type(v) == 'string' and v ~= '' and v:byte(1) ~= 36 and not known(v) then bad = true end
          end
          if bad then
            local o = U.rowOptions(row) or {}
            local bt = o.baseTranslationGlobal
            local px, py, pz = T.x, T.y, T.z
            if type(bt) == 'table' and type(bt.x) == 'number' then px, py, pz = bt.x + T.x, bt.y + T.y, bt.z + T.z end
            local nn = nearestNodes(cloud, px, py, pz, 3, G.isExcluded)
            if #nn == 3 then
              for k, ci in ipairs(cols) do row[ci] = nn[k].name end
              report.remappedProps = (report.remappedProps or 0) + 1
            end
          end
        end
      end
    end
    -- esnek govde (flexbody) gruplari
    local fb = part.flexbodies
    if isList(fb) and isList(fb[1]) then
      local gcol
      for i, h in ipairs(fb[1]) do if h == '[group]:' then gcol = i end end
      if gcol then
        for ri = 2, #fb do
          local row = fb[ri]
          if isList(row) then
            local g = row[gcol]
            local list = type(g) == 'table' and g or {g}
            local ok = true
            for _, gn in ipairs(list) do
              if type(gn) == 'string' and gn ~= '' and gn:byte(1) ~= 36 and not cross then
                -- ayni arac: grup kopyada ya da aracta var mi?
                if not vehGroups[gn] and not gn:find('_bcfp', 1, true) then ok = false end
              end
            end
            if cross then
              local external = false
              for _, gn in ipairs(list) do if type(gn) == 'string' and gn ~= '' and not gn:find('_bcfp', 1, true) then external = true end end
              ok = not external
            end
            if not ok then
              local nn = nearestNodes(cloud, T.x, T.y, T.z, 1, G.isExcluded)
              local ng = nn[1] and nn[1].group
              if type(ng) == 'table' then ng = ng[1] end
              if type(ng) == 'string' and ng ~= '' then
                row[gcol] = {ng}
                report.remappedFlex = (report.remappedFlex or 0) + 1
              end
            end
          end
        end
      end
    end
  end
end

-- performans: kopyadaki gercek isik kaynaklarini azalt (lens parlamasi / desen aynen kalir)
--   mode 1: her iki isiktan biri kalir, kalanin parlakligi 2 kat (toplam aydinlatma korunur)
--   mode 2: hic gercek isik yok (sadece parlayan lensler)
local PROP_COL_DEFAULT = {baseRotation = {x = 0, y = 0, z = 0}, rotation = {x = 0, y = 0, z = 0},
                          translation = {x = 0, y = 0, z = 0}, min = 0, max = 100, offset = 0, multiplier = 1}

local function rowOptionsFor(row, hdr)
  if #row > #hdr and type(row[#row]) == 'table' and not isList(row[#row]) then return row[#row] end
  -- eksik sutunlari oyunun varsayilanlariyla doldur, sonra ayar sozlugu ekle
  for k = #row + 1, #hdr do
    local h = hdr[k]
    local d = PROP_COL_DEFAULT[h]
    if d == nil then return nil end
    row[k] = U.copy(d)
  end
  local o = {}
  row[#hdr + 1] = o
  return o
end

-- sayi, degisken ("$x") ya da ifade ("$= ...") olarak verilmis degeri iki katina cikar
local function doubled(v)
  if type(v) == 'number' then return v * 2 end
  if type(v) == 'string' then
    if v:sub(1, 2) == '$=' then return '$= (' .. v:sub(3) .. ') * 2' end
    if v:sub(1, 1) == '$' then return '$= ' .. v .. ' * 2' end
    local n = tonumber(v)
    if n then return n * 2 end
  end
  return nil
end
I.doubled = doubled

local function reduceLights(parts, mode, rep)
  if not mode or mode == 0 then return end
  local n = 0
  for _, part in ipairs(parts) do
    local pr = part.props
    if isList(pr) and isList(pr[1]) then
      local hdr = pr[1]
      local meshCol
      for i, h in ipairs(hdr) do if h == 'mesh' then meshCol = i end end
      if meshCol then
        local cur = {}
        local newPr = {hdr}
        for ri = 2, #pr do
          local row = pr[ri]
          if type(row) == 'table' and not isList(row) then
            -- satir-ici varsayilan degistirici: sonraki satirlara uygulanir
            for _, k in ipairs({'lightBrightness', 'lightIntensityCd', 'lightIntensityLm'}) do
              if row[k] ~= nil then cur[k] = row[k] end
            end
            newPr[#newPr + 1] = row
          elseif isList(row) and (row[meshCol] == 'SPOTLIGHT' or row[meshCol] == 'POINTLIGHT') then
            n = n + 1
            if mode == 1 and n % 2 == 1 then
              local o = rowOptionsFor(row, hdr)
              if o then
                -- oyun: SPOTLIGHT'ta lightIntensityCd, POINTLIGHT'ta lightIntensityLm varsa parlakligi ezer
                local spot = row[meshCol] == 'SPOTLIGHT'
                local cd = o.lightIntensityCd
                if cd == nil or cd == '' then cd = cur.lightIntensityCd end
                local lm = o.lightIntensityLm
                if lm == nil or lm == '' then lm = cur.lightIntensityLm end
                local key, val
                if spot and cd ~= nil and cd ~= '' then key, val = 'lightIntensityCd', cd
                elseif (not spot) and lm ~= nil and lm ~= '' then key, val = 'lightIntensityLm', lm
                else
                  key, val = 'lightBrightness', o.lightBrightness
                  if val == nil or val == '' then val = cur.lightBrightness end
                  if val == nil or val == '' then val = 1 end
                end
                local d = doubled(val)
                if d ~= nil then o[key] = d end
              end
              newPr[#newPr + 1] = row
            else
              rep.lightsRemoved = (rep.lightsRemoved or 0) + 1
            end
          else
            newPr[#newPr + 1] = row
          end
        end
        part.props = newPr
      end
    end
  end
end
I.reduceLights = reduceLights

-----------------------------------------------------------------------------------------------
-- kopya agaci olusturma
-----------------------------------------------------------------------------------------------
local function stripSlotOptions(so)
  so.name, so.type, so.allowTypes, so.denyTypes, so.default, so.description, so.maxRecursion = nil, nil, nil, nil, nil, nil, nil
  if so.coreSlot == true then so.coreSlot = nil end
  so.variables = nil
  return so
end

local function findTreeNode(node, partPath, depth)
  if type(node) ~= 'table' or (depth or 0) > 60 then return nil end
  if node.partPath == partPath then return node end
  for _, ch in pairs(node.children or {}) do
    local r = findTreeNode(ch, partPath, (depth or 0) + 1)
    if r then return r end
  end
end

local function fillCopy(env, parentPart, parentSlotPath, parentSO, level, treeNode, vars, out)
  local slots = parentPart.slots2 or parentPart.slots
  if type(slots) ~= 'table' then return end
  for _, slotDef in ipairs(slots) do
    if type(slotDef) == 'table' then
      local slotId = slotDef.name or slotDef.type
      if type(slotId) == 'string' then
        local tn = treeNode and treeNode.children and treeNode.children[slotId]
        local chosen
        if tn then chosen = tn.chosenPartName end
        if chosen == nil then chosen = slotDef.default end
        if type(chosen) == 'string' and chosen ~= '' and #out.list < 400 then
          local child = env.getPart(chosen)
          if child and ss.partFitsSlot(child, slotDef) then
            local so = stripSlotOptions(tableMerge(deepcopy(parentSO or {}), deepcopy(slotDef)))
            local slotPath = parentSlotPath .. slotId .. '/'
            local uj = {parentPart, child, level, so, slotPath .. chosen, slotDef}
            local cvars = literalVars(slotDef, vars)
            out.pre[#out.pre + 1] = uj
            out.list[#out.list + 1] = {uj = uj, slotId = slotId, vars = cvars, parent = parentPart}
            fillCopy(env, child, slotPath, so, level + 1, tn, cvars, out)
            out.post[#out.post + 1] = uj
          end
        end
      end
    end
  end
end

-- kopyanin ham sinir kutusu (dugumler degiskenlerle degerlendirilir)
local function bbox(entries)
  local x0, y0, z0, x1, y1, z1 = math.huge, math.huge, math.huge, -math.huge, -math.huge, -math.huge
  local cnt = 0
  for _, e in ipairs(entries) do
    local tmp = {}
    collectPartNodes(e.part, e.so, tmp, '', e.vars)
    for _, n in pairs(tmp) do
      cnt = cnt + 1
      x0, y0, z0 = min(x0, n.x), min(y0, n.y), min(z0, n.z)
      x1, y1, z1 = max(x1, n.x), max(y1, n.y), max(z1, n.z)
    end
  end
  if cnt == 0 then return nil end
  return {x0 = x0, y0 = y0, z0 = z0, x1 = x1, y1 = y1, z1 = z1, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, cz = (z0 + z1) / 2, n = cnt}
end

-- degisken kapsami: araca ait tum parcalarin bildirilen degiskenleri (varsayilan ya da kullanici degeri)
local function declaredVars(rootPart, journal, userVars)
  local out = {}
  local function scan(part)
    local v = part.variables
    if isList(v) and isList(v[1]) then
      local h = {}
      for i, name in ipairs(v[1]) do h[name] = i end
      for r = 2, #v do
        local row = v[r]
        if isList(row) and type(row[h.name or 1]) == 'string' then
          local name = row[h.name or 1]
          local d = row[h.default or 5]
          if userVars and userVars[name] ~= nil then d = userVars[name] end
          if type(d) == 'number' then out[name] = d end
        end
      end
    end
  end
  scan(rootPart)
  for _, j in ipairs(journal) do if type(j[2]) == 'table' then scan(j[2]) end end
  return out
end

-- kopyalanan agacta kullanilan ama agac icinde tanimlanmayan degiskenler icin slot degiskeni sagla
local function collectVarTokens(v, set, depth)
  if depth > 30 then return end
  if type(v) == 'string' then
    if v:byte(1) == 36 then
      for tok in v:gmatch('%$([%a_][%w_]*)') do set['$' .. tok] = true end
    end
  elseif type(v) == 'table' then
    for k, x in pairs(v) do
      if type(k) == 'string' and k:byte(1) == 36 then
        for tok in k:gmatch('%$([%a_][%w_]*)') do set['$' .. tok] = true end
      end
      collectVarTokens(x, set, depth + 1)
    end
  end
end

-----------------------------------------------------------------------------------------------
-- donusum (konum / aci) -> slot secenekleri
-----------------------------------------------------------------------------------------------
-- Oyunun donusum zinciri (jbeam/utils): son konum = R*(p - pivot) + pivot + (tum oteleme toplami).
-- Yani donme, ham (otelenmemis) koordinatlarda pivot etrafinda uygulanir. Dunya uzayindaki W noktasi
-- etrafinda donmesi icin her slot satirinin pivotu = W - (o satirin oteleme toplami) olmali.
local function baseTranslation(so)
  local ops = numericOps(so)
  if not ops then return {x = 0, y = 0, z = 0} end
  local x, y, z = jbeamUtils.getPosAfterNodeRotateOffsetMove(ops, 0, 0, 0)
  return {x = x, y = y, z = z}
end

local function setTransform(so, T, rot, W)
  local B = baseTranslation(so)
  so.nodeMove97 = {x = U.r(T.x, 5), y = U.r(T.y, 5), z = U.r(T.z, 5)}
  if rot and (abs(rot.yaw) > 1e-4 or abs(rot.pitch) > 1e-4 or abs(rot.roll) > 1e-4) then
    so.nodeRotate98 = {x = U.r(rot.pitch, 4), y = U.r(rot.roll, 4), z = U.r(rot.yaw, 4),
                       px = U.r(W.x - B.x - T.x, 5), py = U.r(W.y - B.y - T.y, 5), pz = U.r(W.z - B.z - T.z, 5)}
  end
end

local function anchorPoint(anchors, o)
  local a = anchors[o.anchor]
  if o.anchor == 'roof' or o.anchor == 'orig' or o.anchor == 'custom' or not a then
    local r = anchors.roof or {x = 0, y = 0, z = 1.4}
    if o.anchor == 'custom' then return {x = 0, y = 0, z = 0} end
    return {x = 0, y = r.y or 0, z = r.z or 1.4}
  end
  return {x = 0, y = a.y or 0, z = a.z or 1}
end

-- tavan montaj noktasi: once aracin kendi tepe lambasinin (fabrika) yeri, sonra yuzey taramasi, en son dugum bulutu
-- hx: yarim genislik, hy: yarim derinlik (ayaklarin oturdugu alan); doner: {x, y, z (tavan dis yuzeyi), src}
function I.roofPoint(env, hx, hy, dy)
  local anchors = env.anchors or {}
  local r = anchors.roof or {y = 0, z = 1.4}
  local y = r.y or 0
  local src = 'approx'
  local z = r.z or 1.4
  local F = env.M and Pl.frames(env.M)
  if F and F.roof then
    y = F.roof.y
    src = 'scan'
  end
  local bar = env.roofBar
  if bar and env.M then
    local zr = E.roofZ(env, bar.y, hx, hy)
    if zr and abs(zr - bar.z) < 0.12 then
      y, src = bar.y, 'factory'
    end
  end
  y = y + (dy or 0)
  if env.M then
    local zr = E.roofZ(env, y, hx, hy)
    if zr then z = zr else src = 'approx' end
  end
  return {x = 0, y = y, z = z, src = src}
end

-- fabrika (oyunun kendi) gizli cakarlarindan, bizim basliklarimizla ayni yerde olanlari gizle:
-- parca takili kalir (siren sesi, desen kontrolcusu calisir) ama cakisan modeli ve isigi cizilmez.
local function hideFactoryHeads(env, journal, placed, declared, report)
  if #placed == 0 then return end
  local names = {}
  for _, f in ipairs(env.factory or {}) do if f.active then names[f.name] = true end end
  if next(names) == nil then return end
  local function near(x, y, z, r)
    for _, p in ipairs(placed) do
      local dx, dy, dz = p[1] - x, p[2] - y, p[3] - z
      if dx * dx + dy * dy + dz * dz < r * r then return true end
    end
    return false
  end
  local hidden, bulbs = 0, 0
  local prefixes = {}
  for _, j in ipairs(journal) do
    local part = j[2]
    if type(part) == 'table' and names[part.partName] and isList(part.flexbodies) then
      local list = {}
      E.collectPartFlex(part, j[4], declared, list, j[5])
      -- satir eslesmesi: ayni sirayla (model adi + sayisal konum) yeniden yuru
      local fb = part.flexbodies
      local im = 1
      for i, h in ipairs(fb[1]) do if h == 'mesh' then im = i end end
      local k = 0
      local drop = {}
      for r = 2, #fb do
        local row = fb[r]
        if type(row) == 'table' and row[1] ~= nil and type(row[im]) == 'string' and row[im] ~= '' and row[im]:byte(1) ~= 36 then
          local e = list[k + 1]
          if e and e.mesh == row[im] then
            k = k + 1
            if e.mesh:find('generic_flasher_led', 1, true) and near(e.pos.x, e.pos.y, e.pos.z, 0.075) then drop[#drop + 1] = r end
          end
        end
      end
      for i = #drop, 1, -1 do table.remove(fb, drop[i]) end
      hidden = hidden + #drop
      if #drop > 0 and type(j[5]) == 'string' then prefixes[#prefixes + 1] = j[5]:match('^(.*/)') end
    end
  end
  -- gizlenen basliklarin isik (ampul) alt parcalari
  if #prefixes > 0 then
    for _, j in ipairs(journal) do
      local part, path, sd = j[2], j[5], j[6]
      if type(part) == 'table' and type(path) == 'string' and isList(part.props) and type(sd) == 'table' and type(sd.variables) == 'table' then
        local under = false
        for _, pre in ipairs(prefixes) do if path:sub(1, #pre) == pre and #path > #pre then under = true end end
        local x, y, z = tonumber(sd.variables['$posX']), tonumber(sd.variables['$posY']), tonumber(sd.variables['$posZ'])
        if under and x and y and z and near(x, y, z, 0.16) then
          part.props = nil
          bulbs = bulbs + 1
        end
      end
    end
  end
  if hidden > 0 then
    report.hiddenFactory = hidden
    report.hiddenBulbs = bulbs
  end
end

-----------------------------------------------------------------------------------------------
-- ana giris: findParts sonrasi
-----------------------------------------------------------------------------------------------
function I.run(ioCtx, vehicleConfig, res)
  local rootPart, journal, journalC, tree = res[1], res[2], res[3], res[4]
  local activeParts, activePartsData = res[7], res[6]
  if type(rootPart) ~= 'table' or type(journal) ~= 'table' then return end
  local cfg = C.sanitize(vehicleConfig.bcfp)
  if not cfg or not cfg.enabled then return end
  local model = vehicleConfig.model
  local report = {model = model, items = {}, warnings = {}}
  I.lastReport = report

  local declared = declaredVars(rootPart, journal, vehicleConfig.vars)
  -- arac ortami: dugum bulutu, yuzey modeli, fabrika konumlari (onbellekli)
  local env
  do
    local okE, e = pcall(E.forLoad, ioCtx, vehicleConfig, res)
    if okE and type(e) == 'table' then
      env = e
    else
      U.log('E', 'arac ortami kurulamadi: ' .. tostring(e))
      report.warnings[#report.warnings + 1] = {k = 'envFail', v = tostring(e)}
      local cl = I.collectCloud(rootPart, journal, declared)
      env = {cloud = cl, anchors = G.compute(cl, model), hints = {}, factory = {}, byGroup = {}, warnings = {}, stats = {}}
    end
  end
  local cloud = env.cloud
  local anchors = env.anchors
  report.anchors = anchors
  report.envKey = env.key
  local vehSigs, vehSounds = collectVehicleSigs(rootPart, journal)
  local placed = {}
  local vehNames, vehGroups = {}, {}
  definedNodes(rootPart, vehNames, vehGroups)
  for _, j in ipairs(journal) do if type(j[2]) == 'table' then definedNodes(j[2], vehNames, vehGroups) end end
  local ctx = {items = {}, cfg = cfg, model = model, anchors = anchors, foreignDirs = {}, cloudCount = 0, envKey = env.key}
  for _ in pairs(cloud) do ctx.cloudCount = ctx.cloudCount + 1 end

  local function addEntries(list, preList)
    for _, uj in ipairs(list) do journal[#journal + 1] = uj end
    for _, uj in ipairs(preList) do journalC[#journalC + 1] = uj end
  end

  local M = cfg.master
  local arrays, mlbars = 0, 0
  local firstML = true

  for _, o in ipairs(cfg.items) do
    if o.on then
      local okItem, err = pcall(function()
        local idx = C.itemIndex(o.id)
        local rep = {id = o.id, kind = o.kind}
        report.items[#report.items + 1] = rep
        local slotRoot = '/bcfp_' .. o.id .. '/'
        local rootSlotDef = {name = 'bcfp_' .. o.id, allowTypes = {'bcfp_injected'}, denyTypes = {}, description = 'BCFP PRO'}

        if o.kind == 'copy' then
          local env = {}
          local nsUsed = nil
          env.getPart = function(name)
            local p = jbeamIO.getPart(ioCtx, name)
            if p then return p end
            if o.ns and Cat then
              local fp = Cat.getForeignPart(o.ns, name)
              if fp then nsUsed = o.ns return fp end
            end
            return nil
          end
          local root = env.getPart(o.part)
          if not root then
            rep.error = {k = 'noPart', v = tostring(o.part)}
            report.warnings[#report.warnings + 1] = rep.error
            return
          end
          local cross = (nsUsed ~= nil) and (nsUsed ~= ('/vehicles/' .. tostring(model) .. '/'))
          if cross then ctx.foreignDirs[nsUsed] = true end
          rep.cross = cross
          local orig
          for _, j in ipairs(journal) do
            if type(j[2]) == 'table' and j[2].partName == o.part and not (type(j[5]) == 'string' and j[5]:find('^/bcfp_')) then orig = j break end
          end
          rep.hasOriginal = orig ~= nil
          local anchor = o.anchor
          if anchor == 'orig' and (not orig or cross) then anchor = 'roof' end
          local baseSO = {}
          if anchor == 'orig' and orig then baseSO = stripSlotOptions(deepcopy(orig[4] or {})) end
          -- kok slot degiskenleri: orijinalin slot zincirindeki (ust slotlar dahil) degiskenler
          local rootVars = {}
          if orig then
            local chain, cur, guard = {}, orig, 0
            while cur and guard < 60 do
              guard = guard + 1
              chain[#chain + 1] = cur
              local parent, found = cur[1], nil
              for _, j in ipairs(journal) do if j[2] == parent then found = j break end end
              cur = found
            end
            for i = #chain, 1, -1 do
              local sv = type(chain[i][6]) == 'table' and chain[i][6].variables
              if type(sv) == 'table' then for k, v in pairs(sv) do rootVars[k] = deepcopy(v) end end
            end
          end
          if o.scale and abs(o.scale - 1) > 1e-4 then rootVars['$scale'] = o.scale end
          local litVars = {}
          for k, v in pairs(declared) do litVars[k] = v end
          litVars = literalVars({variables = rootVars}, litVars)
          if litVars['$scale'] == nil then litVars['$scale'] = 1 end

          local treeNode = orig and findTreeNode(tree, orig[5]) or nil
          local out = {pre = {}, post = {}, list = {}}
          local rootUj = {rootPart, root, 1, baseSO, slotRoot .. o.part, rootSlotDef}
          fillCopy(env, root, slotRoot, baseSO, 2, treeNode, litVars, out)

          -- alt parca filtresi: araca (kopya disina) bagli gorsel alt parcalari (izgara flasorleri, far
          -- wig-wag kapaklari ...) varsayilan olarak alma; sadece lambanin kendisini kopyala
          local own, ownGroups = {}, {}
          definedNodes(root, own, ownGroups)
          for _, e in ipairs(out.list) do definedNodes(e.uj[2], own, ownGroups) end
          local dropped = {}
          local keepParts = {root}
          for _, e in ipairs(out.list) do
            local part = e.uj[2]
            if dropped[e.parent] then
              dropped[part] = true
            elseif o.subs ~= 1 and hasVisual(part) and usesExternal(part, own, ownGroups, e.vars) then
              local selfNodes = {}
              definedNodes(part, selfNodes)
              if next(selfNodes) == nil then
                dropped[part] = true
                rep.droppedSubs = (rep.droppedSubs or 0) + 1
              end
            end
            if not dropped[part] then keepParts[#keepParts + 1] = part end
          end
          local function keep(list)
            local r = {}
            for _, uj in ipairs(list) do if not dropped[uj[2]] then r[#r + 1] = uj end end
            return r
          end
          local pre, post = keep(out.pre), keep(out.post)

          -- kontrolcu / ses tekrarini onle
          rep.ctrlRemoved, rep.soundRemoved = 0, 0
          for _, part in ipairs(keepParts) do
            rep.ctrlRemoved = rep.ctrlRemoved + dedupeControllers(part, vehSigs, o.ctrl == 1)
            rep.soundRemoved = rep.soundRemoved + dedupeSounds(part, vehSounds)
          end
          -- performans secimi: gercek isik kaynaklari (lens parlamasi ve desen aynen kalir)
          reduceLights(keepParts, o.lsrc, rep)

          -- konum: ham sinir kutusu -> montaj noktasi
          local entries = {{part = root, so = baseSO, vars = litVars}}
          for _, uj in ipairs(pre) do
            local vv = litVars
            for _, e in ipairs(out.list) do if e.uj == uj then vv = e.vars break end end
            entries[#entries + 1] = {part = uj[2], so = uj[4], vars = vv}
          end
          local bb = bbox(entries) or {cx = 0, cy = 0, cz = 0, z0 = 0, x0 = -0.5, x1 = 0.5, y0 = -0.2, y1 = 0.2, z1 = 0.1}
          rep.bbox = {U.r(bb.x0 or 0, 3), U.r(bb.y0 or 0, 3), U.r(bb.z0 or 0, 3), U.r(bb.x1 or 0, 3), U.r(bb.y1 or 0, 3), U.r(bb.z1 or 0, 3)}
          local T = {x = o.x, y = o.y, z = o.z}
          if anchor ~= 'orig' then
            if anchor == 'custom' then
              T = {x = o.x, y = o.y, z = o.z}
            else
              local hx = max(0.15, ((bb.x1 or 0.5) - (bb.x0 or -0.5)) / 2 - 0.05)
              local hy = max(0.05, ((bb.y1 or 0.2) - (bb.y0 or -0.2)) / 2)
              local A = I.roofPoint(env, hx, hy, o.y)
              T = {x = A.x - bb.cx + o.x, y = A.y - bb.cy, z = A.z - (bb.z0 or 0) + 0.006 + o.z}
              rep.roofSrc = A.src
            end
          end
          rep.anchor = anchor
          rep.T = {U.r(T.x, 3), U.r(T.y, 3), U.r(T.z, 3)}
          local rot = {yaw = o.yaw, pitch = o.pitch, roll = o.roll}
          local W = {x = bb.cx + T.x, y = bb.cy + T.y, z = bb.cz + T.z}   -- dunya uzayinda donme merkezi
          setTransform(baseSO, T, rot, W)
          for _, uj in ipairs(pre) do setTransform(uj[4], T, rot, W) end

          -- eksik degiskenleri kok slota tasi
          local tokens = {}
          for _, part in ipairs(keepParts) do
            for k, v in pairs(part) do
              if k ~= 'variables' and k ~= 'information' then collectVarTokens(v, tokens, 0) end
            end
          end
          local declaredInTree = {}
          for _, part in ipairs(keepParts) do
            local v = part.variables
            if isList(v) then
              for r = 2, #v do if isList(v[r]) and type(v[r][1]) == 'string' then declaredInTree[v[r][1]] = true end end
            end
          end
          for _, uj in ipairs(pre) do
            local sv = uj[6] and uj[6].variables
            if type(sv) == 'table' then for k in pairs(sv) do declaredInTree[k] = true end end
          end
          local missing = 0
          for tok in pairs(tokens) do
            if tok ~= '$components' and tok ~= '$prefix' and tok ~= '$suffix' and not declaredInTree[tok] and rootVars[tok] == nil then
              local v = declared[tok]
              if v == nil and tok == '$scale' then v = 1 end
              if v ~= nil then
                rootVars[tok] = v
                missing = missing + 1
              end
            end
          end
          rep.varsProvided = missing
          if next(rootVars) then rootSlotDef.variables = rootVars end

          -- adlandirma
          local suffix = '_bcfp' .. o.id
          local ownNew = I.renameParts(keepParts, suffix, {rootSlotDef})
          -- baska aractan gelen kopya: araca ait baglantilari hedef araca uyarla
          fixExternalRefs(keepParts, ownNew, cloud, cross, T, rep, vehNames, vehGroups)
          if cross then
            -- baska aracin kirislerini kaldir (govdeye baglanti Phase1'de yeniden kurulur)
            rep.crossVehicle = true
          end

          local list, preList = {}, {}
          preList[1] = rootUj
          for _, uj in ipairs(pre) do preList[#preList + 1] = uj end
          for _, uj in ipairs(post) do list[#list + 1] = uj end
          list[#list + 1] = rootUj
          addEntries(list, preList)
          if activeParts then activeParts[slotRoot .. o.part] = o.part end

          local ownList = {}
          for n in pairs(ownNew) do ownList[#ownList + 1] = n end
          ctx.items[#ctx.items + 1] = {id = o.id, kind = 'copy', own = ownList, yaw = o.yaw, path = slotRoot,
            attach = o.attach, cross = cross, part = o.part, anchor = anchor, T = T, bbox = bb,
            name = o.name or (activePartsData and activePartsData[o.part] and activePartsData[o.part].information and activePartsData[o.part].information.name) or (root.information and root.information.name) or o.part}
          rep.parts = #keepParts
          rep.nodes = #ownList

        elseif o.kind == 'array' then
          arrays = arrays + 1
          local dims = Un.dims(o)
          local lay = Pl.layout(o, env, dims)
          if lay.none then
            rep.error = {k = 'noZone', v = tostring(o.anchor)}
            report.warnings[#report.warnings + 1] = rep.error
            ctx.items[#ctx.items + 1] = {id = o.id, kind = 'array', own = {}, path = slotRoot, attach = 'synthetic', num = idx,
              anchor = o.anchor, src = 'none', heads = {}, head = o.head}
            arrays = arrays - 1
            return
          end
          local bind = E.bind(env, o, lay)
          local part, own = Gn.arrayPart(o, lay, bind, M, idx)
          local uj = {rootPart, part, 1, {}, slotRoot .. part.partName, rootSlotDef}
          addEntries({uj}, {uj})
          local heads = {}
          for _, sd in ipairs({'L', 'R'}) do
            for _, h in ipairs(lay[sd] or {}) do
              heads[#heads + 1] = {U.r(h.x, 3), U.r(h.y, 3), U.r(h.z, 3), U.r(h.yaw, 1), U.r(h.tilt or 0, 1)}
              placed[#placed + 1] = {h.x, h.y, h.z}
            end
          end
          ctx.items[#ctx.items + 1] = {id = o.id, kind = 'array', own = own, path = slotRoot, attach = 'synthetic', num = idx,
            anchor = o.anchor, src = lay.src, heads = heads, head = o.head, gap = U.r(lay.gap, 2), x0 = U.r(lay.x0, 1),
            bound = (bind.L and bind.L.groups) and table.concat(bind.L.groups, '+') or (bind.own and 'kendi' or '-')}
          rep.nodes = #own
          rep.src = lay.src
          rep.heads = #heads

        elseif o.kind == 'mlbar' then
          mlbars = mlbars + 1
          local part, own = Gn.mlbarPart(o, M, idx, firstML)
          firstML = false
          local T
          if o.anchor == 'custom' then
            T = {x = o.x, y = o.y, z = o.z}
          else
            local A = I.roofPoint(env, o.len / 200 - 0.05, 0.15, o.y)
            T = {x = A.x + o.x, y = A.y, z = A.z + 0.002 + o.z}
            rep.roofSrc = A.src
          end
          local so = {}
          setTransform(so, T, {yaw = o.yaw, pitch = o.pitch, roll = o.roll}, {x = T.x, y = T.y, z = T.z + 0.04})
          local uj = {rootPart, part, 1, so, slotRoot .. part.partName, rootSlotDef}
          addEntries({uj}, {uj})
          ctx.items[#ctx.items + 1] = {id = o.id, kind = 'mlbar', own = own, yaw = o.yaw, path = slotRoot, attach = 'synthetic',
            T = T, len = o.len, anchor = o.anchor, src = rep.roofSrc}
          rep.nodes = #own
        end
      end)
      if not okItem then
        report.warnings[#report.warnings + 1] = {k = 'itemFail', v = tostring(o.id) .. ': ' .. tostring(err)}
        U.log('E', 'oge eklenemedi ' .. tostring(o.id) .. ': ' .. tostring(err))
      end
    end
  end

  if M.hideFactory == 1 and arrays > 0 then
    local okH, errH = pcall(hideFactoryHeads, env, journal, placed, declared, report)
    if not okH then U.log('W', 'fabrika cakarlari gizlenemedi: ' .. tostring(errH)) end
  end

  if arrays > 0 or mlbars > 0 then
    local master = Gn.masterPart(M, nil)
    local slotDef = {name = 'bcfp_master', allowTypes = {'bcfp_injected'}, denyTypes = {}, description = 'BCFP PRO'}
    local uj = {rootPart, master, 1, {}, '/bcfp_master/bcfp_master', slotDef}
    local list, preList = {}, {uj}
    -- siren sesi (aracta yoksa ve secildiyse)
    if M.siren ~= '' and not vehSounds.siren then
      local sp = jbeamIO.getPart(ioCtx, M.siren)
      if sp and isList(sp.soundscape) then
        local suj = {master, sp, 2, {}, '/bcfp_master/soundscape_siren/' .. M.siren, {name = 'soundscape_siren', allowTypes = {'soundscape_siren'}, denyTypes = {}}}
        preList[#preList + 1] = suj
        list[#list + 1] = suj
        report.siren = M.siren
      end
    end
    list[#list + 1] = uj
    addEntries(list, preList)
    ctx.hasMaster = true
  end

  I.ctxByConfig[vehicleConfig] = ctx
  report.ok = true
end

-----------------------------------------------------------------------------------------------
-- Phase1: eklenen parcalari govdeye bagla
-----------------------------------------------------------------------------------------------
local ATTACH_EXCLUDE_EXTRA = {'door', 'hood', 'trunk', 'tailgate', 'hatch', 'glass', 'window', 'mirror', 'seat'}
local ANCHOR_ALLOW = {
  trunk = {'trunk', 'tailgate', 'hatch'}, bumperF = {'bumper'}, bumperR = {'bumper'}, grille = {'grille', 'radsupport', 'bumper', 'hood'},
  mirrors = {'mirror', 'door'}, sideRear = {'door'},
}

local function nodeGroupsList(n)
  local g = n.group
  if type(g) == 'string' then return {g} end
  if type(g) == 'table' then return g end
  return {}
end

function I.phase1(vehicle, vehicleConfig)
  local ctx = I.ctxByConfig[vehicleConfig]
  if not ctx or type(vehicle) ~= 'table' or type(vehicle.nodes) ~= 'table' then return end
  local byName = {}
  local injected = {}
  for cid, n in pairs(vehicle.nodes) do
    if type(n) == 'table' and type(n.name) == 'string' then
      byName[n.name] = n
      if n.name:find('_bcfp', 1, true) or n.name:find('^bcfp_u') then injected[n] = true end
    end
  end
  local stats = {beams = 0, items = 0}
  for _, it in ipairs(ctx.items) do
    local own = {}
    for _, nm in ipairs(it.own or {}) do
      local n = byName[nm]
      if n and n.pos then own[#own + 1] = n end
    end
    if #own > 0 and it.attach ~= 'orig' then
      stats.items = stats.items + 1
      local allow = ANCHOR_ALLOW[it.anchor or '']
      local function candidateOk(n, strict)
        if injected[n] or not n.pos or n.cid == nil then return false end
        local gl = nodeGroupsList(n)
        for _, g in ipairs(gl) do
          if U.containsAny(g, G.EXCLUDE) then return false end
        end
        if strict then
          local allowed = false
          if allow then
            for _, g in ipairs(gl) do if U.containsAny(g, allow) then allowed = true end end
          end
          if not allowed then
            for _, g in ipairs(gl) do if U.containsAny(g, ATTACH_EXCLUDE_EXTRA) then return false end end
          end
        end
        return true
      end
      -- ayak dugumleri: kopyalarda en alttaki dugumler, kendi uretimlerimizde hepsi
      local feet = {}
      if it.kind == 'copy' or it.kind == 'mlbar' then
        local zmin = math.huge
        for _, n in ipairs(own) do zmin = min(zmin, n.pos.z) end
        for _, n in ipairs(own) do if n.pos.z <= zmin + 0.045 then feet[#feet + 1] = n end end
        if #feet > 10 then
          table.sort(feet, function(a, b) return abs(a.pos.x) > abs(b.pos.x) end)
          local f2 = {}
          for i = 1, 10 do f2[i] = feet[i] end
          feet = f2
        end
        if #feet < 2 then feet = own end
      else
        feet = own
      end
      local k = (it.kind == 'array') and 2 or 3
      local maxD = (it.kind == 'array') and 0.9 or 1.1
      local beamOpts = (it.kind == 'array')
        and {beamSpring = 220000, beamDamp = 16, beamDeform = 9000, beamStrength = 26000}
        or {beamSpring = 401000, beamDamp = 60, beamDeform = 7000, beamStrength = 30000}
      local made = 0
      for _, f in ipairs(feet) do
        local best = {}
        for _, strict in ipairs({true, false}) do
          for _, n in pairs(vehicle.nodes) do
            if type(n) == 'table' and candidateOk(n, strict) then
              local d = (n.pos - f.pos):squaredLength()
              if d < maxD * maxD then
                if #best < k then
                  best[#best + 1] = {n = n, d = d}
                  table.sort(best, function(a, b) return a.d < b.d end)
                elseif d < best[#best].d then
                  best[#best] = {n = n, d = d}
                  table.sort(best, function(a, b) return a.d < b.d end)
                end
              end
            end
          end
          if #best >= k then break end
        end
        for _, b in ipairs(best) do
          local opts = {
            beamSpring = beamOpts.beamSpring, beamDamp = beamOpts.beamDamp, beamDeform = beamOpts.beamDeform,
            beamStrength = beamOpts.beamStrength, beamPrecompression = 1, beamLongBound = 1.0, beamShortBound = 1.0,
            breakGroup = 'bcfp_mount_' .. it.id, deformGroup = 'bcfp_mount_' .. it.id .. '_def', deformationTriggerRatio = 0.05,
            partOrigin = 'bcfp_mount', partPath = (it.path or '/bcfp/') .. 'mount', optional = true,
          }
          local bm = jbeamUtils.addBeamWithOptions(vehicle, f.cid, b.n.cid, 0, opts)
          if bm then made = made + 1 end
        end
      end
      it.attachBeams = made
      stats.beams = stats.beams + made
    end
  end
  ctx.attachStats = stats
end

-----------------------------------------------------------------------------------------------
-- Phase2: kopyalarda isik yonu, yabanci klasorler, calisma bilgisi
-----------------------------------------------------------------------------------------------
local materialDirsLoaded = {}
local function loadMaterialsDir(path)
  if materialDirsLoaded[path] or not FS then return end
  materialDirsLoaded[path] = true
  local ok, files = pcall(function() return FS:findFiles(path, '*materials.json\t*.cs', -1, true, false) end)
  if not ok or type(files) ~= 'table' then return end
  for _, f in ipairs(files) do
    if f:find('.json', 1, true) then
      if loadJsonMaterialsFile then pcall(loadJsonMaterialsFile, f) end
    elseif TorqueScriptLua and TorqueScriptLua.exec then
      pcall(TorqueScriptLua.exec, f)
    end
  end
end
I.loadMaterialsDir = loadMaterialsDir

function I.onExtensionUnloadedReset() materialDirsLoaded = {} end

function I.phase2(vehicle, vehicleConfig)
  local ctx = I.ctxByConfig[vehicleConfig]
  if not ctx then return nil end
  -- kopyalarda isiklarin (spot) yatay acisi: nodeRotate prop'larin global donusunu cevirmez
  local yawById = {}
  for _, it in ipairs(ctx.items) do
    if (it.kind == 'copy' or it.kind == 'mlbar') and abs(it.yaw or 0) > 1e-4 then yawById[it.path] = it.yaw end
  end
  if next(yawById) and type(vehicle.props) == 'table' then
    for _, prop in pairs(vehicle.props) do
      if type(prop) == 'table' and type(prop.partPath) == 'string' and type(prop.baseRotationGlobal) == 'table' then
        local m = prop.partPath:match('^(/bcfp_[%w]+/)')
        local yaw = m and yawById[m]
        if yaw then prop.baseRotationGlobal.z = (tonumber(prop.baseRotationGlobal.z) or 0) - yaw end
      end
    end
  end
  -- baska aracin klasoru: model ve materyal arama yolu
  if next(ctx.foreignDirs) then
    vehicle.directoriesLoaded = vehicle.directoriesLoaded or {}
    for dir in pairs(ctx.foreignDirs) do
      local present = false
      for _, d in ipairs(vehicle.directoriesLoaded) do if d == dir then present = true end end
      if not present then table.insert(vehicle.directoriesLoaded, dir) end
      loadMaterialsDir(dir)
    end
  end
  local items = {}
  for _, it in ipairs(ctx.items) do
    items[#items + 1] = {id = it.id, kind = it.kind, name = it.name, part = it.part, anchor = it.anchor,
      attachBeams = it.attachBeams or 0, cross = it.cross and true or false, src = it.src, heads = it.heads,
      head = it.head, gap = it.gap, x0 = it.x0, bound = it.bound,
      T = it.T and {U.r(it.T.x, 3), U.r(it.T.y, 3), U.r(it.T.z, 3)} or nil}
  end
  vehicle.bcfpRuntime = {v = 3, items = items, attach = ctx.attachStats, envKey = ctx.envKey,
    hasMaster = ctx.hasMaster or false, warnings = I.lastReport and I.lastReport.warnings or {},
    hiddenFactory = I.lastReport and I.lastReport.hiddenFactory or 0}
  return ctx
end

return I
