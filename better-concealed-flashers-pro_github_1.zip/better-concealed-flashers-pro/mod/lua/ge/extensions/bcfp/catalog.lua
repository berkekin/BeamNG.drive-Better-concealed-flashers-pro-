-- Better Concealed Flashers PRO - lamba kutuphanesi
--  * araca takili uyari isigi parcalari (kopyalanabilir)
--  * oyundaki ve kurulu modlardaki tum tepe lambasi / LED bar / flasor parcalari (tarama)
--  * baska bir aracin klasorundeki parcayi okuma (yabanci parca saglayici)
local Cat = {}
local U, S

local clock = os.clock
local tableSchema

function Cat.init(mods)
  U, S = mods.U, mods.S
  tableSchema = require('jbeam/tableSchema')
end

-- kesin uyari isigi kelimeleri (tepe lambasi, flasor, tepe lambasi markalari ...)
local LIGHT_WORDS = {
  'lightbar', 'light_bar', 'light bar', 'beacon', 'siren', 'strobe', 'flasher', 'cakar', 'rotator', 'whelen',
  'federal', 'code3', 'valor', 'liberty', 'legacy', 'jetsolaris', 'lightrack', 'visorbar', 'visor bar', 'deckbar',
  'deck light', 'dashlight', 'dash light', 'blaulicht', 'kojak', 'wigwag', 'wig-wag', 'wig_wag', 'hideaway',
  'traffic advisor', 'arrowstick', 'arrow stick', 'mini bar', 'mini_bar', 'lightstick', 'warning light',
  'emergency light', 'grille light', 'grill light',
}
-- kurum / gorev kelimeleri: sadece arac donanimi degilse (kapi paneli, laptop, konsol ...)
local AGENCY_WORDS = {
  'police', 'polis', 'polizei', 'policia', 'warning', 'emergency', 'ambulance', 'ambulans', 'rescue', 'firetruck',
  'fire truck', 'pushbar', 'push bar', 'interceptor', 'unmarked', 'undercover', 'concealed', 'gendarm', 'pursuit',
  'patrol', 'sheriff', 'trooper',
}
-- zayif anahtar kelimeler: sadece asagidaki "normal arac parcasi / lambasi" kelimeleri yoksa
local WEAK = {'lights', 'light', 'led'}
local NOT_WARNING = {
  'taillight', 'tail light', 'tail_light', 'headlight', 'head light', 'head_light', 'foglight', 'fog light',
  'fog_light', 'marker', 'trunklight', 'trunk light', 'trunk_light', 'brake', 'reverse', 'indicator', 'signal',
  'interior', 'dome', 'license', 'plate', 'gauge', 'cluster', 'chicken', 'running', 'drl', 'cornering', 'puddle',
  'clearance', 'glovebox', 'rooflights', 'door', 'panel', 'laptop', 'console', 'computer', 'radio', 'seat', 'cage',
  'partition', 'skin', 'livery', 'decal', 'antenna', 'gun', 'mirror', 'screen', 'paint', 'backlight', 'window',
  'bulb', 'chmsl', 'stop light', 'stoplight', 'stop_light', 'nosecone', 'nose light', 'noselight', 'taillamp',
  'headlamp', 'sidemarker', 'tail lamp', 'number plate',
}
local KEYWORDS = {}
for _, w in ipairs(LIGHT_WORDS) do KEYWORDS[#KEYWORDS + 1] = w end
Cat.KEYWORDS = KEYWORDS

-- 3: kesin uyari isigi, 2: polis / kurum parcasi (donanim degil), 1: olasi (isimsiz LED / lamba), 0: degil
local function warningScore(s)
  s = U.lower(s)
  if U.containsWord(s, LIGHT_WORDS) then return 3 end
  local bad = U.containsAny(s, NOT_WARNING)
  if not bad and U.containsWord(s, AGENCY_WORDS) then return 2 end
  if not bad and U.containsAny(s, WEAK) then return 1 end
  return 0
end
Cat.warningScore = warningScore

-----------------------------------------------------------------------------------------------
-- slot bolumunu oyunun io modulu gibi isle (slots -> slots2)
-----------------------------------------------------------------------------------------------
local function processSlots(part)
  if type(part.slots) == 'table' then
    if #part.slots > 0 and type(part.slots[1]) == 'table' and part.slots[1][1] ~= 'type' then
      table.insert(part.slots, 1, {'type', 'default', 'description'})
    end
    local newSlots = {}
    local ok = pcall(tableSchema.processTableWithSchemaDestructive, part.slots, newSlots, nil, true)
    if not ok then newSlots = {} end
    for _, slot in ipairs(newSlots) do
      slot.name = slot.name or slot.type
      slot.allowTypes = {slot.type}
      slot.type = nil
      slot.denyTypes = {}
    end
    part.slots2 = newSlots
    part.slots = nil
  elseif type(part.slots2) == 'table' then
    local newSlots2 = {}
    local ok = pcall(tableSchema.processTableWithSchemaDestructive, part.slots2, newSlots2, nil, true)
    part.slots2 = ok and newSlots2 or {}
  end
end
Cat.processSlots = processSlots

-----------------------------------------------------------------------------------------------
-- yabanci parca saglayici
-----------------------------------------------------------------------------------------------
local nsIndex = {}

local function readJbeam(file)
  local ok, data = pcall(jsonReadFile, file)
  if ok and type(data) == 'table' then return data end
  return nil
end

local function indexNs(ns)
  local idx = nsIndex[ns]
  if idx then return idx end
  idx = {parts = {}, data = {}}
  nsIndex[ns] = idx
  local ok, files = pcall(function() return FS:findFiles(ns, '*.jbeam', -1, false, false) end)
  if not ok or type(files) ~= 'table' then return idx end
  for _, f in ipairs(files) do
    local d = readJbeam(f)
    if d then
      idx.data[f] = d
      for name, p in pairs(d) do
        if type(p) == 'table' and idx.parts[name] == nil then idx.parts[name] = f end
      end
    end
  end
  return idx
end

function Cat.getForeignPart(ns, name)
  if type(ns) ~= 'string' or type(name) ~= 'string' then return nil end
  local idx = indexNs(ns)
  local f = idx.parts[name]
  if not f then return nil end
  local p = idx.data[f] and idx.data[f][name]
  if type(p) ~= 'table' then return nil end
  p = deepcopy(p)
  processSlots(p)
  p.partName = name
  return p
end

function Cat.invalidate()
  nsIndex = {}
end

-----------------------------------------------------------------------------------------------
-- parca ozeti
-----------------------------------------------------------------------------------------------
local function countLights(part)
  local n = 0
  local pr = part.props
  if type(pr) == 'table' then
    for i, row in ipairs(pr) do
      if i > 1 and type(row) == 'table' and (row[2] == 'SPOTLIGHT' or row[2] == 'POINTLIGHT') then n = n + 1 end
    end
  end
  return n
end

local function countRows(sec)
  if type(sec) ~= 'table' then return 0 end
  local n = 0
  for i, row in ipairs(sec) do if i > 1 and type(row) == 'table' and row[1] ~= nil then n = n + 1 end end
  return n
end

local function partInfoName(part)
  local info = part.information
  local nm = info and info.name
  if type(nm) == 'table' then nm = nm.txt end
  return type(nm) == 'string' and nm or nil
end
Cat.partInfoName = partInfoName

function Cat.summarize(name, part)
  local glow = 0
  for _ in pairs(type(part.glowMap) == 'table' and part.glowMap or {}) do glow = glow + 1 end
  local st = part.slotType
  if type(st) == 'table' then st = table.concat(st, ',') end
  local slots = 0
  for _ in ipairs(part.slots2 or part.slots or {}) do slots = slots + 1 end
  return {part = name, name = partInfoName(part) or name, slotType = tostring(st or ''), lights = countLights(part),
          glow = glow, flex = countRows(part.flexbodies), nodes = countRows(part.nodes), slots = slots,
          ctrl = part.controller ~= nil, author = part.information and part.information.authors or nil}
end

local function looksEmergency(name, part)
  local s = name .. ' ' .. tostring(partInfoName(part) or '')
  local st = part.slotType
  if type(st) == 'table' then st = table.concat(st, ' ') end
  s = s .. ' ' .. tostring(st or '')
  local sc = warningScore(s)
  return sc > 0, sc
end
Cat.looksEmergency = looksEmergency

-----------------------------------------------------------------------------------------------
-- aractaki kopyalanabilir parcalar
-----------------------------------------------------------------------------------------------
function Cat.installed(vdata)
  local out = {}
  if type(vdata) ~= 'table' then return out end
  local ap, apd = vdata.activeParts or {}, vdata.activePartsData or {}
  -- yol -> alt agactaki isik sayisi
  local lightsAt = {}
  for _, prop in pairs(vdata.props or {}) do
    if type(prop) == 'table' and (prop.mesh == 'SPOTLIGHT' or prop.mesh == 'POINTLIGHT') and type(prop.partPath) == 'string' then
      lightsAt[prop.partPath] = (lightsAt[prop.partPath] or 0) + 1
    end
  end
  local paths = {}
  for path, name in pairs(ap) do
    if type(path) == 'string' and not path:find('^/bcfp_') and type(name) == 'string' then paths[#paths + 1] = path end
  end
  table.sort(paths, function(a, b) return #a < #b or (#a == #b and a < b) end)
  local taken = {}
  local accepted = {}
  local function underAccepted(p)
    for _, sp in ipairs(accepted) do
      if #p > #sp and p:sub(1, #sp) == sp then return true end
    end
    return false
  end
  for _, path in ipairs(paths) do
    local name = ap[path]
    local part = apd[name]
    -- listelenmis bir lambanin alt parcasi (renk, desen, modul): ust parcayla zaten kopyalanir
    if type(part) == 'table' and not taken[name] and not underAccepted(path) then
      -- bu parcanin ve alt parcalarinin isiklari: yol oneki = parcanin oturdugu slot yolu
      local slotPath = path:match('^(.*/)') or '/'
      local lights = 0
      if slotPath ~= '/' then
        for lp, n in pairs(lightsAt) do
          if lp:sub(1, #slotPath) == slotPath then lights = lights + n end
        end
      end
      local sum = Cat.summarize(name, part)
      local emergency, score = looksEmergency(name, part)
      -- gorunur (modeli olan) ve isigi / parlamasi olan uyari parcalari: ampuller, renk ve desen alt
      -- parcalari (modelsiz) listelenmez; kopyalaninca zaten ust parcayla birlikte gelirler
      -- orijinal ornegin sinir kutusu (kopyalari dizerken aralik icin); kendi dugumu olmayan parcalar
      -- (renk / desen modulu, govdeye yapisik flasor) ayri kopyalanamaz: kopya ayni yerde kalir
      local bbox
      if emergency and sum.flex > 0 and (lights > 0 or sum.glow > 0) and slotPath ~= '/' then
        local x0, y0, z0, x1, y1, z1, n = 1e9, 1e9, 1e9, -1e9, -1e9, -1e9, 0
        for _, nd in pairs(vdata.nodes or {}) do
          if type(nd) == 'table' and nd.pos and type(nd.partPath) == 'string' and nd.partPath:sub(1, #slotPath) == slotPath then
            local p = nd.pos
            x0, y0, z0 = math.min(x0, p.x), math.min(y0, p.y), math.min(z0, p.z)
            x1, y1, z1 = math.max(x1, p.x), math.max(y1, p.y), math.max(z1, p.z)
            n = n + 1
          end
        end
        if n > 0 then bbox = {x0, y0, z0, x1, y1, z1} end
      end
      if bbox then
        sum.score = score
        sum.bbox = bbox
        sum.path = path
        sum.slotPath = slotPath
        sum.lightsTotal = lights
        sum.depth = select(2, path:gsub('/', ''))
        out[#out + 1] = sum
        taken[name] = true
        -- yol bicimi: /yuva1/yuva2/.../yuvaN/parca; alt parcalar ayni yuva yolunun altindadir
        if slotPath ~= '/' then accepted[#accepted + 1] = slotPath end
      end
    end
  end
  -- kesin uyari isiklari (tepe lambasi, flasor ...) once, sonra isik sayisina gore
  for i, s in ipairs(out) do s._ord = i end
  table.sort(out, function(a, b)
    if (a.score or 0) ~= (b.score or 0) then return (a.score or 0) > (b.score or 0) end
    if (a.lightsTotal or 0) ~= (b.lightsTotal or 0) then return (a.lightsTotal or 0) > (b.lightsTotal or 0) end
    return a._ord < b._ord
  end)
  for _, s in ipairs(out) do s._ord = nil end
  return out
end

-----------------------------------------------------------------------------------------------
-- oyun + mod kutuphanesi taramasi (kare basina zaman butcesiyle)
-----------------------------------------------------------------------------------------------
Cat.scan = {state = 'idle', results = {}, done = 0, total = 0}
local scanCo

local function modNameFor(file)
  local mm = extensions and extensions.core_modmanager
  if mm and mm.getModForFilename then
    local ok, name = pcall(mm.getModForFilename, file)
    if ok and type(name) == 'string' then return name end
  end
  return nil
end

local function scanBody(deep)
  local files = {}
  local ok, all = pcall(function() return FS:findFiles('/vehicles/', '*.jbeam', -1, true, false) end)
  if not ok or type(all) ~= 'table' then all = {} end
  for _, f in ipairs(all) do
    local lf = f:lower()
    if deep or warningScore(lf) >= 2 then files[#files + 1] = f end
  end
  Cat.scan.total = #files
  Cat.scan.done = 0
  local results = {}
  local t0 = clock()
  for i, f in ipairs(files) do
    local d = readJbeam(f)
    if d then
      local ns = f:match('^(/vehicles/[^/]+/)')
      -- dosya yolu kesin isik kelimesi iceriyorsa (ornek: .../lightbars/whelen.jbeam) icindeki adsiz parcalar da aday
      local fileStrong = warningScore(f:lower()) == 3
      for name, part in pairs(d) do
        if type(part) == 'table' and part.slotType then
          local sum = Cat.summarize(name, part)
          local _, sc = looksEmergency(name, part)
          local nameOk = sc >= 2 or (fileStrong and (sc == 1 or not U.containsAny(name .. ' ' .. tostring(sum.name), NOT_WARNING)))
          -- ana parca: modeli (govde) ya da alt yuvalari (moduller) olan, isikli veya isik modulu tasiyan parca
          if nameOk and (sum.flex > 0 or sum.slots > 0) and (sum.lights > 0 or sum.glow > 0 or sum.slots > 0) then
            sum.score = sc
            sum.ns = ns
            sum.file = f
            sum.vehicle = ns and ns:match('^/vehicles/([^/]+)/') or '?'
            sum.mod = modNameFor(f)
            results[#results + 1] = sum
          end
        end
      end
    end
    Cat.scan.done = i
    if clock() - t0 > 0.008 then
      coroutine.yield()
      t0 = clock()
    end
  end
  table.sort(results, function(a, b)
    if a.vehicle ~= b.vehicle then return tostring(a.vehicle) < tostring(b.vehicle) end
    return tostring(a.name) < tostring(b.name)
  end)
  return results
end

function Cat.startScan(deep)
  if Cat.scan.state == 'running' then return end
  Cat.scan = {state = 'running', results = {}, done = 0, total = 0, deep = deep and true or false}
  scanCo = coroutine.create(function() return scanBody(deep) end)
end

-- her karede cagrilir; tarama bitince true doner
function Cat.update()
  if not scanCo then return false end
  local ok, res = coroutine.resume(scanCo)
  if not ok then
    Cat.scan.state = 'error'
    Cat.scan.error = tostring(res)
    scanCo = nil
    return true
  end
  if coroutine.status(scanCo) == 'dead' then
    Cat.scan.results = res or {}
    Cat.scan.state = 'done'
    scanCo = nil
    return true
  end
  return false
end

return Cat
