-- Better Concealed Flashers PRO 3 - Isik Studyosu
-- Aractaki tum uyari isiklarini (orijinal tepe lambalari, kopyalar, modlardan gelen lambalar ve kendi LED'lerimiz)
-- gruplara ayirir ve her grup icin isik siddetini (carpan / kandela / lumen / luks@mesafe), menzili, isin acisini,
-- parlama halkasini (flare), lens parlamasini (emissive), golgeyi ve renk profilini (orijinal / gercekci LED /
-- canli) ayarlar. Ayni hesap hem yuklemede (Phase2) hem de canli onizlemede kullanilir.
local S = {}
local U, P, C, Gn

local min, max, sqrt, pi, cos, rad, floor = math.min, math.max, math.sqrt, math.pi, math.cos, math.rad, math.floor

function S.init(mods) U, P, C, Gn = mods.U, mods.P, mods.C, mods.Gn end

S.FLARE_TYPES = {
  {id = 0, tr = 'Orijinal'},
  {id = 1, tr = 'Yumusak parilti', name = 'vehicleBrakeLightFlare'},
  {id = 2, tr = 'Far parlamasi', name = 'vehicleHeadLightFlare'},
  {id = 3, tr = 'Yildiz (kirinim)', name = 'BNG_LightFlare_Diffraction'},
  {id = 4, tr = 'Isinsal', name = 'BNG_SpokeFlare_1'},
  {id = 5, tr = 'Genis hale', name = 'BNG_Sunflare_2'},
  {id = 6, tr = 'Kapali', name = ''},
}

-- uyari isigi tespiti (parca / slot adlarinda ve isik fonksiyonlarinda)
-- kesin isik kelimeleri (her zaman uyari isigi)
local LIGHT_WORDS = {
  'lightbar', 'light_bar', 'light bar', 'beacon', 'flasher', 'strobe', 'wigwag', 'wig_wag', 'wig-wag', 'siren', 'cakar',
  'valor', 'whelen', 'federal', 'code3', 'legacy', 'liberty', 'rotator', 'visorbar', 'visor_bar', 'visor_light',
  'deckbar', 'deck_light', 'decklight', 'dashlight', 'dash_light', 'lightrack', 'traffic_advisor', 'grille_light',
  'hideaway', 'blaulicht', 'kojak', 'mini bar', 'mini_bar', 'lightstick', 'bcfp',
}
-- kurum / gorev kelimeleri: ancak arac donanimi (kapi paneli, laptop, konsol ...) degilse
local EMERGENCY_WORDS = {
  'police', 'polis', 'polizei', 'policia', 'emergency', 'pushbar', 'push_bar', 'ambulance', 'ambulans', 'firetruck',
  'fire_truck', 'rescue', 'warning', 'interceptor', 'unmarked', 'undercover', 'concealed', 'gendarm', 'sheriff',
  'trooper', 'patrol', 'pursuit',
}
local NOT_EMERGENCY = {
  'laptop', 'console', 'door', 'panel', 'computer', 'radio', 'interior', 'dome', 'seat', 'cage', 'partition', 'skin',
  'livery', 'antenna', 'gun', 'mirror', 'glovebox', 'gauge', 'cluster', 'screen', 'headlight', 'taillight', 'foglight',
  'reverselight_lens', 'trunk_light', 'license', 'plate',
}
local function emergencyName(s)
  if type(s) ~= 'string' or s == '' then return false end
  if U.containsWord(s, LIGHT_WORDS) then return true end
  return U.containsWord(s, EMERGENCY_WORDS) and not U.containsAny(s, NOT_EMERGENCY)
end
S.emergencyName = emergencyName
local VEHICLE_FUNCS = {
  lowbeam = true, highbeam = true, lowhighbeam = true, brakelights = true, brake = true, reverse = true,
  signal_L = true, signal_R = true, signal_left_input = true, signal_right_input = true, fog = true,
  parking = true, lights = true, running = true, hazard = true, lowhighbeam_signal_L = true,
  lowhighbeam_signal_R = true, dome = true, interior = true, ignition = true,
}
local EMERGENCY_FUNC_PATTERNS = {'^lightbar', '^[LR]%d+_', '^wigwag', '^highbeam_wigwag', '^reverse_wigwag', 'flash', 'beacon', 'strobe',
  'siren', 'police', 'emerg', '^bcfp_', '^uel', 'lightbar'}

local function isEmergencyFunc(func)
  if type(func) ~= 'string' then return false end
  if VEHICLE_FUNCS[func] then return false end
  for _, p in ipairs(EMERGENCY_FUNC_PATTERNS) do
    if func:find(p) then return true end
  end
  return false
end
S.isEmergencyFunc = isEmergencyFunc

local function isLight(prop)
  return type(prop) == 'table' and (prop.mesh == 'SPOTLIGHT' or prop.mesh == 'POINTLIGHT')
end

-- grup anahtari ve adi
local function groupFor(prop, vehicle)
  local path = prop.partPath
  if type(path) == 'string' then
    local id = path:match('^/bcfp_([%w]+)/')
    if id then
      if id == 'master' then return 'bcfp:master', 'Gizli Cakar PRO', 'bcfp' end
      return 'bcfp:' .. id, nil, 'bcfp'
    end
    -- en kisa uyari isigi slotu
    local spm = vehicle.slotPartMap or {}
    local apd = vehicle.activePartsData or {}
    local acc = '/'
    for seg in path:gmatch('([^/]+)/') do
      acc = acc .. seg .. '/'
      local pn = spm[acc]
      if type(pn) == 'string' and pn ~= '' then
        local info = apd[pn] and apd[pn].information
        local nm = info and info.name
        if type(nm) == 'table' then nm = nm.txt end
        if emergencyName(seg .. ' ' .. pn .. ' ' .. tostring(nm or '')) then
          return 'o:' .. acc, (type(nm) == 'string' and nm ~= '' and nm or pn), 'orig'
        end
      end
    end
  end
  if isEmergencyFunc(prop.func) then
    local origin = tostring(prop.partOrigin or '?')
    return 'f:' .. origin, origin, 'orig'
  end
  return 'veh', 'Arac isiklari (far, stop ...)', 'veh'
end
S.groupFor = groupFor

local function propCd(prop)
  if prop.mesh == 'SPOTLIGHT' and tonumber(prop.lightIntensityCd) then return tonumber(prop.lightIntensityCd) end
  if prop.mesh == 'POINTLIGHT' and tonumber(prop.lightIntensityLm) then return tonumber(prop.lightIntensityLm) / (4 * pi) end
  return (tonumber(prop.lightBrightness) or 1) * 5000
end

local function colorOf(prop)
  local r, g, b, a = P.toLinear(prop.lightColor)
  if not r then return {1, 1, 1, 255} end
  return {r, g, b, a or 255}
end

-- orijinal degerleri kaydet (yalnizca bir kez)
local function snapshot(prop, key)
  if prop._bcfp then return prop._bcfp end
  local c = colorOf(prop)
  local o = {
    g = key,
    cd = propCd(prop),
    r0 = tonumber(prop.lightRange) or 10,
    i0 = tonumber(prop.lightInnerAngle) or 40,
    o0 = tonumber(prop.lightOuterAngle) or 45,
    f0 = tonumber(prop.flareScale) or 1,
    fn0 = (prop.flareName == nil) and 'vehicleDefaultLightflare' or tostring(prop.flareName),
    c0 = c,
    s0 = prop.lightCastShadows and true or false,
    pt = (prop.mesh == 'POINTLIGHT') and 1 or 0,
    ls = prop.lightScaling ~= nil,
    ph = prop.bcfpPhotometric and 1 or 0,
    own = (prop.bcfpLight ~= nil) and 1 or 0,     -- kendi LED dizimiz: rengi zaten gercek LED tonu, yeniden eslenmez
  }
  -- fotometrik (algilanan) kandela: oyun parlakligi x renk luminansi
  o.lcd = (o.ph == 1) and o.cd or (o.cd * max(P.luminance(c[1], c[2], c[3]), 0.02))
  prop._bcfp = o
  return o
end
S.snapshot = snapshot

-- isik hesabi: orijinal kayit + grup ayari -> yeni degerler
function S.compute(o, s, masterProfile)
  s = s or {}
  local imode = s.imode or 0
  local profile = s.color
  if profile == nil or profile < 0 then profile = masterProfile or 0 end
  local r0, g0, b0 = o.c0[1], o.c0[2], o.c0[3]
  local r, g, b = r0, g0, b0
  if profile and profile > 0 and o.ph ~= 1 and o.own ~= 1 then r, g, b = P.remap(r0, g0, b0, profile) end
  local Y0 = max(P.luminance(r0, g0, b0), 0.02)
  local Y = max(P.luminance(r, g, b), 0.02)
  local outer = o.o0
  if (s.ang or 0) > 0 then outer = s.ang end
  local inner = min(o.i0, outer)
  if (s.ang or 0) > 0 then inner = min(s.inner or 12, outer) end
  local comp = (s.comp or 1) == 1
  -- isik siddeti: parlaklik = kandela / 5000 (oyun birimi); renkli isikta fotometrik dengeleme 1/Y
  local bright
  local cdOrig = o.cd
  if imode == 0 or imode == 1 then
    local k = (imode == 1) and ((s.imult or 100) / 100) or 1
    bright = cdOrig / 5000 * k
    if comp and (r ~= r0 or g ~= g0 or b ~= b0) then bright = bright * Y0 / Y end
  else
    local cd
    if imode == 2 then cd = s.cd or 5000
    elseif imode == 3 then
      local omega = (o.pt == 1) and (4 * pi) or Gn.solidAngle(outer)
      cd = (s.lm or 1500) / omega
    else
      local d = s.luxd or 10
      cd = (s.lux or 50) * d * d
    end
    bright = cd / 5000
    if comp and o.ph ~= 1 then bright = bright / Y end
  end
  bright = max(0, bright)
  local lumCd = bright * 5000 * ((o.ph == 1) and 0.2 or Y)
  local range = o.r0
  local rmode = s.rmode or 0
  if rmode == 1 then range = o.r0 * (s.rmult or 100) / 100
  elseif rmode == 2 then range = s.rng or 40
  elseif rmode == 3 then range = sqrt(lumCd / max(s.rlux or 2, 0.05)) end
  range = U.clamp(range, 0.5, 600)
  local flareName = o.fn0
  local ft = s.flareType or 0
  if ft >= 1 and ft <= 6 then
    flareName = S.FLARE_TYPES[ft + 1].name
  end
  local fbase = o.f0
  if fbase <= 0 then fbase = 0.12 end
  local flareScale = fbase * (s.flare or 100) / 100
  if flareName == '' then flareScale = 0 end
  local shadows = o.s0
  if (s.shadow or 0) == 1 then shadows = false elseif (s.shadow or 0) == 2 then shadows = true end
  return {
    b = bright, range = range, inner = inner, outer = outer, flareName = flareName, flareScale = flareScale,
    color = P.to255(r, g, b, o.c0[4] or 255), shadows = shadows, lumCd = lumCd, profile = profile,
  }
end

-- yuklemede uygula (Phase2)
function S.applyToProp(prop, res)
  prop.lightBrightness = U.r(res.b, 6)
  prop.lightIntensityCd = nil
  prop.lightIntensityLm = nil
  prop.lightRange = U.r(res.range, 3)
  prop.lightInnerAngle = U.r(res.inner, 3)
  prop.lightOuterAngle = U.r(res.outer, 3)
  prop.flareName = res.flareName
  prop.flareScale = U.r(res.flareScale, 5)
  if not prop.bcfpPhotometric then
    prop.lightColor = {r = res.color.r, g = res.color.g, b = res.color.b, a = res.color.a}
  end
  prop.lightCastShadows = res.shadows
end

-- isik olcegi olan (dimmer) isiklarda akkor lamba renk kaymasini (kisildikca turuncuya donme) LED'de kapat.
-- Isik olcegi olmayan isiklara dokunulmaz: onlarin rengi / siddeti yuklemede sabitlenir (canli ayar GE'den).
local function ensureLedScaling(prop, profile)
  if prop.bcfpPhotometric then return end
  if prop.lightScaling == true and profile and profile > 0 then prop.lightScaling = {} end
  local ls = type(prop.lightScaling) == 'table' and prop.lightScaling or nil
  if ls and profile and profile > 0 then
    ls.lightColorOffsetRed, ls.lightColorOffsetGreen, ls.lightColorOffsetBlue = 0, 0, 0
  end
end

local function effective(cfg, key, kind)
  local st = cfg and cfg.studio or {}
  local s = st[key]
  if not s and kind ~= 'veh' then s = st['*'] end
  return s
end
S.effective = effective

-- glowMap kayitlarini gruplara bagla (isik fonksiyonu ortakligi uzerinden)
local function glowFuncs(gm)
  local out = {}
  if type(gm.simpleFunction) == 'string' then out[#out + 1] = gm.simpleFunction
  elseif type(gm.simpleFunction) == 'table' then for k in pairs(gm.simpleFunction) do out[#out + 1] = k end end
  if type(gm.advancedFunction) == 'table' and type(gm.advancedFunction.triggers) == 'table' then
    for _, t in pairs(gm.advancedFunction.triggers) do out[#out + 1] = t end
  end
  return out
end
S.glowFuncs = glowFuncs

-- kendi merdiven materyallerimiz: bcfp_on_<renk>_<L> / bcfp_mlon_<kod>_<L>
local function ladderBase(mat)
  if type(mat) ~= 'string' then return nil end
  local b = mat:match('^(bcfp_on_%w+)_%d$') or mat:match('^(bcfp_mlon_%a)_%d$')
  return b
end
S.ladderBase = ladderBase

function S.glowFor(gm, pct, masterPct)
  local base = ladderBase(gm.on)
  local f = (pct or 100) / 100
  if base then
    local L, onMax = Gn.glowLevel((masterPct or 100) * f)
    return base .. '_' .. L, onMax
  end
  -- yabanci materyal: sadece kisilabilir (en fazla %100)
  local onMax = 1 / max(min(f, 1), 0.02)
  return nil, onMax
end

-- Phase2: tum isiklar
function S.phase2(vehicle, cfg)
  if type(vehicle) ~= 'table' or type(vehicle.props) ~= 'table' then return nil end
  local master = cfg and cfg.master or C.sanitizeMaster(nil)
  local profileDefault = master.colorProfile or 1
  local groups, order = {}, {}
  local funcGroups = {}
  for _, prop in pairs(vehicle.props) do
    if isLight(prop) then
      local key, name, kind = groupFor(prop, vehicle)
      local g = groups[key]
      if not g then
        g = {key = key, name = name, kind = kind, count = 0, spots = 0, points = 0, colors = {}, cdMin = math.huge, cdMax = 0,
             rMin = math.huge, rMax = 0, aMin = math.huge, aMax = 0, funcs = {}}
        groups[key] = g
        order[#order + 1] = key
      end
      if not g.name and name then g.name = name end
      local o = snapshot(prop, key)
      g.count = g.count + 1
      if prop.mesh == 'POINTLIGHT' then g.points = g.points + 1 else g.spots = g.spots + 1 end
      local cls = P.classify(o.c0[1], o.c0[2], o.c0[3])
      if o.ph == 1 then cls = 'multi' end
      g.colors[cls] = (g.colors[cls] or 0) + 1
      g.cdMin, g.cdMax = min(g.cdMin, o.lcd), max(g.cdMax, o.lcd)
      g.rMin, g.rMax = min(g.rMin, o.r0), max(g.rMax, o.r0)
      g.aMin, g.aMax = min(g.aMin, o.o0), max(g.aMax, o.o0)
      if type(prop.func) == 'string' then
        g.funcs[prop.func] = true
        funcGroups[prop.func] = funcGroups[prop.func] or {}
        funcGroups[prop.func][key] = true
      end
      if kind ~= 'veh' then
        local s = effective(cfg, key, kind)
        local res = S.compute(o, s, profileDefault)
        S.applyToProp(prop, res)
        ensureLedScaling(prop, res.profile)
      end
    end
  end
  -- lens parlamasi (glowMap)
  local glowAssigned = {}
  if type(vehicle.glowMap) == 'table' then
    for mat, gm in pairs(vehicle.glowMap) do
      if type(gm) == 'table' then
        local key
        for _, f in ipairs(glowFuncs(gm)) do
          local fg = funcGroups[f]
          if fg then
            for k in pairs(fg) do
              if not key or (key:sub(1, 5) == 'bcfp:' and k:sub(1, 5) ~= 'bcfp:') then key = k end
            end
          end
        end
        if not key and ladderBase(gm.on) then key = 'bcfp:glow' end
        if key and groups[key] and groups[key].kind ~= 'veh' or (key == 'bcfp:glow') then
          local g = groups[key]
          local s = effective(cfg, key, g and g.kind or 'bcfp')
          local pct = s and s.glow or 100
          local isOwn = ladderBase(gm.on) ~= nil
          if isOwn or pct < 99.5 then
            gm._bcfpOn0 = gm._bcfpOn0 or gm.on
            local on, onMax = S.glowFor({on = gm._bcfpOn0}, pct, isOwn and master.glow or 100)
            if on then gm.on = on end
            local prev = type(gm.materialEmissiveScaling) == 'table' and tonumber(gm.materialEmissiveScaling.on_max) or nil
            if not isOwn and prev then onMax = onMax * prev end
            gm.materialEmissiveScaling = gm.materialEmissiveScaling or {}
            gm.materialEmissiveScaling.on_max = U.r(onMax, 4)
          end
          if g then g.glow = (g.glow or 0) + 1 end
          glowAssigned[mat] = key
        end
      end
    end
  end
  -- ayni adli gruplari slot adiyla ayirt et (ornek: sol / sag projektor ampulu)
  local nameCount = {}
  for _, key in ipairs(order) do
    local nm = groups[key].name or key
    nameCount[nm] = (nameCount[nm] or 0) + 1
  end
  for _, key in ipairs(order) do
    local g = groups[key]
    local nm = g.name or key
    if nameCount[nm] > 1 and key:sub(1, 2) == 'o:' then
      local segs = {}
      for seg in key:sub(3):gmatch('([^/]+)') do segs[#segs + 1] = seg end
      local tail = segs[#segs - 1] or segs[#segs]
      if tail then g.name = nm .. ' (' .. tail .. ')' end
    end
  end
  local list = {}
  for _, key in ipairs(order) do
    local g = groups[key]
    local fl = {}
    for f in pairs(g.funcs) do fl[#fl + 1] = f end
    table.sort(fl)
    list[#list + 1] = {key = g.key, name = g.name or g.key, kind = g.kind, count = g.count, spots = g.spots, points = g.points,
      colors = g.colors, cd = {U.r(g.cdMin, 1), U.r(g.cdMax, 1)}, range = {U.r(g.rMin, 2), U.r(g.rMax, 2)},
      angle = {U.r(g.aMin, 1), U.r(g.aMax, 1)}, glow = g.glow or 0, funcs = #fl > 40 and {} or fl}
  end
  return list, glowAssigned
end

return S
