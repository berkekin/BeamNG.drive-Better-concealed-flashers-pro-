-- Better Concealed Flashers PRO 3 - arac ortami
-- Bir aracin (govde konfigurasyonunun) yerlesim icin gereken tum bilgisi tek yerde toplanir ve onbelleklenir:
--   * dugum bulutu (ham jbeam, slot donusumleri uygulanmis) ve grup -> dugum dizini
--   * yuzey modeli (scan.lua): aracin gercek 3B modelleri, cam / govde / lamba siniflariyla
--   * fabrika konumlari (hints.lua): oyunun kendi gizli cakar parcalarinin tam yerleri
--   * yaklasik montaj noktalari (geom.lua): model okunamazsa yedek
-- Ayni ortam hem arac yuklenirken (inject.lua) hem de arayuzde (onizleme, bolge listesi) kullanilir.
local E = {}
local mods
local U, S, P, G, H

local jbeamIO, ss, jbeamUtils, EP

local min, max, abs, floor, sqrt, huge = math.min, math.max, math.abs, math.floor, math.sqrt, math.huge

E.KEEP = 3
E.cache = {}
E.order = {}

function E.init(m)
  mods = m
  U, S, P, G, H = m.U, m.Sc, m.Pl, m.G, m.H
  jbeamIO = require('jbeam/io')
  ss = require('jbeam/slotSystem')
  jbeamUtils = require('jbeam/utils')
  EP = require('jbeam/expressionParser')
end

local function isList(t) return type(t) == 'table' and t[1] ~= nil end

-----------------------------------------------------------------------------------------------
-- sayi / degisken cozumleme (jbeam degiskenleri henuz islenmeden)
-----------------------------------------------------------------------------------------------
local function evalNum(v, vars)
  if type(v) == 'number' then return v end
  if type(v) == 'string' and vars then
    local b1, b2 = v:byte(1), v:byte(2)
    if b1 == 36 and b2 == 61 then -- "$="
      local ok, r = pcall(EP.parse, v, vars)
      if ok and type(r) == 'number' and r == r then return r end
    elseif b1 == 36 then
      local x = vars[v]
      if type(x) == 'table' then x = x.val end
      if type(x) == 'number' then return x end
    end
  end
  return nil
end
E.evalNum = evalNum

local function isNodeOpKey(k)
  return type(k) == 'string' and k:byte(1) == 110 and k:byte(2) == 111 and k:byte(3) == 100 and k:byte(4) == 101
    and (k:find('^nodeOffset') or k:find('^nodeMove') or k:find('^nodeRotate')) ~= nil
end

-- slot / satir seceneklerindeki dugum donusumlerinin sayisal kopyasi (cozulemeyenler atlanir)
local function numericOp(v, vars)
  if type(v) ~= 'table' then return nil end
  local x, y, z = evalNum(v.x, vars), evalNum(v.y, vars), evalNum(v.z, vars)
  if not (x and y and z) then return nil end
  local t = {x = x, y = y, z = z}
  if v.px ~= nil or v.py ~= nil or v.pz ~= nil then
    t.px, t.py, t.pz = evalNum(v.px, vars) or 0, evalNum(v.py, vars) or 0, evalNum(v.pz, vars) or 0
  end
  return t
end

function E.numericOps(so, vars)
  if type(so) ~= 'table' then return nil end
  local out
  for k, v in pairs(so) do
    if isNodeOpKey(k) then
      local t = numericOp(v, vars)
      if t then
        out = out or {}
        out[k] = t
      end
    end
  end
  if out and so.ignoreNodeOffset then out.ignoreNodeOffset = so.ignoreNodeOffset end
  return out
end

-- slot tanimindaki sabit degiskenler
function E.literalVars(slotDef, parent)
  local out = {}
  for k, v in pairs(parent or {}) do out[k] = v end
  local sv = type(slotDef) == 'table' and slotDef.variables
  if type(sv) == 'table' then
    for k, v in pairs(sv) do
      if type(v) ~= 'string' or v:byte(1) ~= 36 then out[k] = v
      else
        local n = evalNum(v, out)
        if n then out[k] = n end
      end
    end
  end
  return out
end

-- aracin bildirilen degiskenleri (varsayilan ya da kullanici degeri)
function E.declaredVars(rootPart, journal, userVars)
  local out = {}
  local function scan(part)
    local v = part.variables
    if isList(v) and isList(v[1]) then
      local h = {}
      for i, name in ipairs(v[1]) do h[name] = i end
      for r = 2, #v do
        local row = v[r]
        if isList(row) and type(row[h.name or 1]) == 'string' then
          local name = row[h.name or 1]
          local d = row[h.default or 5]
          if userVars and userVars[name] ~= nil then d = userVars[name] end
          if type(d) == 'number' then out[name] = d end
        end
      end
    end
  end
  scan(rootPart)
  for _, j in ipairs(journal or {}) do if type(j[2]) == 'table' then scan(j[2]) end end
  return out
end

-----------------------------------------------------------------------------------------------
-- ham dugum bulutu
-----------------------------------------------------------------------------------------------
function E.collectPartNodes(part, so, out, path, vars)
  local nodes = part and part.nodes
  if not isList(nodes) or not isList(nodes[1]) then return end
  local header = nodes[1]
  local ci = {}
  for i, h in ipairs(header) do if type(h) == 'string' then ci[h] = i end end
  local iid, ix, iy, iz = ci.id or 1, ci.posX or 2, ci.posY or 3, ci.posZ or 4
  local igroup = ci.group
  local state = {}
  local ops = E.numericOps(so, vars)
  for r = 2, #nodes do
    local row = nodes[r]
    if type(row) == 'table' then
      if row[1] == nil then
        for k, v in pairs(row) do state[k] = v end
      else
        local name = row[iid]
        local x, y, z = evalNum(row[ix], vars), evalNum(row[iy], vars), evalNum(row[iz], vars)
        if type(name) == 'string' and x and y and z then
          local opts = U.rowOptions(row)
          local g = state.group
          if igroup and row[igroup] ~= nil then g = row[igroup] end
          if opts and opts.group ~= nil then g = opts.group end
          if ops then x, y, z = jbeamUtils.getPosAfterNodeRotateOffsetMove(ops, x, y, z) end
          out[name] = {name = name, x = x, y = y, z = z, group = g, path = path, part = part.partName}
        end
      end
    end
  end
end

local function isOwnPath(p) return type(p) == 'string' and p:find('^/bcfp_') ~= nil end

function E.collectCloud(rootPart, journal, vars)
  local out = {}
  E.collectPartNodes(rootPart, nil, out, '/' .. tostring(rootPart.partName), vars)
  for _, j in ipairs(journal or {}) do
    if type(j[2]) == 'table' and not isOwnPath(j[5]) then
      local pv = vars
      if type(j[6]) == 'table' and type(j[6].variables) == 'table' then pv = E.literalVars(j[6], vars) end
      E.collectPartNodes(j[2], j[4], out, j[5], pv)
    end
  end
  return out
end

-----------------------------------------------------------------------------------------------
-- ham gorsel (flexbody) listesi: slot donusumleri oyunun kendi islevi ile uygulanir
-----------------------------------------------------------------------------------------------
local function groupList(g, vars)
  local out = {}
  local function add(x)
    if type(x) ~= 'string' or x == '' then return end
    if x:byte(1) == 36 then
      local v = vars and vars[x]
      if type(v) == 'table' then v = v.val end
      if type(v) == 'string' and v ~= '' then out[#out + 1] = v end
    else
      out[#out + 1] = x
    end
  end
  if type(g) == 'table' then for _, x in ipairs(g) do add(x) end else add(g) end
  return out
end

function E.collectPartFlex(part, so, vars, out, path)
  local fb = part and part.flexbodies
  if not isList(fb) or not isList(fb[1]) then return end
  local im, ig
  for i, h in ipairs(fb[1]) do
    if h == 'mesh' then im = i elseif h == '[group]:' then ig = i end
  end
  im, ig = im or 1, ig or 2
  local state = {}
  if type(so) == 'table' then for k, v in pairs(so) do state[k] = v end end
  local jd = E.numericOps(state, vars)
  local function refreshOps(src)
    for k in pairs(src) do
      if isNodeOpKey(k) or k == 'ignoreNodeOffset' then
        jd = E.numericOps(state, vars)
        return
      end
    end
  end
  for r = 2, #fb do
    local row = fb[r]
    if type(row) == 'table' then
      if row[1] == nil then
        for k, v in pairs(row) do
          if v == '' then state[k] = nil else state[k] = v end
        end
        refreshOps(row)
      else
        local mesh = row[im]
        if type(mesh) == 'string' and mesh ~= '' and mesh:byte(1) ~= 36 then
          local o = U.rowOptions(row)
          local function opt(k)
            local v
            if o then v = o[k] end
            if v == nil then v = state[k] end
            if v == '' then v = nil end
            return v
          end
          local pos, rot, scale = opt('pos'), opt('rot'), opt('scale')
          local x, y, z, rx, ry, rz, sx, sy, sz = 0, 0, 0, 0, 0, 0, 1, 1, 1
          local okNum = true
          if type(pos) == 'table' then
            x, y, z = evalNum(pos.x, vars), evalNum(pos.y, vars), evalNum(pos.z, vars)
            if not (x and y and z) then okNum = false end
          end
          if type(rot) == 'table' then
            rx, ry, rz = evalNum(rot.x, vars) or 0, evalNum(rot.y, vars) or 0, evalNum(rot.z, vars) or 0
          end
          if type(scale) == 'table' then
            sx, sy, sz = evalNum(scale.x, vars) or 1, evalNum(scale.y, vars) or 1, evalNum(scale.z, vars) or 1
          end
          if okNum then
            local rowOps = jd
            if o then
              local own
              for k in pairs(o) do if isNodeOpKey(k) or k == 'ignoreNodeOffset' then own = true break end end
              if own then
                local merged = {}
                for k, v in pairs(state) do merged[k] = v end
                for k, v in pairs(o) do merged[k] = v end
                rowOps = E.numericOps(merged, vars)
              end
            end
            if rowOps then
              local nx, ny, nz, nrx, nry, nrz = jbeamUtils.getFlexbodyPosRotAfterNodeRotateOffsetMove(rowOps, x, y, z, rx, ry, rz)
              if nx then x, y, z = nx, ny, nz end
              if nrx then rx, ry, rz = nrx, nry, nrz end
            end
            out[#out + 1] = {mesh = mesh, pos = {x = x, y = y, z = z}, rot = {x = rx, y = ry, z = rz}, scale = {x = sx, y = sy, z = sz},
              part = part.partName, path = path, groups = groupList(row[ig], vars), dg = opt('deformGroup')}
          end
        end
      end
    end
  end
end

function E.collectFlex(rootPart, journal, vars)
  local out = {}
  E.collectPartFlex(rootPart, nil, vars, out, '/' .. tostring(rootPart.partName))
  for _, j in ipairs(journal or {}) do
    if type(j[2]) == 'table' and not isOwnPath(j[5]) then
      local pv = vars
      if type(j[6]) == 'table' and type(j[6].variables) == 'table' then pv = E.literalVars(j[6], vars) end
      E.collectPartFlex(j[2], j[4], pv, out, j[5])
    end
  end
  return out
end

-----------------------------------------------------------------------------------------------
-- anahtar ve onbellek
-----------------------------------------------------------------------------------------------
local function envKey(model, rootPart, journal)
  local names = {tostring(rootPart and rootPart.partName)}
  for _, j in ipairs(journal or {}) do
    if type(j[2]) == 'table' and not isOwnPath(j[5]) then names[#names + 1] = tostring(j[2].partName) end
  end
  table.sort(names)
  return tostring(model) .. '|' .. table.concat(names, ',')
end
E.envKey = envKey

local function touch(key)
  for i, k in ipairs(E.order) do
    if k == key then table.remove(E.order, i) break end
  end
  table.insert(E.order, 1, key)
  while #E.order > E.KEEP do
    local old = table.remove(E.order)
    E.cache[old] = nil
  end
end

function E.invalidate()
  E.cache, E.order = {}, {}
  if S and S.invalidate then S.invalidate() end
end

local function groupsOf(n)
  local g = n.group
  if type(g) == 'string' then
    if g == '' then return {} end
    return {g}
  end
  if type(g) == 'table' then
    local out = {}
    for _, x in pairs(g) do if type(x) == 'string' and x ~= '' then out[#out + 1] = x end end
    return out
  end
  return {}
end

-----------------------------------------------------------------------------------------------
-- kurulum
-----------------------------------------------------------------------------------------------
-- res: slotSystem.findParts sonuclari {rootPart, journal, journalC, tree, slotPartMap, activePartsData, activeParts}
function E.forLoad(ioCtx, vehicleConfig, res)
  local rootPart, journal = res[1], res[2]
  local model = vehicleConfig.model
  local key = envKey(model, rootPart, journal)
  local env = E.cache[key]
  if env then
    touch(key)
    return env, true
  end
  local t0 = os.clock()
  env = {key = key, model = model, stats = {}, warnings = {}}
  local declared = E.declaredVars(rootPart, journal, vehicleConfig.vars)
  env.cloud = E.collectCloud(rootPart, journal, declared)
  local okA, anchors = pcall(G.compute, env.cloud, model)
  env.anchors = okA and anchors or {}
  -- grup -> dugumler
  local byGroup = {}
  local nNodes = 0
  for _, n in pairs(env.cloud) do
    nNodes = nNodes + 1
    for _, g in ipairs(groupsOf(n)) do
      local l = byGroup[g]
      if not l then l = {}; byGroup[g] = l end
      l[#l + 1] = n
    end
  end
  env.byGroup = byGroup
  env.stats.nodes = nNodes
  -- yuzey modeli
  local flex = E.collectFlex(rootPart, journal, declared)
  env.stats.flex = #flex
  local dirs = (type(ioCtx) == 'table' and ioCtx.preloadedDirs) or {'/vehicles/' .. tostring(model) .. '/', '/vehicles/common/'}
  env.dirs = dirs
  local okS, M, err = pcall(S.get, flex, dirs, model)
  if okS and M then
    env.M = M
    env.stats.tris = M.nt
    env.stats.scan = M.stats and M.stats.time
    for _, w in ipairs(M.warnings or {}) do env.warnings[#env.warnings + 1] = w end
  else
    env.scanError = tostring(okS and err or M)
    env.warnings[#env.warnings + 1] = {k = 'scanFail', v = env.scanError}
    U.log('W', 'yuzey taramasi yapilamadi (' .. tostring(model) .. '): ' .. env.scanError)
  end
  -- mesh adi -> baglandigi gruplar / kirilma grubu (taranmayan modeller dahil)
  local meshGroups = {}
  for _, f in ipairs(flex) do
    if not meshGroups[f.mesh] then meshGroups[f.mesh] = {groups = f.groups, dg = f.dg, part = f.part} end
  end
  env.meshGroups = meshGroups
  -- fabrika konumlari
  env.hints, env.factory, env.roofBar = {}, {}, nil
  local okH, hres = pcall(H.collect, ioCtx, rootPart, journal, env, declared)
  if okH and type(hres) == 'table' then
    env.hints, env.factory, env.roofBar = hres.zones or {}, hres.parts or {}, hres.roofBar
    env.hintRejected = hres.rejected
    env.stats.hintParts = hres.count or 0
  else
    env.warnings[#env.warnings + 1] = {k = 'hintFail', v = tostring(hres)}
    U.log('W', 'fabrika konumlari okunamadi: ' .. tostring(hres))
  end
  env.stats.time = os.clock() - t0
  E.cache[key] = env
  touch(key)
  return env, false
end

-- yuklu arac icin (arayuz): aracin konfigurasyonuyla parca agaci yeniden cozulur (arac yeniden yuklenmez)
function E.forVehicle(vd)
  if type(vd) ~= 'table' or type(vd.config) ~= 'table' then return nil, 'arac verisi yok' end
  local model = vd.config.model
  if type(model) ~= 'string' then return nil, 'model yok' end
  local dirs = {'/vehicles/' .. model .. '/', '/vehicles/common/'}
  local ioCtx = jbeamIO.startLoading(dirs)
  local cfg = deepcopy(vd.config)
  cfg.bcfp = nil
  cfg.model = model
  if not cfg.mainPartName then cfg.mainPartName = jbeamIO.getMainPartName(ioCtx) end
  if cfg.mainPartName then cfg.mainPartPath = '/' .. cfg.mainPartName end
  local find = ss.__bcfpOrigFindParts or ss.findParts
  local r1, r2, r3, r4, r5, r6, r7 = find(ioCtx, cfg)
  if not r1 then return nil, 'parca agaci cozulemedi' end
  local env, cached = E.forLoad(ioCtx, cfg, {r1, r2, r3, r4, r5, r6, r7})
  pcall(jbeamIO.finishLoading)
  return env, cached
end

-----------------------------------------------------------------------------------------------
-- baglama: gorseller hangi dugum gruplarina, isiklar hangi uc dugume baglanacak
-----------------------------------------------------------------------------------------------
local BODY_EXCLUDE = {'wheel', 'tire', 'tyre', 'hub', 'axle', 'suspension', 'spring', 'shock', 'strut', 'brake', 'engine',
  'transmission', 'exhaust', 'driveshaft', 'halfshaft', 'steer', 'sway', 'tierod', 'leaf', 'coilover', 'antenna', 'lightbar',
  'bcfp', 'mudflap', 'hitch', 'spare', 'license', 'flag', 'seat', 'fueltank', 'radiator', 'intake', 'turbo', 'diff'}

local function nodeCount(env, groups)
  local n = 0
  for _, g in ipairs(groups or {}) do n = n + #(env.byGroup[g] or {}) end
  return n
end

-- noktaya en yakin uc dugum (ayni dogru uzerinde olmayan)
local function pickRefNodes(list, px, py, pz)
  local cand = {}
  for _, n in ipairs(list) do
    local dx, dy, dz = n.x - px, n.y - py, n.z - pz
    cand[#cand + 1] = {n = n, d = dx * dx + dy * dy + dz * dz}
  end
  if #cand < 3 then return nil end
  table.sort(cand, function(a, b) return a.d < b.d end)
  local lim = min(#cand, 24)
  local a = cand[1].n
  for i = 2, lim do
    local b = cand[i].n
    local ux, uy, uz = b.x - a.x, b.y - a.y, b.z - a.z
    local ul = sqrt(ux * ux + uy * uy + uz * uz)
    if ul > 0.04 then
      local best, bestS
      for k = 2, lim do
        if k ~= i then
          local c = cand[k].n
          local vx, vy, vz = c.x - a.x, c.y - a.y, c.z - a.z
          local vl = sqrt(vx * vx + vy * vy + vz * vz)
          if vl > 0.04 then
            local cx, cy, cz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            local s = sqrt(cx * cx + cy * cy + cz * cz) / (ul * vl)
            if s > 0.35 then
              -- yeterince dik ilk (en yakin) aday
              best = c
              break
            elseif not bestS or s > bestS then
              best, bestS = c, s
            end
          end
        end
      end
      if best and (bestS == nil or bestS > 0.12) then return {a.name, b.name, best.name} end
    end
  end
  return nil
end

local function nodesOfGroups(env, groups)
  local out, seen = {}, {}
  for _, g in ipairs(groups or {}) do
    for _, n in ipairs(env.byGroup[g] or {}) do
      if not seen[n.name] then seen[n.name] = true; out[#out + 1] = n end
    end
  end
  return out
end

local function excludedGroup(g)
  return U.containsAny(g, BODY_EXCLUDE)
end

-- en yakin govde dugumlerinin cogunluk grubu
local function voteGroups(env, px, py, pz, allow)
  local best = {}
  for _, n in pairs(env.cloud) do
    local gl = groupsOf(n)
    local ok = #gl > 0
    for _, g in ipairs(gl) do if excludedGroup(g) then ok = false end end
    if ok and allow then
      ok = false
      for _, g in ipairs(gl) do if U.containsAny(g, allow) then ok = true end end
    end
    if ok then
      local dx, dy, dz = n.x - px, n.y - py, n.z - pz
      local d = dx * dx + dy * dy + dz * dz
      if #best < 8 then
        best[#best + 1] = {n = n, d = d, gl = gl}
        table.sort(best, function(a, b) return a.d < b.d end)
      elseif d < best[8].d then
        best[8] = {n = n, d = d, gl = gl}
        table.sort(best, function(a, b) return a.d < b.d end)
      end
    end
  end
  if #best == 0 then return nil end
  local score = {}
  for i, b in ipairs(best) do
    for _, g in ipairs(b.gl) do score[g] = (score[g] or 0) + 1 / (0.05 + sqrt(b.d)) end
  end
  local top, topS
  for g, s in pairs(score) do
    if #(env.byGroup[g] or {}) >= 3 and (not topS or s > topS) then top, topS = g, s end
  end
  if top then return {top} end
  return nil
end

local ZONE_ALLOW = {
  trunk = {'trunk', 'tailgate', 'hatch', 'decklid', 'body'},
  bumperF = {'bumper', 'fascia', 'lip', 'nosecone', 'body'}, bumperR = {'bumper', 'fascia', 'body'},
  grille = {'grille', 'fascia', 'radsupport', 'bumper', 'hood', 'body'}, mirrors = {'mirror', 'door'},
  hood = {'hood'}, hideF = {'headlight', 'fascia', 'radsupport', 'fender', 'body'}, hideR = {'taillight', 'trunk', 'tailgate', 'body'},
  sideF = {'fender', 'bumper', 'body'}, skirt = {'body', 'rocker', 'skirt', 'door'},
}

-- lay: P.layout sonucu; doner: {L = {groups, ref, dg}, R = {...}} ya da {own = true} (govde dugumu bulunamadi)
function E.bind(env, o, lay)
  local out = {}
  local zone = o.anchor
  local H = env.hints and env.hints[zone]
  local M = env.M
  for _, sd in ipairs({'L', 'R'}) do
    local heads = lay[sd]
    if heads and #heads > 0 then
      local cx, cy, cz = 0, 0, 0
      for _, h in ipairs(heads) do cx, cy, cz = cx + h.x, cy + h.y, cz + h.z end
      cx, cy, cz = cx / #heads, cy / #heads, cz / #heads
      local groups, dg
      -- 1) fabrika parcasi ayni gruplara baglidir
      if H and heads[1].src == 'factory' and H.groups and nodeCount(env, H.groups) >= 3 then
        groups, dg = H.groups, H.dg
      end
      -- 2) uzerine oturdugu yuzeyin modeli
      if not groups and M then
        local votes, dgs = {}, {}
        for _, h in ipairs(heads) do
          if h.tri then
            local m = M:meshOf(h.tri)
            if m and m.groups and #m.groups > 0 then
              local keyG = table.concat(m.groups, '\t')
              votes[keyG] = (votes[keyG] or 0) + 1
              dgs[keyG] = m
            end
          end
        end
        local bestK, bestV
        for k, v in pairs(votes) do if not bestV or v > bestV then bestK, bestV = k, v end end
        if bestK then
          local m = dgs[bestK]
          local gl = {}
          local bad = false
          for _, g in ipairs(m.groups) do
            if excludedGroup(g) then bad = true end
            if #(env.byGroup[g] or {}) > 0 then gl[#gl + 1] = g end
          end
          if not bad and nodeCount(env, gl) >= 3 then groups = gl end
        end
      end
      -- cam ici bolgeler: on / arka camin kirilma grubu (cam kirilinca cakar da soner; oyunun kendi parcalari gibi)
      if not dg and M and (zone == 'windshield' or zone == 'dash' or zone == 'rearglass' or zone == 'reardeck') then
        local set = (zone == 'windshield' or zone == 'dash') and M.glass.front or M.glass.rear
        if set and #set > 0 then
          local m = M:meshOf(set[1])
          if m and type(m.dg) == 'string' and m.dg ~= '' then dg = m.dg end
        end
      end
      -- 3) en yakin govde dugumleri
      if not groups then groups = voteGroups(env, cx, cy, cz, ZONE_ALLOW[zone]) end
      if not groups then groups = voteGroups(env, cx, cy, cz, nil) end
      if groups then
        local ref = pickRefNodes(nodesOfGroups(env, groups), cx, cy, cz)
        if not ref then
          -- grubun dugumleri isik icin yetersiz: tum govdeden sec
          local all = {}
          for _, n in pairs(env.cloud) do
            local ok = true
            for _, g in ipairs(groupsOf(n)) do if excludedGroup(g) then ok = false end end
            if ok then all[#all + 1] = n end
          end
          ref = pickRefNodes(all, cx, cy, cz)
        end
        out[sd] = {groups = groups, ref = ref, dg = dg, c = {cx, cy, cz}}
      else
        out.own = true
      end
    end
  end
  return out
end

-- tavan cubugu / kopya icin: (x = +-hx, y) noktalarinda tavan dis yuzeyinin yuksekligi
function E.roofZ(env, y, hx, hy)
  local M = env.M
  if not M then return nil end
  local best
  for _, sx in ipairs({-1, 0, 1}) do
    for _, sy in ipairs({-1, 0, 1}) do
      local z = M:rayZ(sx * (hx or 0.4), y + sy * (hy or 0.12), -1, S.M_EXT, huge)
      if z and (not best or z > best) then best = z end
    end
  end
  return best
end

return E
