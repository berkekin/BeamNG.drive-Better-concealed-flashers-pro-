-- Better Concealed Flashers PRO - gercekci LED renk paleti
-- Degerler CIE 1931 renk eslesme fonksiyonlari ve gercek LED spektrumlarindan (kirmizi 625 nm, amber 590 nm,
-- mavi 465 nm, yesil 525 nm; beyaz LED'ler 6000 K / 5000 K / 4300 K, halojen 3200 K) hesaplandi, BeamNG'nin
-- dogrusal (linear) sRGB isik rengine renk tonu korunarak indirgendi. Kirmizi ve mavide capraz kanal
-- (yesil) sizintisi sifirdir: yuksek parlakliktaki ton eslemede kirmizinin turuncuya, mavinin camgobegine
-- kaymasini engeller.
local P = {}

local max, min, floor, abs = math.max, math.min, math.floor, math.abs

-- lin: dogrusal RGB (isik ve emissive icin), hex: arayuzde gosterim (sRGB), Y: bagil parlaklik (luminans)
P.colors = {
  {id = 'red',    idx = 1, tr = 'Kirmizi',      lin = {1.0, 0.0, 0.015},     hex = '#ff0021', Y = 0.2138},
  {id = 'blue',   idx = 2, tr = 'Mavi',         lin = {0.0, 0.0747, 1.0},    hex = '#004dff', Y = 0.1256},
  {id = 'white',  idx = 3, tr = 'Beyaz (6000K)',lin = {1.0, 0.901, 0.8766},  hex = '#fff4f1', Y = 0.9203},
  {id = 'amber',  idx = 4, tr = 'Amber',        lin = {1.0, 0.2305, 0.0},    hex = '#ff8400', Y = 0.3775},
  {id = 'green',  idx = 5, tr = 'Yesil',        lin = {0.0, 1.0, 0.25},      hex = '#00ff89', Y = 0.7332},
  {id = 'purple', idx = 6, tr = 'Mor',          lin = {0.55, 0.0, 1.0},      hex = '#c400ff', Y = 0.1891},
}
P.byId, P.byIdx = {}, {}
for _, c in ipairs(P.colors) do P.byId[c.id] = c; P.byIdx[c.idx] = c end

-- renk tonlari (1 = standart). Materyal anahtari: ton 1 -> "<renk>", digerleri -> "<renk>t<ton>" (bcfp_on_<anahtar>_<seviye>)
P.tones = {
  red    = {{tr = 'Kırmızı 625 nm', lin = {1.0, 0.0, 0.015}},     {tr = 'Turuncu-kırmızı 615 nm', lin = {1.0, 0.045, 0.0}},  {tr = 'Gül kırmızısı', lin = {1.0, 0.0, 0.09}}},
  blue   = {{tr = 'Polis mavisi 470 nm', lin = {0.0, 0.0747, 1.0}}, {tr = 'Derin mavi 455 nm', lin = {0.035, 0.0, 1.0}},     {tr = 'Buz mavisi 480 nm', lin = {0.0, 0.19, 1.0}}},
  white  = {{tr = 'Beyaz 6000 K', lin = {1.0, 0.901, 0.8766}},    {tr = 'Nötr beyaz 5000 K', lin = {1.0, 0.7973, 0.6303}}, {tr = 'Sıcak beyaz 4000 K', lin = {1.0, 0.6605, 0.3791}}},
  amber  = {{tr = 'Amber 590 nm', lin = {1.0, 0.2305, 0.0}},      {tr = 'Sarı 585 nm', lin = {1.0, 0.3159, 0.0}},          {tr = 'Turuncu 600 nm', lin = {1.0, 0.085, 0.0}}},
  green  = {{tr = 'Yeşil 505 nm', lin = {0.0, 1.0, 0.25}},        {tr = 'Saf yeşil 525 nm', lin = {0.0, 1.0, 0.04}},       {tr = 'Limon yeşili 555 nm', lin = {0.16, 1.0, 0.0}}},
  purple = {{tr = 'Mor', lin = {0.55, 0.0, 1.0}},                 {tr = 'Macenta', lin = {1.0, 0.0, 0.75}},                {tr = 'Menekşe', lin = {0.2, 0.0, 1.0}}},
}

local function srgbHex(r, g, b)
  local function enc(v)
    v = max(0, min(1, v))
    local s = (v <= 0.0031308) and (12.92 * v) or (1.055 * v ^ (1 / 2.4) - 0.055)
    return floor(s * 255 + 0.5)
  end
  return string.format('#%02x%02x%02x', enc(r), enc(g), enc(b))
end

for cid, list in pairs(P.tones) do
  for ti, t in ipairs(list) do
    t.key = (ti == 1) and cid or (cid .. 't' .. ti)
    t.Y = max(0.02, 0.2126 * t.lin[1] + 0.7152 * t.lin[2] + 0.0722 * t.lin[3])
    t.hex = srgbHex(t.lin[1], t.lin[2], t.lin[3])
    t.color, t.tone = cid, ti
  end
end

-- renk numarasi (1..6) + ton (1..3) -> ton kaydi
function P.tone(idx, tone)
  local c = P.byIdx[idx] or P.byIdx[3]
  local list = P.tones[c.id]
  return list[tone or 1] or list[1]
end

-- beyaz isik sicakliklari
P.whites = {
  w6000 = {lin = {1.0, 0.901, 0.8766}, Y = 0.9203, tr = 'LED beyaz 6000K'},
  w5000 = {lin = {1.0, 0.7954, 0.63},  Y = 0.827,  tr = 'Notr beyaz 5000K'},
  w4300 = {lin = {1.0, 0.7036, 0.4532}, Y = 0.7486, tr = 'Xenon 4300K'},
  halogen = {lin = {1.0, 0.5224, 0.195}, Y = 0.6003, tr = 'Halojen 3200K'},
}

-- canli (doygun) profil: daha az beyazimsi, ekranda daha "parlak renkli"
P.vivid = {
  red = {1.0, 0.0, 0.0}, blue = {0.0, 0.02, 1.0}, amber = {1.0, 0.16, 0.0}, green = {0.0, 1.0, 0.08},
  purple = {0.45, 0.0, 1.0}, white = {1.0, 0.94, 0.92},
}

function P.luminance(r, g, b)
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
end

-- 0..255 ya da 0..1 renk -> dogrusal 0..1 uclu
local function norm(c)
  if type(c) ~= 'table' then return nil end
  local r, g, b = tonumber(c.r or c[1]), tonumber(c.g or c[2]), tonumber(c.b or c[3])
  if not (r and g and b) then return nil end
  local a = tonumber(c.a or c[4]) or 255
  return r / 255, g / 255, b / 255, a
end

local function parseHex(s)
  if type(s) ~= 'string' or s:sub(1, 1) ~= '#' or #s < 7 then return nil end
  local r = tonumber(s:sub(2, 3), 16)
  local g = tonumber(s:sub(4, 5), 16)
  local b = tonumber(s:sub(6, 7), 16)
  local a = (#s >= 9) and tonumber(s:sub(8, 9), 16) or 255
  if not (r and g and b) then return nil end
  return {r = r, g = g, b = b, a = a}
end
P.parseHex = parseHex

-- jbeam lightColor (sozluk veya "#RRGGBBAA") -> r,g,b (0..1), a (0..255)
function P.toLinear(c)
  if type(c) == 'string' then c = parseHex(c) end
  return norm(c)
end

-- dogrusal sRGB -> CIE xy
local function xyOf(r, g, b)
  local X = 0.4124 * r + 0.3576 * g + 0.1805 * b
  local Y = 0.2126 * r + 0.7152 * g + 0.0722 * b
  local Z = 0.0193 * r + 0.1192 * g + 0.9505 * b
  local s = X + Y + Z
  if s <= 1e-9 then return 0.3127, 0.3290 end
  return X / s, Y / s
end

-- Planck egrisi (Kim vd. kubik yaklasimi, 1667-25000 K)
local function planckXY(T)
  T = max(1667, min(25000, T))
  local t1, t2, t3 = 1 / T, 1 / (T * T), 1 / (T * T * T)
  local x
  if T <= 4000 then x = -0.2661239e9 * t3 - 0.2343589e6 * t2 + 0.8776956e3 * t1 + 0.179910
  else x = -3.0258469e9 * t3 + 2.1070379e6 * t2 + 0.2226347e3 * t1 + 0.240390 end
  local x2, x3 = x * x, x * x * x
  local y
  if T <= 2222 then y = -1.1063814 * x3 - 1.34811020 * x2 + 2.18555832 * x - 0.20219683
  elseif T <= 4000 then y = -0.9549476 * x3 - 1.37418593 * x2 + 2.09137015 * x - 0.16748867
  else y = 3.0817580 * x3 - 5.87338670 * x2 + 3.75112997 * x - 0.37001483 end
  return x, y
end

-- renk sicakligi (McCamy) ve Planck egrisine uzaklik
function P.cct(r, g, b)
  local x, y = xyOf(r, g, b)
  local d0 = 0.1858 - y
  if abs(d0) < 1e-6 then return nil, 1 end
  local n = (x - 0.3320) / d0
  local T = 449 * n ^ 3 + 3525 * n ^ 2 + 6823.3 * n + 5520.33
  if T ~= T or T < 1000 or T > 40000 then return nil, 1 end
  local px, py = planckXY(T)
  local d = math.sqrt((x - px) ^ 2 + (y - py) ^ 2)
  return T, d
end

-- renk sinifi: red / amber / blue / green / purple / white (+ beyaz icin sicaklik)
-- Beyaz: renk noktasi Planck egrisine yakin ve sicaklik >= 2650 K (halojen ve akkor ampuller beyaz sayilir,
-- oyunun amber LED rengi (255,90,14) ~2400 K ve 590 nm amber LED ~1900 K amber kalir).
function P.classify(r, g, b)
  local mx, mn = max(r, g, b), min(r, g, b)
  if mx <= 0.0001 then return 'white', 'w6000' end
  local T, d = P.cct(r, g, b)
  if (T and d < 0.03 and T >= 2650 and T <= 20000) or (mn / mx > 0.75) then
    T = T or 6000
    if T < 3700 then return 'white', 'halogen' end
    if T < 4700 then return 'white', 'w4300' end
    if T < 5600 then return 'white', 'w5000' end
    return 'white', 'w6000'
  end
  -- ton acisi (yaklasik algisal uzay)
  local R, G, B = r ^ 0.4545, g ^ 0.4545, b ^ 0.4545
  local M, N = max(R, G, B), min(R, G, B)
  local dd = M - N
  local h
  if dd < 1e-6 then h = 0
  elseif M == R then h = ((G - B) / dd) % 6
  elseif M == G then h = (B - R) / dd + 2
  else h = (R - G) / dd + 4 end
  h = h * 60
  if h < 0 then h = h + 360 end
  if h < 18 or h >= 330 then return 'red' end
  if h < 62 then return 'amber' end
  if h < 165 then return 'green' end
  if h < 258 then return 'blue' end
  return 'purple'
end

-- profil: 0 orijinal, 1 gercekci LED, 2 canli
function P.remap(r, g, b, profile)
  if profile == 0 or profile == nil then return r, g, b end
  local cls, temp = P.classify(r, g, b)
  if cls == 'white' then
    if profile == 2 then
      local v = P.vivid.white
      return v[1], v[2], v[3]
    end
    local w = P.whites[temp or 'w6000'] or P.whites.w6000
    return w.lin[1], w.lin[2], w.lin[3]
  end
  local src = (profile == 2) and P.vivid[cls] or P.byId[cls].lin
  return src[1], src[2], src[3]
end

-- 0..1 -> 0..255 tamsayi (BeamNG isik rengi dogrusal kabul edilir)
function P.to255(r, g, b, a)
  local function q(v) return floor(max(0, min(1, v)) * 255 + 0.5) end
  return {r = q(r), g = q(g), b = q(b), a = a or 255}
end

-- arayuz icin sRGB hex
function P.hexFromLinear(r, g, b)
  local function enc(v)
    v = max(0, min(1, v))
    local s = (v <= 0.0031308) and (12.92 * v) or (1.055 * v ^ (1 / 2.4) - 0.055)
    return floor(s * 255 + 0.5)
  end
  return string.format('#%02x%02x%02x', enc(r), enc(g), enc(b))
end

return P
