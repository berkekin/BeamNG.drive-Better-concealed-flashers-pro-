-- Better Concealed Flashers PRO - ortak yardimcilar (GE)
local U = {}

local floor, abs, sqrt, min, max = math.floor, math.abs, math.sqrt, math.min, math.max

U.TAG = 'bcfpPro'

function U.log(level, msg)
  if log then log(level, U.TAG, tostring(msg)) end
end

function U.isList(t)
  return type(t) == 'table' and t[1] ~= nil
end

function U.num(v, d, lo, hi)
  v = tonumber(v)
  if v == nil or v ~= v or v == math.huge or v == -math.huge then v = d end
  if v == nil then return nil end
  if lo and v < lo then v = lo end
  if hi and v > hi then v = hi end
  return v
end

function U.int(v, d, lo, hi)
  v = U.num(v, d, lo, hi)
  if v == nil then return nil end
  return floor(v + 0.5)
end

function U.bool(v, d)
  if v == nil then return d end
  if type(v) == 'boolean' then return v end
  if type(v) == 'number' then return v ~= 0 end
  if type(v) == 'string' then return v == 'true' or v == '1' end
  return d
end

function U.copy(v)
  if type(v) ~= 'table' then return v end
  local out = {}
  for k, x in pairs(v) do out[k] = U.copy(x) end
  return out
end

function U.clamp(v, a, b)
  if v < a then return a end
  if v > b then return b end
  return v
end

function U.r(v, n)
  local m = 10 ^ (n or 4)
  return floor(v * m + 0.5) / m
end

-- kararli (sirali anahtarli) serilestirme: imza / karsilastirma icin
local function ser(v, out, depth)
  local t = type(v)
  if depth > 12 then out[#out + 1] = '...' return end
  if t == 'table' then
    local keys = {}
    for k in pairs(v) do keys[#keys + 1] = k end
    table.sort(keys, function(a, b)
      local ta, tb = type(a), type(b)
      if ta ~= tb then return ta < tb end
      return a < b
    end)
    out[#out + 1] = '{'
    for _, k in ipairs(keys) do
      out[#out + 1] = tostring(k)
      out[#out + 1] = '='
      ser(v[k], out, depth + 1)
      out[#out + 1] = ';'
    end
    out[#out + 1] = '}'
  elseif t == 'string' then
    out[#out + 1] = string.format('%q', v)
  else
    out[#out + 1] = tostring(v)
  end
end

function U.signature(v)
  local out = {}
  ser(v, out, 0)
  return table.concat(out)
end

-- jbeam tablo satiri: son eleman satir-ici ayar sozlugu olabilir
function U.rowOptions(row)
  local last = row[#row]
  if type(last) == 'table' and not U.isList(last) and next(last) ~= nil then return last end
  if type(last) == 'table' and next(last) == nil then return last end
  return nil
end

function U.lower(s)
  return type(s) == 'string' and s:lower() or ''
end

function U.containsAny(s, words)
  s = U.lower(s)
  if s == '' then return false end
  for _, w in ipairs(words) do
    if s:find(w, 1, true) then return true end
  end
  return false
end

-- kelime sinirli arama: bosluklu anahtar kelimeler ("light bar") baska kelimelerin icinde eslesmesin
-- ("taillight bar", "light barstow" gibi); tek kelimelikler ("lightbar") parca icinde de eslesir
local function hasWord(s, w)
  if not w:find(' ', 1, true) then return s:find(w, 1, true) ~= nil end
  local i = 1
  while true do
    local a, b = s:find(w, i, true)
    if not a then return false end
    local pre = (a > 1) and s:sub(a - 1, a - 1) or ' '
    local post = (b < #s) and s:sub(b + 1, b + 1) or ' '
    if post == 's' then post = (b + 1 < #s) and s:sub(b + 2, b + 2) or ' ' end
    if not pre:match('%a') and not post:match('%a') then return true end
    i = a + 1
  end
end

function U.containsWord(s, words)
  s = U.lower(s)
  if s == '' then return false end
  for _, w in ipairs(words) do
    if hasWord(s, w) then return true end
  end
  return false
end

function U.dist2(a, b)
  local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
  return dx * dx + dy * dy + dz * dz
end

function U.vlen(x, y, z)
  return sqrt(x * x + y * y + z * z)
end

-- z ekseni etrafinda (derece) dondur
function U.rotZ(x, y, deg)
  local a = math.rad(deg)
  local c, s = math.cos(a), math.sin(a)
  return x * c - y * s, x * s + y * c
end

function U.split(s, sep)
  local out = {}
  for part in string.gmatch(s, '([^' .. sep .. ']+)') do out[#out + 1] = part end
  return out
end

function U.keysSorted(t)
  local keys = {}
  for k in pairs(t or {}) do keys[#keys + 1] = k end
  table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
  return keys
end

function U.trimStr(s, n)
  s = tostring(s or '')
  if #s > n then return s:sub(1, n - 1) .. '~' end
  return s
end

-----------------------------------------------------------------------------------------------
-- dil (arayuz ve bildirimler): 'tr' | 'en'. Kullanici secimi /settings/bcfp_pro/prefs.json icinde;
-- secim yoksa oyunun dili Turkce ise 'tr', degilse 'en'.
-----------------------------------------------------------------------------------------------
U.PREFS_FILE = '/settings/bcfp_pro/prefs.json'
U.LANGS = {tr = true, en = true}
local langCache

function U.lang()
  if langCache then return langCache end
  local l
  local ok, d = pcall(jsonReadFile, U.PREFS_FILE)
  if ok and type(d) == 'table' and U.LANGS[d.lang] then l = d.lang end
  if not l then
    local okG, g = pcall(function() return core_locales and core_locales.getLanguage and core_locales.getLanguage() end)
    l = (okG and type(g) == 'string' and g:lower():sub(1, 2) == 'tr') and 'tr' or 'en'
  end
  langCache = l
  return l
end

function U.setLang(l)
  if not U.LANGS[l] then return false end
  langCache = l
  pcall(function() if FS and not FS:directoryExists('/settings/bcfp_pro/') then FS:directoryCreate('/settings/bcfp_pro/', true) end end)
  local ok, d = pcall(jsonReadFile, U.PREFS_FILE)
  d = (ok and type(d) == 'table') and d or {}
  d.lang = l
  pcall(jsonWriteFile, U.PREFS_FILE, d, true)
  return true
end

-- oyun ici bildirimler (arayuz metinleri arayuz uygulamasinin kendisinde)
U.TXT = {
  tr = {
    autoApplied = 'Gizli Çakar PRO: "%s" kiti otomatik uygulandı',
    kits = {undercover = 'Sivil ekip', full = 'Tam donanım', front = 'Sadece ön', rear = 'Sadece arka', slicktop = 'İç lightbar',
            hideaway = 'Hideaway', traffic = 'Trafik oku'},
  },
  en = {
    autoApplied = 'Concealed Flashers PRO: "%s" kit applied automatically',
    kits = {undercover = 'Undercover', full = 'Full package', front = 'Front only', rear = 'Rear only', slicktop = 'Interior lightbar',
            hideaway = 'Hideaway', traffic = 'Traffic advisor'},
  },
}
function U.txt(key)
  local d = U.TXT[U.lang()] or U.TXT.en
  local v = d[key]
  if v == nil then v = U.TXT.en[key] end
  return v
end

return U
