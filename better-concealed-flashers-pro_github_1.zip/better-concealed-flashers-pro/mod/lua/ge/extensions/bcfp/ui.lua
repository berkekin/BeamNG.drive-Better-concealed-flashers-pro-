-- Better Concealed Flashers PRO 3 - arayuz baglantisi: durum paketi, eylemler, hazir kitler, canli ayar,
-- yerlesim onizlemesi (hayalet kutular), profiller ve "her araca otomatik uygula"
local UI = {}
local U, P, G, C, Gn, Cat, S, E, Pl, Un

local min, max, abs, floor, sqrt, sin, cos, rad = math.min, math.max, math.abs, math.floor, math.sqrt, math.sin, math.cos, math.rad

UI.EVENT = 'BcfpProState'
local SETTINGS_DIR = '/settings/bcfp_pro/'
local PROFILES_FILE = SETTINGS_DIR .. 'profiles.json'
local AUTO_FILE = SETTINGS_DIR .. 'auto.json'

-- arac tarafindaki kontrolcu modlariyla ayni sira (bcfp_flasher.lua MODES)
UI.MODES = {
  'Normal (Orijinal)', 'Takip - Cift Flas', 'Takip - Dortlu', 'Takip - Hizli', 'Karisik (Combo)', 'Takedown',
  'Sahne / Park', 'Seyir 1 (Sabit)', 'Seyir 2', 'Trafik Ok - Sol', 'Trafik Ok - Sag', 'Trafik Ok - Orta',
  'Avrupa (ECE)', 'Dalga', 'Tam Beyaz Aydinlatma', 'Tarama (Soldan Saga)', 'Tarama (Ping-Pong)', 'Capraz',
  'Donen Isik (360)', 'Ortadan Disa', 'Disten Ortaya', 'Xenon Strobe', 'Hizli Dortlu Strobe', 'Yavas Dalga',
  'Rastgele Pirilti', 'Cift + Uclu', 'Sabit + Cakar (Steady Burn)', 'Hiper Flas', 'Uclu + Tek', 'Es Zamanli Dortlu',
  'Yavas Ikaz (1 Hz)',
}

-- bolge deseni secenekleri (controller PATTERN_BY_INDEX ile ayni sira; 0 = moda gore)
UI.PATTERNS = {'Orijinal', 'Cift flas', 'Uclu flas', 'Dortlu flas', 'Tekli', 'Hizli', 'Es zamanli cift', 'ECE', 'Combo',
  'Sahne (yavas)', 'Sabit', 'Kapali', 'Xenon strobe', 'Hizli dortlu', 'Cift + uclu', 'Yavas', 'Steady burn', 'Hiper flas',
  'Uclu + tek', 'Es zamanli dortlu', 'Yavas ikaz 1 Hz'}

-- renk semalari: sol / sag renk numarasi (1 kirmizi, 2 mavi, 3 beyaz, 4 amber, 5 yesil, 6 mor)
UI.SCHEMES = {
  {id = 'rb', tr = 'Kırmızı – Mavi', L = 1, R = 2},
  {id = 'br', tr = 'Mavi – Kırmızı', L = 2, R = 1},
  {id = 'bb', tr = 'Mavi – Mavi', L = 2, R = 2},
  {id = 'rr', tr = 'Kırmızı – Kırmızı', L = 1, R = 1},
  {id = 'rw', tr = 'Kırmızı – Beyaz', L = 1, R = 3},
  {id = 'bw', tr = 'Mavi – Beyaz', L = 2, R = 3},
  {id = 'aa', tr = 'Amber – Amber', L = 4, R = 4},
  {id = 'aw', tr = 'Amber – Beyaz', L = 4, R = 3},
  {id = 'gg', tr = 'Yeşil – Yeşil', L = 5, R = 5},
  {id = 'pp', tr = 'Mor – Mor', L = 6, R = 6},
}
local schemeById = {}
for _, s in ipairs(UI.SCHEMES) do schemeById[s.id] = s end

-- hazir kitler: bolge listesi (aracta olmayan bolgeler atlanir). opt: n = adet (nil = otomatik), b = ikinci renk,
-- bfn = ikinci renk islevi, adv = trafik oku uyesi, alt = bu bolge yoksa denenecek bolge
UI.KITS = {
  {id = 'undercover', tr = 'Sivil ekip', desc = 'Ön cam üstü, panjur, arka cam, bagaj',
    zones = {{'windshield'}, {'grille'}, {'rearglass', alt = 'reardeck'}, {'trunk', alt = 'bumperR'}}},
  {id = 'full', tr = 'Tam donanım', desc = 'Tüm bölgeler; ön camda beyaz takedown, arkada amber ok',
    zones = {{'windshield', b = 3, bfn = 1}, {'grille'}, {'bumperF'}, {'mirrors'}, {'sideF'}, {'sideRear'},
             {'rearglass', b = 4, bfn = 4, adv = 1, alt = 'reardeck'}, {'reardeck'}, {'trunk'}, {'bumperR'}}},
  {id = 'front', tr = 'Sadece ön', desc = 'Ön cam üstü, panjur, ön tampon',
    zones = {{'windshield'}, {'grille'}, {'bumperF'}}},
  {id = 'rear', tr = 'Sadece arka', desc = 'Arka cam, bagaj, arka tampon',
    zones = {{'rearglass', alt = 'reardeck'}, {'trunk'}, {'bumperR'}}},
  {id = 'slicktop', tr = 'İç lightbar', desc = 'Ön ve arka camı boydan boya dolduran sıra (slicktop)',
    zones = {{'windshield', fill = true, b = 3, bfn = 1}, {'rearglass', fill = true, alt = 'reardeck'}}},
  {id = 'hideaway', tr = 'Hideaway', desc = 'Far ve stop içi, panjur',
    zones = {{'hideF'}, {'grille'}, {'hideR'}}},
  {id = 'traffic', tr = 'Trafik oku', desc = 'Arka camda 3 kademeli amber ok + ön/arka amber ikaz', scheme = 'aa',
    zones = {{'rearglass', n = 1, adv = 1, steps = 3, alt = 'reardeck'}, {'grille'}, {'bumperR'}}},
}
local kitById = {}
for _, k in ipairs(UI.KITS) do kitById[k.id] = k end

local REAR_ZONE = {rearglass = true, reardeck = true, trunk = true, bumperR = true, hideR = true}

local state = {
  vid = nil, markers = true, markerItem = nil, dirty = true, status = {}, modes = nil,
  appAlive = -1e9, envJob = nil, scheme = 'rb', autoGuard = {}, markerCache = {},
}
UI._state = state

function UI.init(mods)
  U, P, G, C, Gn, Cat, S = mods.U, mods.P, mods.G, mods.C, mods.Gn, mods.Cat, mods.S
  E, Pl, Un = mods.E, mods.Pl, mods.Un
end

-----------------------------------------------------------------------------------------------
-- arac / konfigurasyon erisimi
-----------------------------------------------------------------------------------------------
local function targetVid()
  local vid = state.vid
  if vid and be:getObjectByID(vid) then return vid end
  local ok, id = pcall(function() return be:getPlayerVehicleID(0) end)
  if ok and id and id >= 0 then return id end
  return nil
end
UI.targetVid = targetVid

local function vehData(vid)
  if not vid or not core_vehicle_manager then return nil end
  local ok, vd = pcall(core_vehicle_manager.getVehicleData, vid)
  if ok then return vd end
  return nil
end

local function currentCfg(vd)
  local raw = vd and vd.config and vd.config.bcfp
  local cfg = C.sanitize(raw or {})
  return cfg, raw ~= nil
end

local function appOpen() return (os.clock() - state.appAlive) < 30 end

-- aracin ortami (yuzey modeli + fabrika konumlari). build = false ise yalnizca onbellekten.
local function envFor(vd, build)
  if not vd or not vd.config then return nil end
  local rt = vd.vdata and vd.vdata.bcfpRuntime
  if rt and rt.envKey and E.cache[rt.envKey] then return E.cache[rt.envKey] end
  local key = state.envKeyByVd and state.envKeyByVd[vd]
  if key and E.cache[key] then return E.cache[key] end
  if not build then return nil end
  state.envFailed = state.envFailed or setmetatable({}, {__mode = 'k'})
  if state.envFailed[vd] then return nil end
  local ok, env, err = pcall(E.forVehicle, vd)
  if ok and env then
    state.envKeyByVd = state.envKeyByVd or setmetatable({}, {__mode = 'k'})
    state.envKeyByVd[vd] = env.key
    return env
  end
  state.envFailed[vd] = tostring(ok and err or env)
  U.log('W', 'arac ortami kurulamadi: ' .. tostring(ok and err or env))
  return nil
end
UI.envFor = envFor

-- araci guncel konfigurasyonuyla yeniden yukle. Oyunun core_vehicle_partmgmt.setConfig'i tablolari birlestirdigi icin
-- (silinen ogeler geri gelirdi) kullanilmaz; onun yeniden yukleme adimlari burada aynen uygulanir.
local function respawnVehicle(veh, vid, vd)
  pcall(function()
    local ct = extensions.core_vehicle_configTarget
    if ct and ct.getTargetVehicleId and ct.getTargetVehicleId() == vid then
      local tp = (ct.getTargetPlayerId and ct.getTargetPlayerId()) or 0
      if be:getPlayerVehicleID(tp) == vid then veh.autoEnterVehiclePlayer = tostring(tp) else veh.autoEnterVehicle = 'false' end
    end
  end)
  return pcall(function() veh:respawn(serialize(vd.config)) end)
end

-- konfigurasyonu araca yaz; respawn = true ise arac yeniden yuklenir (parca konumu / sayisi degisince)
local function writeCfg(vid, cfg, respawn)
  local vd = vehData(vid)
  if not vd or not vd.config then return false end
  local veh = be:getObjectByID(vid)
  if not veh then return false end
  vd.config.bcfp = cfg
  if respawn then
    respawnVehicle(veh, vid, vd)
    state.pendingRespawn = os.clock()
    state.pendingEdit = false
  else
    pcall(function() veh:setField('partConfig', '', serialize(vd.config)) end)
    state.pendingEdit = true
  end
  state.markerCache = {}
  return true
end

local function vehCmd(vid, cmd)
  local veh = vid and be:getObjectByID(vid)
  if veh then veh:queueLuaCommand(cmd) return true end
  return false
end

-----------------------------------------------------------------------------------------------
-- canli isik ayari (isik studyosu)
-----------------------------------------------------------------------------------------------
local function getPropObj(veh, pid)
  local p
  pcall(function()
    local o = veh.obj
    if o and o.getProp then p = o:getProp(pid) end
  end)
  if not p then pcall(function() p = veh:getProp(pid) end) end
  return p
end

local function liveApplyGroup(vid, key, s, cfg)
  local vd = vehData(vid)
  local veh = vid and be:getObjectByID(vid)
  if not vd or not vd.vdata or not veh then return 0 end
  local profile = cfg.master.colorProfile
  local payload = {props = {}, glow = {}}
  local n = 0
  for _, prop in pairs(vd.vdata.props or {}) do
    local o = type(prop) == 'table' and prop._bcfp
    if o and o.g == key and prop.pid then
      local res = S.compute(o, s, profile)
      local p = getPropObj(veh, prop.pid)
      if p then
        pcall(function()
          local l = p:getLight()
          if l then
            local c = res.color
            local col = ColorF(c.r / 255, c.g / 255, c.b / 255, (c.a or 255) / 255)
            local att = vec3(0, 1, 1)
            if prop.lightAttenuation then att = vec3(prop.lightAttenuation) end
            l:setLightArgs(res.inner, res.outer, res.b, res.range, col, att, res.shadows and true or false)
            l:setLightArgs2(res.flareName, res.flareScale, prop.cookieName or '', prop.animationType or '',
              prop.animationPeriod or 1, prop.animationPhase or 1, prop.texSize or 256, prop.shadowSoftness or 1)
          end
        end)
      end
      S.applyToProp(prop, res)
      payload.props[#payload.props + 1] = {pid = prop.pid, b = U.r(res.b, 6), f = U.r(res.flareScale, 5),
        c = {res.color.r, res.color.g, res.color.b, res.color.a or 255}, ph = o.ph}
      n = n + 1
    end
  end
  local rt = vd.vdata.bcfpRuntime
  local gmap = vd.vdata.glowMap
  if rt and rt.glowAssigned and type(gmap) == 'table' then
    for mat, gkey in pairs(rt.glowAssigned) do
      if gkey == key or (key == 'bcfp:glow' and gkey == 'bcfp:glow') then
        local gm = gmap[mat]
        if type(gm) == 'table' then
          local isOwn = S.ladderBase(gm._bcfpOn0 or gm.on) ~= nil
          local on, onMax = S.glowFor({on = gm._bcfpOn0 or gm.on}, s and s.glow or 100, isOwn and cfg.master.glow or 100)
          payload.glow[mat] = {on = on, m = U.r(onMax, 4)}
        end
      end
    end
  end
  local cmd = 'if not bcfpLive then extensions.load("bcfpLive") end if bcfpLive then bcfpLive.apply(' .. serialize(payload) .. ') end'
  vehCmd(vid, cmd)
  return n
end
UI.liveApplyGroup = liveApplyGroup

-----------------------------------------------------------------------------------------------
-- ayar dosyalari
-----------------------------------------------------------------------------------------------
local function ensureDir()
  pcall(function() if FS and not FS:directoryExists(SETTINGS_DIR) then FS:directoryCreate(SETTINGS_DIR, true) end end)
end

local function loadProfiles()
  local ok, d = pcall(jsonReadFile, PROFILES_FILE)
  if ok and type(d) == 'table' then return d end
  return {}
end

local function saveProfiles(d)
  ensureDir()
  return pcall(jsonWriteFile, PROFILES_FILE, d, true)
end

local function loadAuto()
  if state.auto then return state.auto end
  local ok, d = pcall(jsonReadFile, AUTO_FILE)
  d = (ok and type(d) == 'table') and d or {}
  state.auto = {enabled = d.enabled == true, kit = kitById[d.kit] and d.kit or 'undercover', scheme = schemeById[d.scheme] and d.scheme or 'rb',
                lightbar = d.lightbar == true}
  if schemeById[d.lastScheme or ''] then state.scheme = d.lastScheme end
  return state.auto
end

local function saveAuto()
  ensureDir()
  local a = loadAuto()
  pcall(jsonWriteFile, AUTO_FILE, {enabled = a.enabled, kit = a.kit, scheme = a.scheme, lightbar = a.lightbar, lastScheme = state.scheme}, true)
end

-----------------------------------------------------------------------------------------------
-- bolge yardimcilari
-----------------------------------------------------------------------------------------------
-- ortamin bolge ozeti (arayuz haritasi): {id -> {avail, n, gap, x0, head, part, active}}
local function zoneInfo(env)
  if not env then return {} end
  if env.zoneInfo then return env.zoneInfo end
  local out = {}
  local avail = Pl.available(env)
  for _, z in ipairs(Pl.ZONES) do
    local a = avail[z.id]
    local info = {avail = a or false}
    if a then
      local okD, d = pcall(Pl.defaults, z.id, env, nil)
      if okD and d then
        if d.src == false then
          info.avail = false
        else
          info.n, info.gap, info.x0, info.head, info.part, info.active = d.n, d.gap, d.x0, d.head, d.part, d.active
        end
      end
      -- tarama bolgeleri: bir baslik gercekten yerlesebiliyor mu (ornek: torpido modeli olmayan arac)
      if info.avail == 'scan' and z.id ~= 'custom' then
        local trial = C.newItem('array', {anchor = z.id, head = info.head or z.head, n = 1})
        local okL, lay = pcall(Pl.layout, trial, env, Un.dims(trial))
        if not okL or not lay or lay.none then info.avail = false end
      end
    end
    out[z.id] = info
  end
  env.zoneInfo = out
  return out
end

-- bolge icin yeni dizi ogesi (varsayilanlar: fabrika duzeni / tarama cercevesi)
local function newZoneItem(zone, env, extra)
  local zi = zoneInfo(env)[zone] or {}
  local zd = Pl.zoneById[zone] or {}
  local sc = schemeById[state.scheme] or UI.SCHEMES[1]
  local it = {kind = 'array', anchor = zone, head = zi.head or zd.head, n = zi.n or zd.n, colL = sc.L, colR = sc.R,
              grp = REAR_ZONE[zone] and 2 or 1}
  if zone == 'custom' then
    -- serbest: tavanin ortasindan baslar (aracin icinde kaybolmasin), kullanici istedigi yere tasir
    local roof = env and env.anchors and env.anchors.roof
    it.x0 = 30
    it.y = roof and roof.y and U.r(roof.y * 100, 0) or 0
    it.z = roof and roof.z and U.r(roof.z * 100 + 3, 0) or 150
  end
  for k, v in pairs(extra or {}) do it[k] = v end
  return C.newItem('array', it)
end

local function hasZone(cfg, zone)
  for _, it in ipairs(cfg.items) do
    if it.kind == 'array' and it.anchor == zone then return true end
  end
  return false
end

local function countKind(cfg, kind)
  local n = 0
  for _, it in ipairs(cfg.items) do if it.kind == kind then n = n + 1 end end
  return n
end

-- kit ogeleri
local function kitItems(kit, env, schemeId)
  local zi = zoneInfo(env)
  local sc = schemeById[schemeId or kit.scheme or state.scheme] or UI.SCHEMES[1]
  local out, used = {}, {}
  for _, zs in ipairs(kit.zones) do
    local zone = zs[1]
    if (not zi[zone] or not zi[zone].avail or used[zone]) and zs.alt then zone = zs.alt end
    local info = zi[zone]
    if info and info.avail and not used[zone] then
      used[zone] = true
      local zd = Pl.zoneById[zone]
      local base = {kind = 'array', anchor = zone, head = info.head or zd.head, n = zs.n or info.n or zd.n, colL = sc.L, colR = sc.R,
                    grp = REAR_ZONE[zone] and 2 or 1, colB = zs.b or 0, bfn = zs.bfn or 1, adv = zs.adv or 0}
      if zs.fill then
        -- camin kullanilabilir genisligini doldur
        local ut = Un.get(base.head)
        local gap = max((info.gap or 6.5), ut.w * 100 + 0.2)
        local half = (env and env.M and Pl.frames(env.M).halfW or 0.8) * 100
        base.n = U.int((half * 0.78 - (info.x0 or 30)) / gap + 1, 4, 2, 10)
      end
      if zs.steps and zs.steps > 1 then
        -- kademeli (trafik oku): her kademe ayri dizi
        local ut = Un.get(base.head)
        local gap = max((info.gap or 6.5), ut.w * 100 + 0.2) * 2.2
        local x0 = max(8, (info.x0 or 30) - gap)
        for k = 1, zs.steps do
          local it = U.copy(base)
          it.x0 = U.r(x0 + (k - 1) * gap, 1)
          out[#out + 1] = it
        end
      else
        out[#out + 1] = base
      end
    end
  end
  return out
end

-----------------------------------------------------------------------------------------------
-- tepe lambasi yardimcilari (kopya / cubuk)
-----------------------------------------------------------------------------------------------
local function firstInstalled(vd)
  local list = Cat.installed(vd and vd.vdata)
  table.sort(list, function(a, b)
    if (a.score or 0) ~= (b.score or 0) then return (a.score or 0) > (b.score or 0) end
    if (a.lightsTotal > 0) ~= (b.lightsTotal > 0) then return a.lightsTotal > 0 end
    if a.depth ~= b.depth then return a.depth < b.depth end
    return tostring(a.part) < tostring(b.part)
  end)
  return list[1], list
end

local function spreadCopies(cfg, entry, count, vd, extra)
  local step
  if entry and entry.bbox then
    local depth = max(0.12, entry.bbox[5] - entry.bbox[2])
    step = max(depth + 0.08, 0.25)
  elseif entry and entry.ns then
    step = 0.5
  else
    step = 0.15
  end
  local made = 0
  for k = 1, count do
    local j = math.ceil(k / 2)
    local sgn = (k % 2 == 1) and 1 or -1
    local it = {kind = 'copy', part = entry.part, ns = entry.ns, file = entry.file, name = entry.name,
                anchor = entry.ns and 'roof' or 'orig', y = sgn * j * step}
    if extra then for kk, vv in pairs(extra) do it[kk] = vv end end
    local o = C.newItem('copy', it)
    if o then
      cfg.items[#cfg.items + 1] = o
      made = made + 1
    end
  end
  return made
end

-- multicolor bar icin tavanda bos yer: aracta zaten bir tepe lambasi varsa arkasina (yer yoksa onune)
local function mlbarSpot(vd, env)
  local roof = env and env.anchors and env.anchors.roof
  if not roof or not roof.y then return 0 end
  local ay = roof.y
  local F = env.M and Pl.frames(env.M)
  if F and F.roof then ay = F.roof.y end
  local half = 0.20
  local ry0, ry1 = roof.y0 or (ay - 0.6), roof.y1 or (ay + 0.6)
  for _, e in ipairs(Cat.installed(vd and vd.vdata)) do
    local bb = e.bbox
    if bb and (e.score or 0) >= 2 and bb[6] > (roof.z or 1.3) - 0.12 and bb[2] < ry1 and bb[5] > ry0 then
      if ay + half > bb[2] and ay - half < bb[5] then
        local behind = bb[5] + half + 0.03
        local front = bb[2] - half - 0.03
        if behind <= ry1 - 0.10 then return behind - ay end
        if front >= ry0 + 0.10 then return front - ay end
        return behind - ay
      end
    end
  end
  return 0
end
UI.mlbarSpot = mlbarSpot

-----------------------------------------------------------------------------------------------
-- durum paketi
-----------------------------------------------------------------------------------------------
local enumCache
local function enums()
  if enumCache then
    enumCache.modes = state.modes or UI.MODES
    return enumCache
  end
  local colors = {}
  for _, c in ipairs(P.colors) do
    local tones = {}
    for ti, t in ipairs(P.tones[c.id] or {}) do tones[ti] = {tr = t.tr, hex = t.hex} end
    colors[#colors + 1] = {idx = c.idx, id = c.id, tr = c.tr, hex = c.hex, tones = tones}
  end
  local mlColors = {}
  for i, code in ipairs(Gn.ML_CODES) do
    local c = P.byId[Gn.ML_CODE_COLOR[code]]
    mlColors[i] = {idx = i, id = code, tr = c.tr, hex = c.hex}
  end
  local flares = {}
  for _, f in ipairs(S.FLARE_TYPES) do flares[#flares + 1] = {id = f.id, tr = f.tr} end
  local heads = {}
  for _, h in ipairs(Un.TYPES) do
    heads[#heads + 1] = {id = h.id, tr = h.tr, w = U.r(h.w * 1000, 1), h = U.r(h.h * 1000, 1), d = U.r(h.d * 1000, 1), cd = h.cd, ang = h.ang,
                         cols = h.cols, rows = h.rows}
  end
  local zones = {}
  for _, z in ipairs(Pl.ZONES) do zones[#zones + 1] = {id = z.id, tr = z.tr, kind = z.kind, head = z.head, n = z.n, gap = z.gap} end
  local kits = {}
  for _, k in ipairs(UI.KITS) do kits[#kits + 1] = {id = k.id, tr = k.tr, desc = k.desc} end
  enumCache = {anchors = C.ANCHORS, zones = zones, heads = heads, colors = colors, mlColors = mlColors, flareTypes = flares,
    modes = state.modes or UI.MODES, patterns = UI.PATTERNS, mlLengths = C.ML_LENGTHS, max = C.MAX, bright = Un.BRIGHT,
    bfn = C.BFN, schemes = UI.SCHEMES, kits = kits, version = '3.0.0'}
  return enumCache
end

local function vehicleName(veh, vd)
  local name
  pcall(function()
    local model = vd and vd.config and vd.config.model
    local info = core_vehicles and core_vehicles.getModel and model and core_vehicles.getModel(model)
    if info and info.model then name = (info.model.Brand and (info.model.Brand .. ' ') or '') .. tostring(info.model.Name or model) end
  end)
  return name or (vd and vd.config and vd.config.model) or '?'
end

-- dizi ogelerinin fotometri ozeti (arayuzde gosterilir)
local function photometry(cfg)
  local out = {}
  for _, it in ipairs(cfg.items) do
    if it.kind == 'array' then
      local cd = Un.headCd(it)
      local ut = Un.get(it.head)
      local ang = it.light and it.light.ang or ut.ang
      local l = it.light or {}
      out[it.id] = {cd = U.r(cd, 0), side = U.r(cd * it.n, 0), lm = U.r(cd * Un.solidAngle(ang), 0),
                    lux10 = U.r(cd * it.n / 100, 1), rng = U.r((l.rmode == 1) and l.rng or Un.autoRange(cd * it.n), 0)}
    end
  end
  return out
end

function UI.buildState()
  local vid = targetVid()
  local auto = loadAuto()
  local out = {ok = false, enums = enums(), scan = {state = Cat.scan.state, done = Cat.scan.done, total = Cat.scan.total,
    count = #(Cat.scan.results or {}), deep = Cat.scan.deep}, markers = state.markers, status = state.status,
    scheme = state.scheme, auto = auto, pending = state.pendingEdit and true or false, lang = U.lang()}
  if not vid then out.msgCode = 'noVehicle' return out end
  local veh = be:getObjectByID(vid)
  local vd = vehData(vid)
  if not veh or not vd or not vd.vdata then out.msgCode = 'noData' return out end
  local cfg, has = currentCfg(vd)
  out.ok = true
  out.vid = vid
  out.model = vd.config and vd.config.model
  out.vehName = vehicleName(veh, vd)
  out.hasConfig = has
  out.cfg = cfg
  out.photo = photometry(cfg)
  local rt = vd.vdata.bcfpRuntime
  out.runtime = rt and {items = rt.items, attach = rt.attach, warnings = rt.warnings, hasMaster = rt.hasMaster,
                        hiddenFactory = rt.hiddenFactory} or nil
  out.groups = rt and rt.groups or {}
  out.installed = Cat.installed(vd.vdata)
  -- ortam: onbellekte varsa hemen, yoksa bir sonraki karede kurulur (yuzey taramasi ~1 sn surebilir)
  local env = envFor(vd, false)
  if env then
    local fac = {}
    for _, f in ipairs(env.factory or {}) do fac[#fac + 1] = {name = f.name, active = f.active, zones = f.zones} end
    out.env = {ready = true, scan = env.M ~= nil, tris = env.stats and env.stats.tris, time = env.stats and U.r(env.stats.time or 0, 2),
               warnings = env.warnings, zones = zoneInfo(env), factory = fac, roofBar = env.roofBar and env.roofBar.part or nil}
  elseif state.envFailed and state.envFailed[vd] then
    out.env = {ready = true, scan = false, zones = {}, factory = {}, warnings = {{k = 'envFail', v = tostring(state.envFailed[vd])}}}
  else
    out.env = {ready = false}
    state.envJob = vid
  end
  local prof = loadProfiles()
  local names = {}
  for name in pairs(prof[out.model or ''] or {}) do names[#names + 1] = name end
  table.sort(names)
  out.profiles = names
  local globals = {}
  for name in pairs(prof['*'] or {}) do globals[#globals + 1] = name end
  table.sort(globals)
  out.globalProfiles = globals
  return out
end

function UI.publish()
  local ok, st = pcall(UI.buildState)
  if not ok then
    U.log('E', 'arayuz durumu olusturulamadi: ' .. tostring(st))
    st = {ok = false, msgCode = 'error', msg = tostring(st), enums = enums(), lang = U.lang()}
  end
  guihooks.trigger(UI.EVENT, st)
  state.dirty = false
end

function UI.publishLibrary()
  guihooks.trigger('BcfpProLibrary', {state = Cat.scan.state, results = Cat.scan.results or {}, done = Cat.scan.done,
    total = Cat.scan.total, error = Cat.scan.error})
end

-----------------------------------------------------------------------------------------------
-- eylemler
-----------------------------------------------------------------------------------------------
local A = {}

function A.hello(a)
  state.appAlive = os.clock()
  state.dirty = true
end

function A.bye(a)
  state.appAlive = -1e9
end

function A.ping(a)
  state.appAlive = os.clock()
end

function A.select(a)
  if a and tonumber(a.vid) then state.vid = tonumber(a.vid) end
  state.dirty = true
end

local function withCfg(fn, respawn)
  local vid = targetVid()
  local vd = vehData(vid)
  if not vd then return end
  local cfg = currentCfg(vd)
  local r = fn(cfg, vd, vid)
  if r == false then return end
  cfg = C.sanitize(cfg)
  writeCfg(vid, cfg, respawn)
  state.dirty = true
end

-- bolgeyi ac / kapat (haritadaki tek tik)
function A.zoneToggle(a)
  local zone = a.zone
  if type(zone) ~= 'string' or not Pl.zoneById[zone] then return end
  withCfg(function(cfg, vd)
    if hasZone(cfg, zone) then
      for i = #cfg.items, 1, -1 do
        local it = cfg.items[i]
        if it.kind == 'array' and it.anchor == zone then table.remove(cfg.items, i) end
      end
      return
    end
    if countKind(cfg, 'array') >= C.MAX.array then
      guihooks.trigger('BcfpProError', {cmd = 'zoneToggle', code = 'maxArrays', n = C.MAX.array})
      return false
    end
    local env = envFor(vd, true)
    local o = newZoneItem(zone, env, type(a.item) == 'table' and a.item or nil)
    if not o then return false end
    cfg.items[#cfg.items + 1] = o
  end, true)
end

function A.addItem(a)
  withCfg(function(cfg, vd)
    local kind = a.kind
    local extra = type(a.item) == 'table' and a.item or {}
    local o
    if kind == 'array' then
      local env = envFor(vd, true)
      o = newZoneItem(extra.anchor or 'windshield', env, extra)
    else
      if kind == 'mlbar' and (extra.anchor == nil or extra.anchor == 'roof') and extra.y == nil then
        extra.y = mlbarSpot(vd, envFor(vd, true))
      end
      o = C.newItem(kind, extra)
    end
    if not o then return false end
    cfg.items[#cfg.items + 1] = o
  end, a.apply ~= false)
end

-- yeniden yukleme gerektirmeyen alanlar: renk / ton / parlaklik (lens materyali ve isik canli degisir),
-- desen ayarlari (arac tarafindaki kontrolcuye canli gider)
local LIVE_COLOR = {colL = true, colR = true, toneL = true, toneR = true, toneB = true, bright = true, colB = true}
local LIVE_CTRL = {pat = true, phase = true, side = true, lvl = true, grp = true, bfn = true, adv = true, kind2 = true}
local LIVE_LIGHT = {cd = true, unit = true, lm = true, lux = true, luxd = true}

local function liveArray(vid, it, cfg)
  local vd = vehData(vid)
  if not vd or not vd.vdata then return false end
  local num = C.itemIndex(it.id)
  if not num then return false end
  local zid = 'u' .. num
  local gmap = vd.vdata.glowMap or {}
  local L = Gn.glowLevel(cfg.master.glow)
  local profile = cfg.master.colorProfile
  local key = 'bcfp:' .. it.id
  local cdHead = Un.headCd(it)
  local tones = {}
  for _, sd in ipairs({'L', 'R'}) do
    local TA = P.tone((sd == 'L') and it.colL or it.colR, (sd == 'L') and it.toneL or it.toneR)
    tones[zid .. '_' .. sd] = TA
    local gm = gmap[Un.matA(num, sd)]
    if type(gm) == 'table' then
      gm._bcfpOn0 = 'bcfp_on_' .. TA.key .. '_4'
      gm.on = 'bcfp_on_' .. TA.key .. '_' .. L
      gm.off = (cfg.master.lens == 1) and ('bcfp_led_off_' .. TA.color) or 'bcfp_led_off_clear'
    end
    if (it.colB or 0) > 0 then
      local TB = P.tone(it.colB, it.toneB)
      tones[zid .. '_' .. sd .. '2'] = TB
      local gb = gmap[Un.matB(num, sd)]
      if type(gb) == 'table' then
        gb._bcfpOn0 = 'bcfp_on_' .. TB.key .. '_4'
        gb.on = 'bcfp_on_' .. TB.key .. '_' .. L
      end
    end
  end
  for _, prop in pairs(vd.vdata.props or {}) do
    local T = type(prop) == 'table' and prop.bcfpLight and tones[prop.bcfpLight]
    if T then
      local lin = (profile == 2 and T.tone == 1 and P.vivid[T.color]) or T.lin
      local Y = max(P.luminance(lin[1], lin[2], lin[3]), 0.05)
      local cdv = cdHead * (tonumber(prop.bcfpN) or 1)
      local o = S.snapshot(prop, key)
      o.c0 = {lin[1], lin[2], lin[3], 255}
      o.cd = cdv / Y
      o.lcd = cdv
      prop.bcfpCd = U.r(cdv, 1)
    end
  end
  liveApplyGroup(vid, key, S.effective(cfg, key, 'bcfp'), cfg)
  -- desen ayarlari
  local zf = {pat = it.pat, phase = U.r(it.phase / 100, 3), side = it.side, lvl = U.r(it.lvl / 100, 3), grp = it.grp, bfn = it.bfn,
              adv = it.adv, kind = it.kind2}
  vehCmd(vid, 'for _, c in pairs(controller.getControllersByType("bcfp_flasher")) do if c.bcfpSetZone then c.bcfpSetZone("' .. zid .. '", ' .. serialize(zf) .. ') end end')
  return true
end

function A.updateItem(a)
  local fields = type(a.fields) == 'table' and a.fields or {}
  local live = true
  local target
  withCfg(function(cfg, vd)
    for _, it in ipairs(cfg.items) do
      if it.id == a.id then
        target = it
        for k, v in pairs(fields) do
          if k == 'light' and type(v) == 'table' then
            it.light = it.light or {}
            for lk, lv in pairs(v) do
              if it.light[lk] ~= lv and not LIVE_LIGHT[lk] then live = false end
              it.light[lk] = lv
            end
          elseif k ~= 'id' and k ~= 'kind' then
            if it[k] ~= v then
              if it.kind ~= 'array' or not (LIVE_COLOR[k] or LIVE_CTRL[k]) then live = false end
              -- ikinci renk ac / kapat: ek lens modeli gerekir
              if k == 'colB' and ((tonumber(it.colB) or 0) > 0) ~= ((tonumber(v) or 0) > 0) then live = false end
            end
            it[k] = v
          end
        end
        -- arac henuz bu ogeyle yuklenmemisse canli guncellenemez
        local rt = vd.vdata and vd.vdata.bcfpRuntime
        local loaded = false
        for _, ri in ipairs(rt and rt.items or {}) do if ri.id == it.id and ri.src ~= 'none' then loaded = true end end
        if not loaded or state.pendingEdit then live = false end
        return
      end
    end
    return false
  end, (not live) and a.apply == true)
  if not target then return end
  if live then
    -- canli: yeniden yukleme yok, bekleyen degisiklik sayilmaz
    state.pendingEdit = false
    local vid = targetVid()
    local vd = vehData(vid)
    if vd then
      local cfg = currentCfg(vd)
      for _, it in ipairs(cfg.items) do
        if it.id == a.id then pcall(liveArray, vid, it, cfg) end
      end
    end
  end
end

-- ince ayar sifirlama (otomatik konuma don)
function A.resetItem(a)
  withCfg(function(cfg)
    for _, it in ipairs(cfg.items) do
      if it.id == a.id and it.kind == 'array' then
        it.x, it.y, it.z, it.yaw, it.tilt, it.x0, it.gap, it.sink, it.src = 0, 0, 0, 0, 0, -1, -1, -1, 'auto'
        return
      end
    end
    return false
  end, true)
end

function A.removeItem(a)
  withCfg(function(cfg)
    for i, it in ipairs(cfg.items) do
      if it.id == a.id then table.remove(cfg.items, i) return end
    end
    return false
  end, true)
end

function A.duplicateItem(a)
  withCfg(function(cfg)
    for _, it in ipairs(cfg.items) do
      if it.id == a.id then
        local c = U.copy(it)
        c.id = nil
        if c.kind == 'copy' or c.kind == 'mlbar' then c.y = (c.y or 0) + (a.dy or 0.5) end
        if c.kind == 'array' then
          -- ayni bolgede bir ust / dis sira
          local ut = Un.get(c.head)
          c.z = (c.z or 0) - (ut.h * 100 * (c.size or 100) / 100 + 0.4)
        end
        cfg.items[#cfg.items + 1] = c
        return
      end
    end
    return false
  end, true)
end

function A.copyInstalled(a)
  withCfg(function(cfg, vd)
    local entry
    for _, e in ipairs(Cat.installed(vd.vdata)) do if e.part == a.part then entry = e end end
    if not entry then entry = {part = a.part, name = a.part} end
    if spreadCopies(cfg, entry, U.int(a.count, 1, 1, 6), vd, a.extra) == 0 then return false end
  end, true)
end

function A.copyLibrary(a)
  withCfg(function(cfg, vd)
    local e = a.entry
    if type(e) ~= 'table' or type(e.part) ~= 'string' then return false end
    local model = vd.config and vd.config.model
    local ns = e.ns
    if ns == '/vehicles/' .. tostring(model) .. '/' or ns == '/vehicles/common/' then ns = nil end
    local entry = {part = e.part, ns = ns, file = e.file, name = e.name}
    if spreadCopies(cfg, entry, U.int(a.count, 1, 1, 6), vd, {anchor = (ns or a.roof) and 'roof' or 'orig'}) == 0 then return false end
  end, true)
end

function A.apply(a)
  withCfg(function() end, true)
end

function A.clearAll(a)
  local vid = targetVid()
  local vd = vehData(vid)
  if not vd or not vd.config then return end
  vd.config.bcfp = nil
  local veh = be:getObjectByID(vid)
  if veh then respawnVehicle(veh, vid, vd) end
  state.pendingEdit = false
  state.markerCache = {}
  state.dirty = true
end

-- hazir kit: a.id, a.scheme, a.keep (mevcut dizileri koru), a.lightbar (cubuk da ekle)
function A.kit(a)
  local kit = kitById[a.id]
  if a.id == 'clear' then
    withCfg(function(cfg)
      for i = #cfg.items, 1, -1 do if cfg.items[i].kind == 'array' then table.remove(cfg.items, i) end end
    end, true)
    return
  end
  if not kit then return end
  if schemeById[a.scheme or ''] then state.scheme = a.scheme end
  withCfg(function(cfg, vd)
    local env = envFor(vd, true)
    if not a.keep then
      for i = #cfg.items, 1, -1 do if cfg.items[i].kind == 'array' then table.remove(cfg.items, i) end end
    end
    local added = 0
    for _, it in ipairs(kitItems(kit, env, a.scheme)) do
      if not (a.keep and hasZone(cfg, it.anchor)) and countKind(cfg, 'array') < C.MAX.array then
        local o = C.newItem('array', it)
        if o then cfg.items[#cfg.items + 1] = o; added = added + 1 end
      end
    end
    if a.lightbar and countKind(cfg, 'mlbar') == 0 then
      cfg.items[#cfg.items + 1] = C.newItem('mlbar', {len = a.len or 139, anchor = 'roof', y = mlbarSpot(vd, env)})
    end
    if added == 0 and not a.lightbar then
      guihooks.trigger('BcfpProError', {cmd = 'kit', code = 'kitNone'})
      return false
    end
  end, true)
  saveAuto()
end

-- renk semasi: tum dizilerin sol / sag rengi
function A.scheme(a)
  local sc = schemeById[a.id or '']
  if not sc then return end
  state.scheme = sc.id
  saveAuto()
  withCfg(function(cfg)
    local any = false
    for _, it in ipairs(cfg.items) do
      if it.kind == 'array' and it.kind2 ~= 'white' then
        it.colL, it.colR, it.toneL, it.toneR = sc.L, sc.R, 1, 1
        any = true
      end
    end
    if not any then return false end
  end, true)
  state.dirty = true
end

-- tum dizilere ayni alanlar (ornek: parlaklik hazir ayari)
function A.allArrays(a)
  local f = type(a.fields) == 'table' and a.fields or {}
  withCfg(function(cfg)
    for _, it in ipairs(cfg.items) do
      if it.kind == 'array' then
        for k, v in pairs(f) do
          if k == 'light' and type(v) == 'table' then
            it.light = it.light or {}
            for lk, lv in pairs(v) do it.light[lk] = lv end
          elseif k ~= 'id' and k ~= 'kind' and k ~= 'anchor' then
            it[k] = v
          end
        end
      end
    end
  end, true)
end

function A.masterSet(a)
  local respawnKeys = {props = true, shadows = true, flare = true, flareType = true, cookie = true, lens = true, glow = true,
                       siren = true, colorProfile = true, hideFactory = true}
  local needRespawn = false
  withCfg(function(cfg)
    for k, v in pairs(a.fields or {}) do
      cfg.master[k] = v
      if respawnKeys[k] then needRespawn = true end
    end
  end, false)
  state.pendingEdit = needRespawn or state.pendingEdit
  local vid = targetVid()
  local f = a.fields or {}
  local live = {}
  for _, k in ipairs({'speed', 'day', 'night', 'cruise', 'wigwag', 'autoNight'}) do
    if f[k] ~= nil then live[k] = f[k] end
  end
  if next(live) then
    vehCmd(vid, 'for _, c in pairs(controller.getControllersByType("bcfp_flasher")) do if c.bcfpSetLive then c.bcfpSetLive(' .. serialize(live) .. ') end end')
  end
  if needRespawn and a.apply ~= false then withCfg(function() end, true) end
end

function A.studioSet(a)
  local key = a.key
  if type(key) ~= 'string' then return end
  local vid = targetVid()
  local vd = vehData(vid)
  if not vd then return end
  local cfg = currentCfg(vd)
  local s = C.sanitizeStudio(a.params or {})
  cfg.studio[key] = s
  if a.all then cfg.studio = {['*'] = s} end
  cfg = C.sanitize(cfg)
  local wasPending = state.pendingEdit
  writeCfg(vid, cfg, false)
  state.pendingEdit = wasPending
  local rt = vd.vdata and vd.vdata.bcfpRuntime
  local n = 0
  if a.all and rt and rt.groups then
    for _, g in ipairs(rt.groups) do
      if g.kind ~= 'veh' then n = n + liveApplyGroup(vid, g.key, s, cfg) end
    end
  else
    n = liveApplyGroup(vid, key, s, cfg)
  end
  -- isiklari hic islenmemis (bcfp konfigurasyonu olmadan yuklenmis) arac: bir kez yeniden yukle
  if n == 0 and not (rt and rt.groups) then writeCfg(vid, cfg, true) end
  state.dirty = true
end

function A.studioReset(a)
  local vid = targetVid()
  local vd = vehData(vid)
  if not vd then return end
  local cfg = currentCfg(vd)
  if a.key then cfg.studio[a.key] = nil else cfg.studio = {} end
  local wasPending = state.pendingEdit
  writeCfg(vid, cfg, false)
  state.pendingEdit = wasPending
  local rt = vd.vdata and vd.vdata.bcfpRuntime
  if rt and rt.groups then
    for _, g in ipairs(rt.groups) do
      if g.kind ~= 'veh' and (not a.key or g.key == a.key) then
        liveApplyGroup(vid, g.key, S.effective(cfg, g.key, g.kind), cfg)
      end
    end
  end
  state.dirty = true
end

function A.ctrl(a)
  local vid = targetVid()
  local c = a.cmd
  if c == 'lightbar' then
    vehCmd(vid, 'electrics.set_lightbar_signal(' .. U.int(a.value, 1, 0, 2) .. ')')
  elseif c == 'mode' then
    vehCmd(vid, 'local cs = controller.getControllersByType("bcfp_flasher") for _, c in pairs(cs) do if c.bcfpIsMaster and c.bcfpIsLeader and c.bcfpIsLeader() then c.setModeIndex(' .. U.int(a.value, 1, 1, 60) .. ') end end')
  elseif c == 'next' or c == 'prev' or c == 'night' or c == 'tkd' or c == 'aly' then
    local fn = ({next = 'nextMode', prev = 'prevMode', night = 'toggleNight', tkd = 'toggleTakedown', aly = 'toggleAlley'})[c]
    vehCmd(vid, 'local cs = controller.getControllersByType("bcfp_flasher") for _, c in pairs(cs) do if c.bcfpIsLeader and c.bcfpIsLeader() then c.' .. fn .. '() end end')
  elseif c == 'vanillaMode' then
    vehCmd(vid, 'for _, v in pairs(controller.getControllersByType("lightbar")) do v.toggleMode() end')
  end
end

function A.scan(a)
  Cat.startScan(a and a.deep)
  state.dirty = true
end

function A.library(a)
  UI.publishLibrary()
end

function A.markers(a)
  if a.on ~= nil then state.markers = a.on and true or false end
  state.markerItem = a.item
  state.markerAll = a.all and true or false
end

-- yuzey taramasini yenile (model degistiyse)
function A.rescan(a)
  E.invalidate()
  state.dirty = true
end

function A.profileSave(a)
  local vid = targetVid()
  local vd = vehData(vid)
  if not vd or type(a.name) ~= 'string' or a.name == '' then return end
  local model = a.global and '*' or (vd.config.model or '?')
  local prof = loadProfiles()
  prof[model] = prof[model] or {}
  local cfg = currentCfg(vd)
  if a.global then
    -- genel profil: araca ozel kopyalar tasinmaz (baska araclarda parca bulunmayabilir)
    for i = #cfg.items, 1, -1 do if cfg.items[i].kind == 'copy' then table.remove(cfg.items, i) end end
    cfg.studio = {}
  end
  prof[model][U.trimStr(a.name, 60)] = cfg
  saveProfiles(prof)
  state.dirty = true
end

function A.profileLoad(a)
  local vid = targetVid()
  local vd = vehData(vid)
  if not vd then return end
  local prof = loadProfiles()
  local m = a.global and '*' or (vd.config.model or '?')
  local p = prof[m] and prof[m][a.name]
  if not p then return end
  writeCfg(vid, C.sanitize(p), true)
  state.dirty = true
end

function A.profileDelete(a)
  local vid = targetVid()
  local vd = vehData(vid)
  if not vd then return end
  local prof = loadProfiles()
  local m = a.global and '*' or (vd.config.model or '?')
  if prof[m] then prof[m][a.name] = nil end
  saveProfiles(prof)
  state.dirty = true
end

-- arayuz / bildirim dili
function A.setLang(a)
  if not U.setLang(a.lang) then return end
  -- aractaki kontrolcunun bildirimleri (mod adlari, gece / takedown) de ayni dile gecer
  pcall(function()
    for i = 0, be:getObjectCount() - 1 do
      local veh = be:getObject(i)
      if veh and veh.queueLuaCommand then
        veh:queueLuaCommand('for _, c in pairs(controller.getControllersByType("bcfp_flasher")) do if c.bcfpSetLang then c.bcfpSetLang("' .. U.lang() .. '") end end')
      end
    end
  end)
  state.dirty = true
end

-- her araca otomatik uygula ayari
function A.auto(a)
  local au = loadAuto()
  if a.enabled ~= nil then au.enabled = a.enabled and true or false end
  if kitById[a.kit or ''] then au.kit = a.kit end
  if schemeById[a.scheme or ''] then au.scheme = a.scheme end
  if a.lightbar ~= nil then au.lightbar = a.lightbar and true or false end
  saveAuto()
  state.dirty = true
end

function UI.dispatch(cmd, args)
  local f = A[cmd]
  if not f then U.log('W', 'bilinmeyen arayuz komutu: ' .. tostring(cmd)) return end
  state.appAlive = os.clock()
  local ok, err = pcall(f, type(args) == 'table' and args or {})
  if not ok then
    U.log('E', 'arayuz komutu hatasi ' .. tostring(cmd) .. ': ' .. tostring(err))
    guihooks.trigger('BcfpProError', {cmd = cmd, err = tostring(err)})
  end
  if state.dirty then UI.publish() end
end

-----------------------------------------------------------------------------------------------
-- arac tarafindan gelen durum
-----------------------------------------------------------------------------------------------
function UI.onVehicleStatus(vid, st)
  if type(st) ~= 'table' then return end
  if vid ~= targetVid() then return end
  state.status = st
  if st.modes then state.modes = st.modes end
  guihooks.trigger('BcfpProStatus', st)
end

-----------------------------------------------------------------------------------------------
-- her araca otomatik uygula
-----------------------------------------------------------------------------------------------
function UI.onVehicleSpawned(vid)
  state.dirty = true
  state.markerCache = {}
  local au = loadAuto()
  if not au.enabled then return end
  local okP, pid = pcall(function() return be:getPlayerVehicleID(0) end)
  if not okP or pid ~= vid then return end
  local now = os.clock()
  if state.autoGuard[vid] and now - state.autoGuard[vid] < 5 then return end
  local vd = vehData(vid)
  if not vd or not vd.config or vd.config.bcfp ~= nil then return end
  -- yalnizca otomobil / kamyon turleri
  local okT, typ = pcall(function()
    local info = core_vehicles.getModel(vd.config.model)
    return info and info.model and info.model.Type
  end)
  if not okT or (typ ~= 'Car' and typ ~= 'Truck') then return end
  state.autoGuard[vid] = now
  state.autoJob = {vid = vid, t = now}
end

local function runAutoJob()
  local job = state.autoJob
  state.autoJob = nil
  if not job then return end
  local vd = vehData(job.vid)
  if not vd or not vd.config or vd.config.bcfp ~= nil then return end
  local au = loadAuto()
  local kit = kitById[au.kit]
  if not kit then return end
  local env = envFor(vd, true)
  if not env then return end
  local cfg = C.sanitize({})
  for _, it in ipairs(kitItems(kit, env, au.scheme)) do
    local o = C.newItem('array', it)
    if o then cfg.items[#cfg.items + 1] = o end
  end
  if au.lightbar then cfg.items[#cfg.items + 1] = C.newItem('mlbar', {len = 139, anchor = 'roof', y = mlbarSpot(vd, env)}) end
  if #cfg.items == 0 then return end
  cfg = C.sanitize(cfg)
  writeCfg(job.vid, cfg, true)
  pcall(function() guihooks.message(string.format(U.txt('autoApplied'), (U.txt('kits') or {})[kit.id] or kit.tr), 4, 'bcfp.auto') end)
end

-----------------------------------------------------------------------------------------------
-- yerlesim onizlemesi: basliklarin dunya uzayinda tel kutulari (arac yeniden yuklenmeden)
-----------------------------------------------------------------------------------------------
local function worldFrame(veh, vdata)
  local rn = vdata.refNodes and vdata.refNodes[0]
  if not rn or not vdata.nodes then return nil end
  local function L(cid) local n = vdata.nodes[cid] return n and n.pos end
  local ref, back, left, up = rn.ref, rn.back, rn.left, rn.up
  local Lr, Lb, Ll, Lu = L(ref), L(back), L(left), L(up)
  if not (Lr and Lb and Ll and Lu) then return nil end
  local vp = veh:getPosition()
  local function W(cid) return veh:getNodePosition(cid) + vp end
  local Wr, Wb, Wl, Wu = W(ref), W(back), W(left), W(up)
  local function nrm(v) local l = v:length() if l < 1e-6 then return v end return v / l end
  local ly, lx = nrm(Lb - Lr), nrm(Ll - Lr)
  local wy, wx = nrm(Wb - Wr), nrm(Wl - Wr)
  local lz, wz = nrm(lx:cross(ly)), nrm(wx:cross(wy))
  ly, wy = nrm(lz:cross(lx)), nrm(wz:cross(wx))
  return function(x, y, z)
    local d = vec3(x, y, z) - Lr
    local a, b, c = d:dot(lx), d:dot(ly), d:dot(lz)
    return Wr + wx * a + wy * b + wz * c
  end
end

local EDGES = {{1, 2}, {2, 4}, {4, 3}, {3, 1}, {5, 6}, {6, 8}, {8, 7}, {7, 5}, {1, 5}, {2, 6}, {3, 7}, {4, 8}}

-- baslik kutusunun 8 kosesi (arac koordinatlari)
local function boxCorners(h, dims)
  local a, t = rad(h.yaw or 0), rad(-(h.tilt or 0))
  local cz, sz, cx, sx = cos(a), sin(a), cos(t), sin(t)
  local hw, hd, hh = dims.w / 2, dims.d / 2, dims.h / 2
  local out = {}
  for _, s in ipairs({{-1, -1, -1}, {1, -1, -1}, {-1, 1, -1}, {1, 1, -1}, {-1, -1, 1}, {1, -1, 1}, {-1, 1, 1}, {1, 1, 1}}) do
    local lx, ly, lz = s[1] * hw, s[2] * hd, s[3] * hh
    -- Rx(t) sonra Rz(a)
    local y1, z1 = ly * cx - lz * sx, ly * sx + lz * cx
    local x2, y2 = lx * cz - y1 * sz, lx * sz + y1 * cz
    out[#out + 1] = {h.x + x2, h.y + y2, h.z + z1}
  end
  return out
end

local SRC_COLOR = {factory = {0.25, 1, 0.35}, scan = {1, 0.62, 0.1}, approx = {1, 0.3, 0.3}}

local function markerLayout(it, env)
  local sig = serialize(it)
  local c = state.markerCache[it.id]
  if c and c.sig == sig and c.envKey == env.key then return c end
  local dims = Un.dims(it)
  local ok, lay = pcall(Pl.layout, it, env, dims)
  c = {sig = sig, envKey = env.key, dims = dims, boxes = {}, src = ok and lay.src or 'none'}
  if ok and lay and not lay.none then
    for _, sd in ipairs({'L', 'R'}) do
      for _, h in ipairs(lay[sd] or {}) do
        c.boxes[#c.boxes + 1] = {corners = boxCorners(h, dims), src = h.src, pos = {h.x, h.y, h.z}, yaw = h.yaw, tilt = h.tilt or 0}
      end
    end
  end
  state.markerCache[it.id] = c
  return c
end

function UI.onPreRender()
  if not state.markers or not appOpen() then return end
  if not state.markerItem and not state.markerAll then return end
  local vid = targetVid()
  local veh = vid and be:getObjectByID(vid)
  local vd = vehData(vid)
  if not veh or not vd or not vd.vdata or not debugDrawer then return end
  local env = envFor(vd, false)
  if not env then return end
  local toWorld = worldFrame(veh, vd.vdata)
  if not toWorld then return end
  local cfg = currentCfg(vd)
  for _, it in ipairs(cfg.items) do
    if it.kind == 'array' and (state.markerAll or state.markerItem == it.id) then
      local sel = state.markerItem == it.id
      local c = markerLayout(it, env)
      for _, b in ipairs(c.boxes) do
        local rgb = SRC_COLOR[b.src] or SRC_COLOR.scan
        local col = ColorF(rgb[1], rgb[2], rgb[3], sel and 1 or 0.55)
        local w = {}
        for i, p in ipairs(b.corners) do w[i] = toWorld(p[1], p[2], p[3]) end
        pcall(function()
          for _, e in ipairs(EDGES) do debugDrawer:drawLine(w[e[1]], w[e[2]], col) end
          if sel then
            -- lens yonu
            local a, t = rad(b.yaw or 0), rad(b.tilt or 0)
            local fx, fy, fz = sin(a) * cos(t), -cos(a) * cos(t), sin(t)
            local p0 = toWorld(b.pos[1], b.pos[2], b.pos[3])
            local p1 = toWorld(b.pos[1] + fx * 0.09, b.pos[2] + fy * 0.09, b.pos[3] + fz * 0.09)
            debugDrawer:drawLine(p0, p1, ColorF(1, 1, 1, 0.9))
          end
        end)
      end
    end
  end
end

-----------------------------------------------------------------------------------------------
-- gece sensoru: gunun saatine gore araclara bildir (0 = oglen, 0.5 = gece yarisi)
local function isNightTime()
  local ok, tod = pcall(function() return core_environment and core_environment.getTimeOfDay and core_environment.getTimeOfDay() end)
  if not ok or type(tod) ~= 'table' or type(tod.time) ~= 'number' then return nil end
  local t = tod.time % 1
  return t > 0.245 and t < 0.755
end
UI.isNightTime = isNightTime

local function pushEnvironment()
  local n = isNightTime()
  if n == nil then return end
  local val = n and 1 or 0
  if state.lastEnv == val and (state.envRepeat or 0) < 6 then
    state.envRepeat = (state.envRepeat or 0) + 1
    return
  end
  state.lastEnv, state.envRepeat = val, 0
  pcall(function()
    for i = 0, be:getObjectCount() - 1 do
      local veh = be:getObject(i)
      if veh and veh.queueLuaCommand then
        local vd = vehData(veh:getID())
        if vd and vd.vdata and vd.vdata.bcfpRuntime and vd.vdata.bcfpRuntime.hasMaster then
          veh:queueLuaCommand('electrics.values.bcfp_env_night = ' .. val)
        end
      end
    end
  end)
end

function UI.onUpdate(dt)
  state.envT = (state.envT or 0) + (dt or 0)
  if state.envT > 3 then
    state.envT = 0
    pushEnvironment()
  end
  if state.autoJob and os.clock() - state.autoJob.t > 0.6 then
    local ok, err = pcall(runAutoJob)
    if not ok then U.log('W', 'otomatik uygulama hatasi: ' .. tostring(err)) end
  end
  if Cat.scan.state == 'running' then
    if Cat.update() then
      UI.publishLibrary()
      state.dirty = true
    end
    state.scanPublishT = (state.scanPublishT or 0) + (dt or 0)
    if state.scanPublishT > 0.5 then
      state.scanPublishT = 0
      guihooks.trigger('BcfpProScan', {state = Cat.scan.state, done = Cat.scan.done, total = Cat.scan.total})
    end
  end
  if not appOpen() then return end
  -- ortam kurulumu (yuzey taramasi): durum paketi "taraniyor" olarak gittikten sonraki karede
  if state.envJob then
    state.envWait = (state.envWait or 0) + 1
    if state.envWait >= 3 then
      local vid = state.envJob
      state.envJob, state.envWait = nil, 0
      local vd = vehData(vid)
      if vd then
        envFor(vd, true)
        state.dirty = true
      end
    end
  end
  if state.dirty then
    state.publishT = (state.publishT or 0) + (dt or 0)
    if state.publishT > 0.15 then
      state.publishT = 0
      UI.publish()
    end
  end
end

function UI.markDirty() state.dirty = true end

return UI
