-- Better Concealed Flashers PRO 3 - arac konfigurasyonu (vehicleConfig.bcfp) semasi ve dogrulama
-- Tum ayarlar aracin kendi konfigurasyonunda saklanir; .pc olarak kaydedilince birlikte kaydedilir.
local C = {}
local U, Un, Pl

function C.init(mods)
  U, Un, Pl = mods.U, mods.Un, mods.Pl
  C.ZONES = Pl.ZONES
  C.zoneById = Pl.zoneById
  C.MAX.array = Un.MAX
end

C.VERSION = 3
C.MAX = {copy = 12, array = 24, mlbar = 6}
C.ML_LENGTHS = {116, 139, 161}

-- kopya / cubuk icin montaj yerleri
C.ANCHORS = {
  {id = 'orig',   tr = 'Orijinal yeri (kopyalanan parçanın kendi yeri)'},
  {id = 'roof',   tr = 'Tavan (otomatik)'},
  {id = 'custom', tr = 'Serbest (aracın merkezine göre)'},
}
C.anchorById = {}
for _, a in ipairs(C.ANCHORS) do C.anchorById[a.id] = a end

-- ikinci renk (B kanali) islevleri
C.BFN = {
  {id = 1, tr = 'Takedown (beyaz aydınlatma tuşuyla sabit yanar)'},
  {id = 2, tr = 'Sahne / park modlarında sabit yanar'},
  {id = 3, tr = 'Ana renkle dönüşümlü çakar'},
  {id = 4, tr = 'Trafik oku modlarında ok rengi'},
  {id = 5, tr = 'Seyir modlarında kısık sabit yanar'},
}

local function num(v, d, lo, hi) return U.num(v, d, lo, hi) end
local function int(v, d, lo, hi) return U.int(v, d, lo, hi) end

local function sanitizeLight(l, d)
  l = type(l) == 'table' and l or {}
  d = d or {}
  return {
    unit = int(l.unit, d.unit or 1, 1, 3),         -- 1 kandela, 2 lumen, 3 luks@mesafe
    cd = num(l.cd, d.cd or -1, -1, 300000),        -- -1: baslik tipine ve parlaklik ayarina gore otomatik
    lm = num(l.lm, d.lm or 800, 1, 100000),
    lux = num(l.lux, d.lux or 30, 0.1, 20000),
    luxd = num(l.luxd, d.luxd or 10, 0.5, 200),
    rmode = int(l.rmode, d.rmode or 2, 1, 2),      -- 1 metre, 2 otomatik (esik luks)
    rng = num(l.rng, d.rng or 30, 1, 500),
    ang = num(l.ang, d.ang or 100, 3, 178),
    inner = num(l.inner, d.inner or 10, 1, 170),
    lpl = U.bool(l.lpl, d.lpl or false),           -- her baslik icin ayri isik kaynagi
  }
end
C.sanitizeLight = sanitizeLight

local AXES = {x = true, y = true, z = true}

local function sanitizeItem(it, legacy)
  if type(it) ~= 'table' then return nil end
  local kind = it.kind
  if kind ~= 'copy' and kind ~= 'array' and kind ~= 'mlbar' then return nil end
  local o = {kind = kind, on = U.bool(it.on, true)}
  o.id = type(it.id) == 'string' and it.id or nil
  o.name = type(it.name) == 'string' and U.trimStr(it.name, 80) or nil
  if kind == 'copy' then
    if type(it.part) ~= 'string' or it.part == '' then return nil end
    o.anchor = C.anchorById[it.anchor] and it.anchor or 'orig'
    o.x = num(it.x, 0, -5, 5)
    o.y = num(it.y, 0, -15, 15)
    o.z = num(it.z, 0, -3, 5)
    o.yaw = num(it.yaw, 0, -180, 180)
    o.pitch = num(it.pitch, 0, -45, 45)
    o.roll = num(it.roll, 0, -45, 45)
    o.part = it.part
    o.ns = (type(it.ns) == 'string' and it.ns:match('^/vehicles/[^/]+/$')) and it.ns or nil
    o.file = type(it.file) == 'string' and it.file or nil
    o.scale = num(it.scale, 1, 0.3, 3)
    o.subs = int(it.subs, 0, 0, 1)
    o.attach = (it.attach == 'orig' or it.attach == 'synthetic') and it.attach or 'auto'
    o.ctrl = int(it.ctrl, 0, 0, 1)            -- 1: kopyanin kendi desen kontrolcusunu de calistir
    o.lsrc = int(it.lsrc, 0, 0, 2)            -- gercek isik kaynaklari: 0 tumu, 1 yarisi, 2 yok (sadece lens)
  elseif kind == 'array' then
    local anchor = it.anchor
    if legacy and anchor == 'orig' then anchor = 'windshield' end
    o.anchor = (type(anchor) == 'string' and C.zoneById and C.zoneById[anchor]) and anchor or 'windshield'
    local zd = (C.zoneById and C.zoneById[o.anchor]) or {}
    local head = it.head
    if head == 'led' then head = 'std' end
    o.head = Un.byId[head] and head or (zd.head or 'std')
    o.src = (it.src == 'scan' or it.src == 'approx') and it.src or 'auto'
    o.n = int(it.n, zd.n or 3, 1, 10)
    o.gap = num(it.gap, -1, -1, 120)           -- cm; -1 = otomatik (fabrika araligi / baslik genisligi)
    o.x0 = num(it.x0, -1, -1, 250)             -- cm; -1 = otomatik
    o.mirror = U.bool(it.mirror, true)
    o.axis = AXES[it.axis] and it.axis or 'x'
    o.dirx = (tonumber(it.dirx) == -1) and -1 or 1
    o.facing = (it.facing == 'side') and 'side' or num(it.facing, -999, -999, 180)
    -- ince ayar: bolgenin otomatik konumuna gore kaydirma (cm) ve ek acilar (derece)
    if legacy then
      o.x, o.y, o.z, o.yaw, o.tilt = 0, 0, 0, 0, 0
      o.x0, o.gap = -1, -1
    else
      -- serbest bolgede konum aracin merkezine gore verilir: genis aralik
      local lim = (o.anchor == 'custom') and 600 or 80
      o.x = num(it.x, 0, -lim, lim)
      o.y = num(it.y, 0, -lim, lim)
      o.z = num(it.z, 0, -lim, lim)
      o.yaw = num(it.yaw, 0, -180, 180)
      o.tilt = num(it.tilt, 0, -80, 80)
    end
    o.size = num(it.size, 100, 50, 250)
    o.sink = num(it.sink, -1, -1, 100)         -- dis yuzeylerde gomme orani (%); -1 = otomatik
    o.follow = int(it.follow, 1, 0, 1)         -- yuzeyin yatay egimini izle
    o.ftilt = int(it.ftilt, 0, 0, 1)           -- yuzeyin dikey egimini izle
    o.colL = int(it.colL, 1, 1, 6)
    o.colR = int(it.colR, 2, 1, 6)
    o.toneL = int(it.toneL, 1, 1, 3)
    o.toneR = int(it.toneR, 1, 1, 3)
    o.colB = int(it.colB, 0, 0, 6)             -- ikinci renk (0 = yok)
    o.toneB = int(it.toneB, 1, 1, 3)
    o.bfn = int(it.bfn, 1, 1, #C.BFN)
    o.kind2 = (it.kind2 == 'white') and 'white' or 'color'   -- beyaz (takedown) bolgesi
    o.grp = int(it.grp, 1, 1, 2)
    o.pat = int(it.pat, 0, 0, 40)
    o.phase = num(it.phase, 0, 0, 100)
    o.side = int(it.side, 0, 0, 2)
    o.lvl = num(it.lvl, 100, 5, 100)
    o.adv = int(it.adv, 0, 0, 1)               -- trafik oku (advisor) uyesi
    o.bright = int(it.bright, 2, 1, 4)
    local l = it.light
    if legacy and type(l) == 'table' and (tonumber(l.cd) == 3000 or tonumber(l.cd) == 3500 or tonumber(l.cd) == 4500) then
      l = U.copy(l)
      l.cd = -1
    end
    local ut = Un.get(o.head)
    o.light = sanitizeLight(l, {cd = -1, ang = ut.ang, rng = 30})
  elseif kind == 'mlbar' then
    o.anchor = (it.anchor == 'custom') and 'custom' or 'roof'
    o.x = num(it.x, 0, -5, 5)
    o.y = num(it.y, 0, -15, 15)
    o.z = num(it.z, 0, -3, 5)
    o.yaw = num(it.yaw, 0, -180, 180)
    o.pitch = num(it.pitch, 0, -45, 45)
    o.roll = num(it.roll, 0, -45, 45)
    local len = int(it.len, 139)
    if len ~= 116 and len ~= 139 and len ~= 161 then len = 139 end
    o.len = len
    o.colA = int(it.colA, 1, 1, 4)
    o.colB = int(it.colB, 2, 1, 4)
    o.colC = int(it.colC, 3, 1, 4)
    o.arrow = int(it.arrow, 4, 1, 4)
    o.lvl = num(it.lvl, 100, 5, 100)
    o.wlvl = num(it.wlvl, 100, 5, 100)
    o.light = sanitizeLight(it.light, {cd = 6000, ang = 120, rng = 35, rmode = 2})
    if o.light.cd <= 0 then o.light.cd = 6000 end
    o.wcd = num(it.wcd, 9000, 50, 200000)
    o.wrng = num(it.wrng, 45, 1, 500)
    o.wang = num(it.wang, 75, 5, 170)
    o.disable = type(it.disable) == 'table' and {
      r = U.bool(it.disable.r, false), b = U.bool(it.disable.b, false),
      w = U.bool(it.disable.w, false), a = U.bool(it.disable.a, false)} or {r = false, b = false, w = false, a = false}
  end
  return o
end

-- isik studyosu grup ayari
local function sanitizeStudio(s)
  if type(s) ~= 'table' then return nil end
  return {
    imode = int(s.imode, 0, 0, 4),       -- 0 orijinal, 1 carpan, 2 kandela, 3 lumen, 4 luks@mesafe
    imult = num(s.imult, 100, 1, 2000),
    cd = num(s.cd, 5000, 10, 300000),
    lm = num(s.lm, 1500, 1, 200000),
    lux = num(s.lux, 50, 0.1, 50000),
    luxd = num(s.luxd, 10, 0.5, 300),
    comp = int(s.comp, 1, 0, 1),         -- renkli isikta fotometrik dengeleme
    rmode = int(s.rmode, 0, 0, 3),       -- 0 orijinal, 1 carpan, 2 metre, 3 otomatik
    rmult = num(s.rmult, 100, 5, 2000),
    rng = num(s.rng, 40, 1, 600),
    rlux = num(s.rlux, 2, 0.05, 100),
    ang = num(s.ang, 0, 0, 178),         -- 0 orijinal
    inner = num(s.inner, 12, 1, 170),
    flareType = int(s.flareType, 0, 0, 6), -- 0 orijinal, 1 yumusak, 2 far, 3 yildiz, 4 isinsal, 5 gunes, 6 kapali
    flare = num(s.flare, 100, 0, 1000),  -- % (orijinal olcegin)
    glow = num(s.glow, 100, 0, 800),     -- % lens parlamasi (kendi LED'lerimizde 800'e kadar)
    color = int(s.color, -1, -1, 2),     -- -1 genel ayara gore, 0 orijinal, 1 gercekci LED, 2 canli
    shadow = int(s.shadow, 0, 0, 2),     -- 0 orijinal, 1 kapali, 2 acik
  }
end
C.sanitizeStudio = sanitizeStudio

C.MASTER_DEFAULT = {
  mode = 1, speed = 100, day = 100, night = 35, autoNight = 1, nightDefault = 0, cruise = 20,
  wigwag = 1, props = 1, shadows = 0, flare = 50, flareType = 3, cookie = 1, lens = 0, glow = 100,
  siren = '', colorProfile = 1, hideFactory = 1,
}

function C.sanitizeMaster(m)
  m = type(m) == 'table' and m or {}
  local d = C.MASTER_DEFAULT
  return {
    mode = int(m.mode, d.mode, 1, 60),
    speed = num(m.speed, d.speed, 20, 400),
    day = num(m.day, d.day, 5, 100),
    night = num(m.night, d.night, 5, 100),
    autoNight = int(m.autoNight, d.autoNight, 0, 1),
    nightDefault = int(m.nightDefault, d.nightDefault, 0, 1),
    cruise = num(m.cruise, d.cruise, 2, 100),
    wigwag = int(m.wigwag, d.wigwag, 0, 1),
    props = int(m.props, d.props, 0, 1),
    shadows = int(m.shadows, d.shadows, 0, 1),
    flare = num(m.flare, d.flare, 0, 400),
    flareType = int(m.flareType, d.flareType, 1, 6),
    cookie = int(m.cookie, d.cookie, 1, 3),
    lens = int(m.lens, d.lens, 0, 1),
    glow = num(m.glow, d.glow, 10, 800),
    siren = type(m.siren) == 'string' and U.trimStr(m.siren, 80) or '',
    colorProfile = int(m.colorProfile, d.colorProfile, 0, 2),
    hideFactory = int(m.hideFactory, d.hideFactory, 0, 1),   -- ayni yerdeki fabrika cakarlarini gizle
  }
end

function C.sanitize(cfg)
  if type(cfg) ~= 'table' then return nil end
  local legacy = (tonumber(cfg.v) or 2) < 3 and type(cfg.items) == 'table' and #cfg.items > 0
  local out = {v = C.VERSION, enabled = U.bool(cfg.enabled, true), items = {}, studio = {}}
  out.master = C.sanitizeMaster(cfg.master)
  local counters = {copy = 0, array = 0, mlbar = 0}
  local usedIds = {}
  local prefix = {copy = 'c', array = 'a', mlbar = 'm'}
  for _, it in ipairs(type(cfg.items) == 'table' and cfg.items or {}) do
    local o = sanitizeItem(it, legacy)
    if o then
      counters[o.kind] = counters[o.kind] + 1
      if counters[o.kind] <= C.MAX[o.kind] then
        -- kimlik: tur onekli ve 1..MAX araliginda benzersiz (dizi icin lens / elektrik numarasi buna bagli)
        local id = o.id
        local okId = type(id) == 'string' and id:match('^' .. prefix[o.kind] .. '(%d+)$')
        if not okId or usedIds[id] or tonumber(okId) < 1 or tonumber(okId) > C.MAX[o.kind] then
          id = nil
          for k = 1, C.MAX[o.kind] do
            local cand = prefix[o.kind] .. k
            if not usedIds[cand] then id = cand break end
          end
        end
        if id then
          o.id = id
          usedIds[id] = true
          out.items[#out.items + 1] = o
        end
      end
    end
  end
  if type(cfg.studio) == 'table' then
    for k, s in pairs(cfg.studio) do
      if type(k) == 'string' and #k < 300 then
        local v = sanitizeStudio(s)
        if v then out.studio[k] = v end
      end
    end
  end
  return out
end

-- yeni oge icin varsayilanlar (arayuz kullanir)
function C.newItem(kind, extra)
  local it = {kind = kind}
  for k, v in pairs(extra or {}) do it[k] = v end
  return sanitizeItem(it, false)
end

function C.itemIndex(id)
  return tonumber(type(id) == 'string' and id:match('%d+$') or nil)
end

return C
