-- Better Concealed Flashers PRO - aracin dugum bulutundan montaj noktalari (her araca uyum)
-- Koordinatlar jbeam arac uzayindadir: +x sol, +y geri (on = -y), +z yukari (metre).
local G = {}

local U
local min, max, abs, floor, sqrt = math.min, math.max, math.abs, math.floor, math.sqrt

function G.init(util) U = util end

-- govdeye ait olmayan (tekerlek, aks, motor ...) dugum gruplari
local EXCLUDE = {
  'wheel', 'tire', 'tyre', 'hub', 'axle', 'suspension', 'spring', 'shock', 'strut', 'damper', 'brake',
  'engine', 'transmission', 'gearbox', 'exhaust', 'driveshaft', 'halfshaft', 'steer', 'sway', 'tierod',
  'trackbar', 'leaf', 'coilover', 'antenna', 'lightbar', 'light_bar', 'roofrack', 'roof_rack', 'bcfp',
  'mudflap', 'hitch', 'bullbar', 'pushbar', 'snorkel', 'spare', 'ladder', 'winch', 'rack', 'cargo',
  'license', 'flag', 'siren', 'beacon', 'spotlight'
}
G.EXCLUDE = EXCLUDE

-- jbeam'de grup dizi ya da metin; yuklenmis arac verisinde (vdata) {grupAdi = true} sozlugu olabilir
local function groupsOf(n)
  local g = n.group
  if type(g) == 'string' then return {g} end
  if type(g) == 'table' then
    if g[1] ~= nil or next(g) == nil then return g end
    local out = {}
    for k, v in pairs(g) do
      if type(k) == 'string' then out[#out + 1] = k elseif type(v) == 'string' then out[#out + 1] = v end
    end
    return out
  end
  return {}
end
G.groupsOf = groupsOf

local function isExcluded(n)
  if type(n.name) == 'string' and (n.name:find('_bcfp', 1, true) or n.name:sub(1, 5) == 'bcfp_') then return true end
  for _, g in ipairs(groupsOf(n)) do
    if U.containsAny(g, EXCLUDE) then return true end
  end
  -- yuklenmis arac verisinde dugum gruplari yok: dugumu tanimlayan parcanin adina bak
  if type(n.part) == 'string' and n.part ~= '' and U.containsAny(n.part, EXCLUDE) then return true end
  return false
end
G.isExcluded = isExcluded

local function percentile(list, p)
  if #list == 0 then return nil end
  table.sort(list)
  local i = max(1, min(#list, floor(p * (#list - 1) + 1.5)))
  return list[i]
end

local function median(list) return percentile(list, 0.5) end

local function hasGroupWord(n, word)
  for _, g in ipairs(groupsOf(n)) do
    if U.lower(g):find(word, 1, true) then return true end
  end
  return false
end

-- Arac modeline ozel kesin konumlar (Grand Marshal icin orijinal BCFP olculeri)
G.MODEL_OVERRIDES = {
  fullsize = {
    windshield = {y = -0.20, z = 1.35, x0 = 0.34, scale = {1.0, 1.0, 0.55}},
    rearglass  = {y = 1.82, z = 1.06, x0 = 0.26, scale = {1.3, 1.3, 1.1}},
    bumperF    = {y = -2.35, z = 0.39, x0 = 0.43, curve = 0.32},
    grille     = {y = -2.31, z = 0.66, x0 = 0.12},
    trunk      = {y = 2.79, z = 0.68, x0 = 0.26, scale = {1.0, 1.0, 0.5}},
    mirrors    = {y = -0.525, z = 1.02, x0 = 0.98, scale = {0.9, 0.9, 0.7}},
    sideRear   = {y = 0.86, z = 1.20, x0 = 0.78},
    roof       = {y = 0.36, z = 1.45},
  },
}

-- nodes: {name, x, y, z, group}
function G.compute(nodes, model)
  local body = {}
  local all = {}
  for _, n in pairs(nodes) do
    if type(n) == 'table' and n.x and n.y and n.z then
      all[#all + 1] = n
      if not isExcluded(n) then body[#body + 1] = n end
    end
  end
  if #body < 8 then body = all end
  local res = {ok = #body >= 8, count = #body}
  if #body == 0 then
    res.ok = false
    res.bbox = {xmin = -0.9, xmax = 0.9, ymin = -2.3, ymax = 2.3, zmin = 0.2, zmax = 1.4}
    body = {}
  end

  local xs, ys, zs, ax = {}, {}, {}, {}
  for _, n in ipairs(body) do
    xs[#xs + 1] = n.x; ys[#ys + 1] = n.y; zs[#zs + 1] = n.z; ax[#ax + 1] = abs(n.x)
  end
  local halfW = percentile(U.copy(ax), 0.97) or 0.9
  local ymin = percentile(U.copy(ys), 0.01) or -2.3
  local ymax = percentile(U.copy(ys), 0.99) or 2.3
  local zmin = percentile(U.copy(zs), 0.01) or 0.2
  local zmaxAll = percentile(U.copy(zs), 0.995) or 1.4
  res.bbox = {xmin = -halfW, xmax = halfW, ymin = ymin, ymax = ymax, zmin = zmin, zmax = zmaxAll}
  res.halfW = halfW
  res.length = ymax - ymin

  -- tavan: orta seritteki en yuksek dugumler
  local central = {}
  for _, n in ipairs(body) do
    if abs(n.x) < halfW * 0.55 then central[#central + 1] = n end
  end
  if #central < 3 then central = body end
  local czs = {}
  for _, n in ipairs(central) do czs[#czs + 1] = n.z end
  local zTop = percentile(czs, 0.99) or zmaxAll
  local roofNodes = {}
  for _, n in ipairs(body) do
    if n.z > zTop - 0.12 and abs(n.x) < halfW * 0.9 then roofNodes[#roofNodes + 1] = n end
  end
  local ry0, ry1, rhw = math.huge, -math.huge, 0
  for _, n in ipairs(roofNodes) do
    ry0 = min(ry0, n.y); ry1 = max(ry1, n.y); rhw = max(rhw, abs(n.x))
  end
  if ry0 > ry1 then ry0, ry1 = -0.5, 0.5 end
  if ry1 - ry0 < 0.4 then
    local c = (ry0 + ry1) / 2
    ry0, ry1 = c - 0.2, c + 0.2
  end
  res.roof = {x = 0, y0 = ry0, y1 = ry1, z = zTop, halfW = max(rhw, 0.3),
              y = ry0 + 0.32 * (ry1 - ry0), yc = (ry0 + ry1) / 2, len = ry1 - ry0}

  -- on: izgara ve tampon bantlari
  local function band(zlo, zhi, front)
    local sel = {}
    for _, n in ipairs(body) do
      local inY = front and (n.y < ymin + 0.35) or (n.y > ymax - 0.35)
      if inY and n.z >= zlo and n.z <= zhi and abs(n.x) < halfW * 0.7 then sel[#sel + 1] = n end
    end
    if #sel == 0 then return nil end
    local yy, zz = {}, {}
    for _, n in ipairs(sel) do yy[#yy + 1] = n.y; zz[#zz + 1] = n.z end
    local yEdge = front and percentile(yy, 0.05) or percentile(yy, 0.95)
    return {y = yEdge, z = median(zz), n = #sel}
  end
  local hz = zmin + 0.62 * (zTop - zmin) -- kabaca kaput / bagaj yuksekligi
  local grille = band(zmin + 0.30 * (zTop - zmin), hz, true)
  local bumperF = band(zmin, zmin + 0.30 * (zTop - zmin), true)
  local trunk = band(zmin + 0.40 * (zTop - zmin), hz + 0.08, false)
  local bumperR = band(zmin, zmin + 0.30 * (zTop - zmin), false)
  res.grille = {x0 = 0.14, y = (grille and grille.y or ymin) - 0.012, z = grille and grille.z or (zmin + 0.45)}
  res.bumperF = {x0 = min(0.45, halfW * 0.55), y = (bumperF and bumperF.y or ymin) - 0.012, z = bumperF and bumperF.z or (zmin + 0.2)}
  res.trunk = {x0 = min(0.3, halfW * 0.4), y = (trunk and trunk.y or ymax) + 0.012, z = trunk and trunk.z or (zmin + 0.55)}
  res.bumperR = {x0 = min(0.45, halfW * 0.55), y = (bumperR and bumperR.y or ymax) + 0.012, z = bumperR and bumperR.z or (zmin + 0.2)}

  -- on cam ici (gunesluk) ve arka cam ici
  res.windshield = {x0 = max(0.2, min(0.36, res.roof.halfW * 0.48)), y = ry0 + 0.10, z = zTop - 0.10}
  res.rearglass = {x0 = max(0.2, min(0.32, res.roof.halfW * 0.42)), y = ry1 - 0.10, z = zTop - 0.13}

  -- aynalar
  local mL, mR = {}, {}
  for _, n in ipairs(all) do
    if hasGroupWord(n, 'mirror') then
      if n.x > 0 then mL[#mL + 1] = n else mR[#mR + 1] = n end
    end
  end
  local function centroid(list)
    local sx, sy, sz = 0, 0, 0
    for _, n in ipairs(list) do sx = sx + n.x; sy = sy + n.y; sz = sz + n.z end
    return {x = sx / #list, y = sy / #list, z = sz / #list}
  end
  if #mL > 0 or #mR > 0 then
    local c = centroid(#mL > 0 and mL or mR)
    res.mirrors = {x0 = abs(c.x), y = c.y - 0.02, z = c.z}
  else
    res.mirrors = {x0 = halfW + 0.08, y = ry0 - 0.25, z = zTop - 0.42}
  end
  -- arka yan camlar
  res.sideRear = {x0 = max(0.4, res.roof.halfW + 0.06), y = (res.roof.yc + ry1) / 2, z = zTop - 0.24}

  -- modele ozel kesin degerler
  local ov = model and G.MODEL_OVERRIDES[model]
  if ov then
    for k, v in pairs(ov) do
      res[k] = res[k] or {}
      for kk, vv in pairs(v) do res[k][kk] = vv end
    end
    res.override = model
  end
  return res
end

-- arayuz icin ustten gorunum: indirgenmis nokta bulutu (x, y) ve yan gorunum (y, z)
function G.preview(nodes, maxPoints)
  maxPoints = maxPoints or 420
  local list = {}
  for _, n in pairs(nodes) do
    if type(n) == 'table' and n.x and not isExcluded(n) then list[#list + 1] = n end
  end
  local step = max(1, math.ceil(#list / maxPoints))
  local top, side = {}, {}
  for i = 1, #list, step do
    local n = list[i]
    top[#top + 1] = {U.r(n.x, 3), U.r(n.y, 3)}
    side[#side + 1] = {U.r(n.y, 3), U.r(n.z, 3)}
  end
  return {top = top, side = side}
end

return G
