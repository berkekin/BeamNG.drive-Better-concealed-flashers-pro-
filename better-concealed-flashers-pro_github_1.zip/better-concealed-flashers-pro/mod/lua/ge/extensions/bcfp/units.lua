-- Better Concealed Flashers PRO 3 - cakar baslik (modul) tipleri ve fotometri
-- Olculer metre; w = genislik (x), h = yukseklik (z), d = derinlik (y). Lens -y yonune bakar, orijin merkezde.
-- "std" olculeri oyunun kendi cakar modulu (generic_flasher_led: 65.2 x 40.6 x 17 mm) ile aynidir; boylece fabrika
-- konumlarina bire bir oturur. "slim / wide / mini" de oyunun kullandigi olceklerle (z 0.5; 1.3,1.3,1.1; 0.7,0.7,0.5) eslesir.
local Un = {}

Un.MAX = 24                 -- en fazla dizi (her biri kendi lens materyali / elektrik kanaliyla)

-- cd: baslik basina tepe isik siddeti (kandela). Olcek, oyunun kendi isik parcalariyla aynidir
-- ("1 lightIntensityCd = 1 cd"; oyunun 4 LED'li 16 W modulu 4210 cd, 3 LED'li 9 W modulu 1350 cd).
Un.TYPES = {
  {id = 'std',   tr = 'Standart modül (8 LED)',    w = 0.0652, h = 0.0406, d = 0.0170, cols = 4, rows = 2, cd = 1400, ang = 100},
  {id = 'slim',  tr = 'İnce modül (4 LED)',        w = 0.0652, h = 0.0203, d = 0.0170, cols = 4, rows = 1, cd = 1050, ang = 100},
  {id = 'wide',  tr = 'Geniş modül (12 LED)',      w = 0.0848, h = 0.0447, d = 0.0221, cols = 6, rows = 2, cd = 2100, ang = 110},
  {id = 'mini',  tr = 'Mini modül (3 LED)',        w = 0.0456, h = 0.0203, d = 0.0119, cols = 3, rows = 1, cd = 600,  ang = 110},
  {id = 'lin',   tr = 'Lineer çubuk (6 LED)',      w = 0.1100, h = 0.0240, d = 0.0140, cols = 6, rows = 1, cd = 1600, ang = 100},
  {id = 'round', tr = 'Hideaway (yuvarlak)',       w = 0.0340, h = 0.0340, d = 0.0180, cols = 2, rows = 2, cd = 900,  ang = 120, round = true},
}
Un.byId = {}
for i, t in ipairs(Un.TYPES) do t.idx = i; Un.byId[t.id] = t end
Un.byId.led = Un.byId.std     -- v2 adi

function Un.get(id) return Un.byId[id] or Un.byId.std end

-- oge (dizi) -> olcekli olculer
function Un.dims(o)
  local t = Un.get(o.head)
  local k = (tonumber(o.size) or 100) / 100
  return {w = t.w * k, h = t.h * k, d = t.d * k}
end

function Un.meshA(typeId, num, side) return 'bcfp_hd_' .. typeId .. '_' .. num .. '_' .. side end
function Un.meshB(typeId, num, side) return 'bcfp_hb_' .. typeId .. '_' .. num .. '_' .. side end
function Un.matA(num, side) return 'bcfp_k_u' .. num .. '_' .. side end
function Un.matB(num, side) return 'bcfp_k_u' .. num .. '_' .. side .. '2' end

-----------------------------------------------------------------------------------------------
-- fotometri
-----------------------------------------------------------------------------------------------
local pi, cos, rad, sqrt, min, max = math.pi, math.cos, math.rad, math.sqrt, math.min, math.max

-- koni kati acisi (steradyan), tam tepe acisi derece
function Un.solidAngle(outerDeg)
  local a = rad(min(max(outerDeg or 45, 1), 179))
  return 2 * pi * (1 - cos(a / 2))
end

-- Parlaklik hazir ayarlari: baslik basina kandela carpani. Degerler baslik tipinin temel siddetine uygulanir.
--  1 "Fabrika"  : oyunun kendi gizli cakarlariyla ayni seviye (4 baslik ~ 4200 cd)
--  2 "Standart" : tipin kendi degeri
--  3 "Yuksek"   : gunduz uzaktan gorunurluk (SAE J595 Sinif 1 duzeyi)
--  4 "Cok yuksek"
Un.BRIGHT = {
  {id = 1, tr = 'Fabrika (oyun)', k = 0.75},
  {id = 2, tr = 'Standart', k = 1.0},
  {id = 3, tr = 'Yüksek', k = 2.0},
  {id = 4, tr = 'Çok yüksek', k = 4.0},
}

-- dizi ogesinin baslik basina kandelasi
function Un.headCd(o)
  local l = o.light or {}
  local t = Un.get(o.head)
  local k = ((tonumber(o.size) or 100) / 100) ^ 2
  if l.unit == 2 then return (l.lm or 800) / Un.solidAngle(l.ang or t.ang) end
  if l.unit == 3 then return (l.lux or 30) * (l.luxd or 10) ^ 2 end
  if (l.cd or -1) > 0 then return l.cd end
  local b = Un.BRIGHT[o.bright or 2] or Un.BRIGHT[2]
  return t.cd * b.k * k
end

-- gorunur menzil (m): aydinlatma esigi (luks) altina dustugu mesafe
function Un.autoRange(cd, lux)
  return min(max(sqrt(cd / (lux or 4.5)), 6), 120)
end

return Un
