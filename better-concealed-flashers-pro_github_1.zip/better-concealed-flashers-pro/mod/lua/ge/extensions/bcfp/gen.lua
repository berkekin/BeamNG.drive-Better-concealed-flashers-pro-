-- Better Concealed Flashers PRO 3 - kendi parcalarimizin (gizli LED dizileri, multicolor bar, ana sistem)
-- bellekte uretilmesi. Uretilen parcalar oyunun jbeam yukleyicisine normal parca gibi verilir; boylece her
-- arac (orijinal ya da modlu) icin ayri jbeam dosyasi gerekmez.
local Gn = {}
local U, P, C, Un

local min, max, floor, abs, sqrt, cos, sin, rad, pi, ceil, log, deg, atan2 =
  math.min, math.max, math.floor, math.abs, math.sqrt, math.cos, math.sin, math.rad, math.pi, math.ceil, math.log, math.deg, math.atan2

function Gn.init(mods) U, P, C, Un = mods.U, mods.P, mods.C, mods.Un end

Gn.COLOR_IDS = {'red', 'blue', 'white', 'amber', 'green', 'purple'}   -- 1..6
Gn.ML_CODES = {'r', 'b', 'w', 'a'}
Gn.ML_CODE_COLOR = {r = 'red', b = 'blue', w = 'white', a = 'amber'}
Gn.GLOW_LEVELS = 7         -- bcfp_on_<renk>_<1..7>, 4 = 200000 nit (oyunun lightbar seviyesi)
Gn.FLARES = {'vehicleBrakeLightFlare', 'vehicleHeadLightFlare', 'BNG_LightFlare_Diffraction', 'BNG_SpokeFlare_1', 'BNG_Sunflare_2', ''}
Gn.COOKIES = {'/art/special/BNG_light_cookie_lightbar.color.png', '/art/special/BNG_light_cookie_generic_led.color.png', ''}

-- parlama yuzdesi -> (merdiven seviyesi, emissive olcek on_max)
function Gn.glowLevel(pct)
  local f = max(0.02, (tonumber(pct) or 100) / 100)
  local L = ceil(log(f) / log(2) - 1e-9) + 4
  L = max(1, min(Gn.GLOW_LEVELS, L))
  local lf = 2 ^ (L - 4)
  local onMax = lf / f
  if onMax < 1 then onMax = 1 end
  return L, onMax
end

local function colorOf(idx, profile)
  local id = Gn.COLOR_IDS[idx] or 'white'
  local c = P.byId[id]
  local lin = c.lin
  if profile == 2 and P.vivid[id] then lin = P.vivid[id] end
  return id, lin, c.Y
end

local function lightColor255(lin)
  local c = P.to255(lin[1], lin[2], lin[3], 255)
  return {r = c.r, g = c.g, b = c.b, a = 255}
end

-- kandela hesabi (isik ayarlarindan)
local function solidAngle(outerDeg)
  local a = rad(min(max(outerDeg or 45, 1), 179))
  return 2 * pi * (1 - cos(a / 2))
end
Gn.solidAngle = solidAngle

function Gn.lightCd(l)
  if l.unit == 2 then return l.lm / solidAngle(l.ang) end
  if l.unit == 3 then return l.lux * l.luxd * l.luxd end
  return l.cd
end

local function rangeFor(l, cd)
  if l.rmode == 1 then return l.rng end
  return U.clamp(sqrt(cd / 2), 2, 400)
end

local function flareFor(M, base)
  local name = Gn.FLARES[M.flareType or 1] or 'vehicleBrakeLightFlare'
  local scale = (base or 0.12) * (M.flare or 60) / 100
  if name == '' or scale <= 0 then return '', 0 end
  return name, scale
end

local ZERO = {x = 0, y = 0, z = 0}
local PROP_HEADER = {'func', 'mesh', 'idRef:', 'idX:', 'idY:', 'baseRotation', 'rotation', 'translation', 'min', 'max', 'offset', 'multiplier'}

-----------------------------------------------------------------------------------------------
-- Gizli LED dizisi
-----------------------------------------------------------------------------------------------
-- o: dizi ogesi; lay: yerlesim (place.layout): {L = {baslik...}, R = {...}}; bind: baglama (env.bind):
-- {L = {groups, ref = {n1, n2, n3}, dg}, R = {...}}; M: ana ayarlar; num: 1..24 (lens / elektrik numarasi)
-- Oyunun kendi gizli cakarlari gibi: gorseller aracin mevcut govde dugum gruplarina baglanir (ek dugum / kiris yok),
-- isiklar en yakin uc govde dugumune gore konumlanir, cam kirilinca (kirilma grubu) cakar da soner.
function Gn.arrayPart(o, lay, bind, M, num)
  local zid = 'u' .. num
  local ut = Un.get(o.head)
  local k = o.size / 100
  local scale = {x = U.r(k, 4), y = U.r(k, 4), z = U.r(k, 4)}
  local dims = Un.dims(o)
  local flex = {{'mesh', '[group]:', 'nonFlexMaterials'}}
  local props = {PROP_HEADER}
  local glow = {}
  local own = {}
  local nodes, beams
  local l = o.light
  local cdHead = Un.headCd(o)
  local L, onMax = Gn.glowLevel(M.glow)
  local flareName, flareScale = flareFor(M, 0.10)
  local cookie = Gn.COOKIES[M.cookie or 1] or ''
  local ut_ang = l.ang
  local inner = min(l.inner, ut_ang)
  local profile = M.colorProfile
  local hasB = (o.colB or 0) > 0
  local xs = {}

  local function linOf(T)
    if profile == 2 and T.tone == 1 and P.vivid[T.color] then return P.vivid[T.color] end
    return T.lin
  end

  for _, sd in ipairs({{'L', lay.L, 1}, {'R', lay.R, -1}}) do
    local S, heads, sgn = sd[1], sd[2], sd[3]
    if heads and #heads > 0 then
      local n = #heads
      local cx, cy, cz, fx, fy, fz = 0, 0, 0, 0, 0, 0
      for _, h in ipairs(heads) do
        cx, cy, cz = cx + h.x, cy + h.y, cz + h.z
        local a, t = rad(h.yaw), rad(h.tilt or 0)
        fx, fy, fz = fx + sin(a) * cos(t), fy - cos(a) * cos(t), fz + sin(t)
      end
      cx, cy, cz = cx / n, cy / n, cz / n
      xs[S] = cx
      local b = bind and bind[S]
      local groups, ref, dg
      if b and b.groups and #b.groups > 0 then
        groups, ref, dg = b.groups, b.ref, b.dg
      else
        -- govde dugumu bulunamadi: kendi (carpismasiz, hafif) montaj dugumleri; govdeye kirisleri Phase1 ekler
        nodes = nodes or {{'id', 'posX', 'posY', 'posZ'}, {selfCollision = false}, {collision = false}, {nodeWeight = 0.45},
                          {frictionCoef = 0.5}, {nodeMaterial = '|NM_PLASTIC'}}
        beams = beams or {{'id1:', 'id2:'}, {beamPrecompression = 1, beamType = '|NORMAL', beamLongBound = 1.0, beamShortBound = 1.0},
                          {beamSpring = 260000, beamDamp = 18}, {beamDeform = 60000, beamStrength = 'FLT_MAX'}}
        local group = 'bcfp_g_' .. zid .. '_' .. S
        local nn = {}
        local off = {{0, 0, 0}, {0.07 * sgn, 0, 0}, {0, 0.07, 0}, {0, 0, 0.06}}
        nodes[#nodes + 1] = {group = group}
        for i = 1, 4 do
          local name = 'bcfp_' .. zid .. '_' .. S .. (i - 1)
          nn[i] = name
          own[#own + 1] = name
          nodes[#nodes + 1] = {name, U.r(cx + off[i][1], 4), U.r(cy + off[i][2], 4), U.r(cz + off[i][3], 4)}
        end
        nodes[#nodes + 1] = {group = ''}
        for a = 1, 4 do
          for c = a + 1, 4 do beams[#beams + 1] = {nn[a], nn[c]} end
        end
        groups, ref = {group}, {nn[1], nn[2], nn[3]}
      end

      local matA, matB = Un.matA(num, S), Un.matB(num, S)
      local meshA, meshB = Un.meshA(ut.id, num, S), Un.meshB(ut.id, num, S)
      local function rowOpts(h)
        return {pos = {x = U.r(h.x, 4), y = U.r(h.y, 4), z = U.r(h.z, 4)},
                rot = {x = U.r(-(h.tilt or 0), 3), y = U.r(h.roll or 0, 3), z = U.r(h.yaw, 3)}, scale = scale}
      end
      if dg then flex[#flex + 1] = {deformGroup = dg, deformMaterialBase = matA, deformMaterialDamaged = 'bcfp_led_broken'} end
      for _, h in ipairs(heads) do flex[#flex + 1] = {meshA, groups, {}, rowOpts(h)} end
      if hasB then
        if dg then flex[#flex + 1] = {deformGroup = dg, deformMaterialBase = matB, deformMaterialDamaged = 'bcfp_invis'} end
        for _, h in ipairs(heads) do flex[#flex + 1] = {meshB, groups, {}, rowOpts(h)} end
      end
      if dg then flex[#flex + 1] = {deformGroup = '', deformMaterialBase = '', deformMaterialDamaged = ''} end

      -- lens parlamasi
      local TA = P.tone((S == 'L') and o.colL or o.colR, (S == 'L') and o.toneL or o.toneR)
      local funcA = 'bcfp_' .. zid .. '_' .. S
      local offMat = (M.lens == 1) and ('bcfp_led_off_' .. TA.color) or 'bcfp_led_off_clear'
      glow[matA] = {simpleFunction = funcA, off = offMat, on = 'bcfp_on_' .. TA.key .. '_' .. L,
        materialEmissiveScaling = {on_max = U.r(onMax, 4)}}
      local TB, funcB
      if hasB then
        TB = P.tone(o.colB, o.toneB)
        funcB = funcA .. '2'
        glow[matB] = {simpleFunction = funcB, off = 'bcfp_invis', on = 'bcfp_on_' .. TB.key .. '_' .. L,
          materialEmissiveScaling = {on_max = U.r(onMax, 4)}}
      end

      -- gercek isik kaynaklari
      if M.props == 1 and ref then
        local function addLight(func, T, px, py, pz, yaw, tilt, cdv, tag)
          local lin = linOf(T)
          local Y = max(P.luminance(lin[1], lin[2], lin[3]), 0.05)
          local opts = {
            lightScaling = {brightnessMinInput = 0, brightnessMaxInput = 1, flareScaleMinInput = 0.25, flareScaleMaxInput = 1,
                            lightColorOffsetRed = 0, lightColorOffsetGreen = 0, lightColorOffsetBlue = 0},
            lightInnerAngle = inner, lightOuterAngle = ut_ang,
            lightRange = U.r((l.rmode == 1) and l.rng or Un.autoRange(cdv), 2), lightBrightness = U.r(cdv / 5000 / Y, 5),
            lightCastShadows = (M.shadows == 1), flareName = flareName, flareScale = U.r(flareScale, 4),
            cookieName = cookie, lightColor = lightColor255(lin),
            baseTranslationGlobal = {x = U.r(px, 4), y = U.r(py, 4), z = U.r(pz, 4)},
            baseRotationGlobal = {x = U.r(tilt, 3), y = 0, z = U.r(180 - yaw, 3)},
            bcfpLight = tag, bcfpCd = U.r(cdv, 1), bcfpN = U.r(cdv / max(cdHead, 1e-6), 3),
          }
          if dg then opts.deformGroup = dg end
          props[#props + 1] = {func, 'SPOTLIGHT', ref[1], ref[2], ref[3], ZERO, ZERO, ZERO, 0, 0, 0, 1, opts}
        end
        local lead = dims.d / 2 + 0.004
        local function emit(func, T, tag)
          if l.lpl then
            for _, h in ipairs(heads) do
              local a, t = rad(h.yaw), rad(h.tilt or 0)
              addLight(func, T, h.x + sin(a) * cos(t) * lead, h.y - cos(a) * cos(t) * lead, h.z + sin(t) * lead, h.yaw, h.tilt or 0, cdHead, tag)
            end
          else
            local fl = sqrt(fx * fx + fy * fy + fz * fz)
            local ux, uy, uz = 0, -1, 0
            if fl > 1e-6 then ux, uy, uz = fx / fl, fy / fl, fz / fl end
            local yaw = deg(atan2(ux, -uy))
            local tilt = deg(math.asin(max(-1, min(1, uz))))
            addLight(func, T, cx + ux * lead, cy + uy * lead, cz + uz * lead, yaw, tilt, cdHead * n, tag)
          end
        end
        emit(funcA, TA, zid .. '_' .. S)
        if hasB then emit(funcB, TB, zid .. '_' .. S .. '2') end
      end
    end
  end

  local face = 'F'
  do
    local h = (lay.L and lay.L[1]) or (lay.R and lay.R[1])
    if h then
      local a = ((h.yaw + 180) % 360) - 180
      if abs(a) > 120 then face = 'R' elseif abs(a) > 50 then face = 'S' end
    end
  end
  local zones = {{'id', 'eL', 'eR', 'eL2', 'eR2', 'kind', 'grp', 'pat', 'phase', 'side', 'lvl', 'bfn', 'face', 'x', 'adv', 'zone'},
                 {zid, lay.L and ('bcfp_' .. zid .. '_L') or '', lay.R and ('bcfp_' .. zid .. '_R') or '',
                  (hasB and lay.L) and ('bcfp_' .. zid .. '_L2') or '', (hasB and lay.R) and ('bcfp_' .. zid .. '_R2') or '',
                  o.kind2, o.grp, o.pat, U.r(o.phase / 100, 3), o.side, U.r(o.lvl / 100, 3), o.bfn, face,
                  U.r(abs(xs.L or xs.R or 0), 3), o.adv, o.anchor}}
  local part = {
    partName = 'bcfp_array_' .. zid,
    information = {authors = 'Better Concealed Flashers PRO', name = 'Concealed LED array ' .. num, value = 0},
    slotType = 'bcfp_injected',
    flexbodies = flex, glowMap = glow, bcfpZones = zones,
  }
  if nodes then part.nodes, part.beams = nodes, beams end
  if #props > 1 then part.props = props end
  return part, own
end

-----------------------------------------------------------------------------------------------
-- Multicolor hoparlorlu LED bar (ozgun tasarim; 116 / 139 / 161 cm, 36 cm derinlik)
-----------------------------------------------------------------------------------------------
local ML_VARIANTS = {[116] = 3, [139] = 4, [161] = 5}
local ML_SPK, ML_END, ML_FACE = 0.135, 0.016, 0.158

function Gn.mlLayout(V)
  local n = ML_VARIANTS[V] or 4
  local L = V / 100
  local H = L / 2
  local x_in = ML_SPK + 0.012
  local x_out = H - ML_END - 0.050
  local pitch = (x_out - x_in) / n
  local mods = {}
  for _, sd in ipairs({{'L', 1}, {'R', -1}}) do
    for _, fc in ipairs({{'F', -ML_FACE}, {'B', ML_FACE}}) do
      for k = 1, n do
        mods[#mods + 1] = {id = sd[1] .. '_' .. fc[1] .. k, side = sd[1], face = fc[1], k = k, n = n}
      end
    end
    mods[#mods + 1] = {id = sd[1] .. '_E1', side = sd[1], face = 'E', k = 1, n = 1}
  end
  return mods, n, H
end

-- first: bu ornek bar kontrolcuyu tasir mi (ayni elektrikleri paylasan diger barlar tasimaz)
function Gn.mlbarPart(o, M, idx, first)
  local V = o.len
  local mods, n, H = Gn.mlLayout(V)
  local sfx = '_bcfpm' .. idx
  local group = 'bcfp_g_m' .. idx
  local xn = H - 0.05
  local nodes = {{'id', 'posX', 'posY', 'posZ'},
                 {group = {group, 'lightbar_bcfp'}}, {selfCollision = true}, {collision = true},
                 {nodeWeight = 1.1}, {frictionCoef = 0.7}, {nodeMaterial = '|NM_METAL'}}
  local own = {}
  for _, s in ipairs({{'', 0.0}, {'l', xn}, {'r', -xn}}) do
    for _, p in ipairs({{1, -0.15, 0.065}, {2, -0.15, 0.012}, {3, 0.15, 0.065}, {4, 0.15, 0.012}}) do
      local name = 'lightbar_' .. p[1] .. s[1] .. sfx
      own[#own + 1] = name
      nodes[#nodes + 1] = {name, U.r(s[2], 4), p[2], p[3]}
    end
  end
  nodes[#nodes + 1] = {group = ''}
  local function nm(i, s) return 'lightbar_' .. i .. s .. sfx end
  local beams = {{'id1:', 'id2:'},
                 {beamPrecompression = 1, beamType = '|NORMAL', beamLongBound = 1.0, beamShortBound = 1.0},
                 {beamSpring = 701000, beamDamp = 60}, {beamDeform = 6000, beamStrength = 'FLT_MAX'},
                 {deformationTriggerRatio = 0.02}, {deformGroup = 'bcfp_mlbar_break' .. sfx}}
  for _, s in ipairs({'', 'l', 'r'}) do
    beams[#beams + 1] = {nm(1, s), nm(2, s)}; beams[#beams + 1] = {nm(2, s), nm(3, s)}
    beams[#beams + 1] = {nm(3, s), nm(4, s)}; beams[#beams + 1] = {nm(4, s), nm(1, s)}
    beams[#beams + 1] = {nm(1, s), nm(3, s)}; beams[#beams + 1] = {nm(2, s), nm(4, s)}
  end
  for _, s in ipairs({'l', 'r'}) do
    for i = 1, 4 do beams[#beams + 1] = {nm(i, s), nm(i, '')} end
    beams[#beams + 1] = {nm(4, s), nm(3, '')}; beams[#beams + 1] = {nm(3, s), nm(4, '')}
    beams[#beams + 1] = {nm(3, ''), nm(1, s)}; beams[#beams + 1] = {nm(3, s), nm(1, '')}
    beams[#beams + 1] = {nm(1, ''), nm(2, s)}; beams[#beams + 1] = {nm(2, ''), nm(1, s)}
    beams[#beams + 1] = {nm(2, s), nm(4, '')}; beams[#beams + 1] = {nm(4, s), nm(2, '')}
  end
  beams[#beams + 1] = {deformGroup = '', deformationTriggerRatio = ''}

  local flex = {{'mesh', '[group]:', 'nonFlexMaterials'},
    {'bcfp_ml' .. V .. '_body', {group}, {}},
    {'bcfp_ml' .. V .. '_refl', {group}, {}},
    {deformGroup = 'bcfp_mlbar_break' .. sfx, deformMaterialBase = 'bcfp_ml_dome', deformMaterialDamaged = 'bcfp_ml_black'},
    {'bcfp_ml' .. V .. '_dome', {group}, {}},
    {deformGroup = ''},
    {'bcfp_ml' .. V .. '_lights', {group}, {}}}

  local L, onMax = Gn.glowLevel(M.glow)
  local glow = {}
  local rows = {{'id', 'side', 'face', 'k', 'n'}}
  for _, m in ipairs(mods) do
    rows[#rows + 1] = {m.id, m.side, m.face, m.k, m.n}
    for _, code in ipairs(Gn.ML_CODES) do
      glow['bcfp_mlk_' .. m.id .. '_' .. code] = {simpleFunction = 'bcfp_ml_' .. m.id .. '_' .. code, off = 'bcfp_invis',
        on = 'bcfp_mlon_' .. code .. '_' .. L, materialEmissiveScaling = {on_max = U.r(onMax, 4)}}
    end
  end
  for _, S in ipairs({'L', 'R'}) do
    for _, wk in ipairs({'tkd', 'aly', 'fld'}) do
      rows[#rows + 1] = {S .. '_' .. wk, S, wk, 0, 0}
      glow['bcfp_mlk_' .. S .. '_' .. wk] = {simpleFunction = 'bcfp_ml_' .. wk .. '_' .. S, off = 'bcfp_ml_white_off',
        on = 'bcfp_mlon_w_' .. L, materialEmissiveScaling = {on_max = U.r(onMax, 4)}}
    end
  end

  local props = {PROP_HEADER}
  if M.props == 1 then
    local l = o.light
    local cdc = max(1, Gn.lightCd(l))
    local rng = rangeFor(l, cdc)
    local flareName, flareScale = flareFor(M, 0.10)
    for _, sd in ipairs({{'L', 1}, {'R', -1}}) do
      local S, sgn = sd[1], sd[2]
      local ref = {'lightbar_2' .. sfx, 'lightbar_2' .. S:lower() .. sfx, 'lightbar_4' .. sfx}
      for _, fp in ipairs({{'F', sgn * H / 2, -0.175, 0.053, 180}, {'B', sgn * H / 2, 0.175, 0.053, 0},
                           {'E', sgn * (H + 0.004), 0.0, 0.053, 90 * sgn}}) do
        props[#props + 1] = {'bcfp_mlp_' .. S .. '_' .. fp[1], 'SPOTLIGHT', ref[1], ref[2], ref[3], ZERO, ZERO, ZERO, 0, 0, 0, 1, {
          lightInnerAngle = min(l.inner, l.ang), lightOuterAngle = l.ang, lightRange = U.r(rng, 2),
          lightBrightness = U.r(cdc / 5000, 5), lightCastShadows = (M.shadows == 1),
          flareName = flareName, flareScale = U.r(flareScale, 4),
          cookieName = '/art/special/BNG_light_cookie_lightbar.color.png',
          lightColor = {r = 255, g = 255, b = 255, a = 255},
          baseTranslationGlobal = {x = U.r(fp[2], 4), y = fp[3], z = fp[4]},
          baseRotationGlobal = {x = 0, y = 0, z = fp[5]}, deformGroup = 'bcfp_mlbar_break' .. sfx,
          bcfpLight = 'ml_' .. S .. '_' .. fp[1], bcfpPhotometric = true}}
      end
      local wlin = P.whites.w6000.lin
      for _, wp in ipairs({{'tkd', sgn * 0.26, -0.175, 0.027, 180}, {'aly', sgn * (H + 0.004), 0.0, 0.027, 90 * sgn},
                           {'fld', sgn * 0.26, 0.175, 0.027, 0}}) do
        props[#props + 1] = {'bcfp_ml_' .. wp[1] .. '_' .. S, 'SPOTLIGHT', ref[1], ref[2], ref[3], ZERO, ZERO, ZERO, 0, 0, 0, 1, {
          lightScaling = {brightnessMinInput = 0, brightnessMaxInput = 1, flareScaleMinInput = 0.25, flareScaleMaxInput = 1,
                          lightColorOffsetRed = 0, lightColorOffsetGreen = 0, lightColorOffsetBlue = 0},
          lightInnerAngle = 15, lightOuterAngle = o.wang, lightRange = o.wrng,
          lightBrightness = U.r(o.wcd / 5000 / P.whites.w6000.Y, 5), lightCastShadows = (M.shadows == 1),
          flareName = 'vehicleHeadLightFlare', flareScale = 0.15,
          cookieName = '/art/special/BNG_light_cookie_generic_led.color.png',
          lightColor = lightColor255(wlin),
          baseTranslationGlobal = {x = U.r(wp[2], 4), y = wp[3], z = wp[4]},
          baseRotationGlobal = {x = 0, y = 0, z = wp[5]}, deformGroup = 'bcfp_mlbar_break' .. sfx,
          bcfpLight = 'mlw_' .. wp[1] .. '_' .. S}}
      end
    end
  end

  local part = {
    partName = 'bcfp_mlbar_' .. V .. sfx,
    information = {authors = 'Better Concealed Flashers PRO', name = 'Multicolor speaker LED bar ' .. V .. ' cm', value = 0},
    slotType = 'bcfp_injected',
    nodes = nodes, beams = beams, flexbodies = flex, glowMap = glow, bcfpML = rows,
  }
  if #props > 1 then part.props = props end
  if first then
    local dis = {}
    for _, code in ipairs(Gn.ML_CODES) do if o.disable and o.disable[code] then dis[#dis + 1] = code end end
    part.controller = {{'fileName'}, {'bcfp_flasher', {
      name = 'bcfp_mlbar_m', role = 'mlbar',
      colA = o.colA, colB = o.colB, colC = o.colC, arrowCol = o.arrow,
      mlLevel = o.lvl / 100, mlWhiteLevel = o.wlvl / 100,
      nightLevel = M.night / 100, dayLevel = M.day / 100, cruiseLevel = M.cruise / 100,
      speed = M.speed / 100, defaultMode = M.mode, autoNight = M.autoNight,
      colorProfile = M.colorProfile, disabledColors = table.concat(dis, ','),
      photometric = 1, lang = U.lang()}}}
  end
  return part, own
end

-----------------------------------------------------------------------------------------------
-- Ana sistem (mod yonetimi, gizli bolgeler, far wig-wag)
-----------------------------------------------------------------------------------------------
function Gn.masterPart(M, zoneRows)
  local zones = {{'id', 'eL', 'eR', 'eL2', 'eR2', 'kind', 'grp', 'pat', 'phase', 'side', 'lvl', 'bfn', 'face', 'x', 'adv', 'zone'}}
  for _, r in ipairs(zoneRows or {}) do zones[#zones + 1] = r end
  local part = {
    partName = 'bcfp_master',
    information = {authors = 'Better Concealed Flashers PRO', name = 'Concealed Flashers PRO - master', value = 0},
    slotType = 'bcfp_injected',
    controller = {{'fileName'}, {'bcfp_flasher', {
      name = 'bcfp_flasher', role = 'master',
      speed = M.speed / 100, dayLevel = M.day / 100, nightLevel = M.night / 100,
      nightDefault = M.nightDefault, cruiseLevel = M.cruise / 100, defaultMode = M.mode,
      wigwag = M.wigwag, autoNight = M.autoNight, lang = U.lang()}}},
  }
  return part
end

return Gn
