-- Better Concealed Flashers PRO 3 - COLLADA (.dae) okuyucu
-- Aracin gercek govde modellerinden (cam, tampon, izgara, kaput ...) ucgenleri okur. Yerlesim motoru bu
-- ucgenler uzerinde isin izleyerek cakarlari yuzeye tam oturtur.
--  * mesh adi = <library_visual_scenes> icindeki <node name="...">; geometri instance_geometry ile baglanir
--  * buyuk dosyalar icin duz metin taramasi (string.find) ve bayt duzeyinde sayi cozumleme kullanilir
local D = {}

local byte, find, sub, match = string.byte, string.find, string.sub, string.match
local floor = math.floor

-----------------------------------------------------------------------------------------------
-- sayi cozumleyiciler (s[a..b] araligi)
-----------------------------------------------------------------------------------------------
local function parseFloats(s, a, b, out, n)
  local i = a
  n = n or 0
  while i <= b do
    local c = byte(s, i)
    while c == 32 or c == 10 or c == 13 or c == 9 do
      i = i + 1
      if i > b then return n end
      c = byte(s, i)
    end
    local neg = false
    if c == 45 then neg = true; i = i + 1; c = byte(s, i)
    elseif c == 43 then i = i + 1; c = byte(s, i) end
    local v, any = 0, false
    while c and c >= 48 and c <= 57 do
      v = v * 10 + (c - 48); i = i + 1; c = byte(s, i); any = true
    end
    if c == 46 then
      i = i + 1; c = byte(s, i)
      local f = 0.1
      while c and c >= 48 and c <= 57 do
        v = v + (c - 48) * f; f = f * 0.1; i = i + 1; c = byte(s, i); any = true
      end
    end
    if any and (c == 101 or c == 69) then
      i = i + 1; c = byte(s, i)
      local eneg = false
      if c == 45 then eneg = true; i = i + 1; c = byte(s, i)
      elseif c == 43 then i = i + 1; c = byte(s, i) end
      local e = 0
      while c and c >= 48 and c <= 57 do e = e * 10 + (c - 48); i = i + 1; c = byte(s, i) end
      v = v * 10 ^ (eneg and -e or e)
    end
    if not any then
      -- taninmayan belirtec (nan, inf ...): bosluga kadar atla
      while c and not (c == 32 or c == 10 or c == 13 or c == 9 or c == 60) do i = i + 1; c = byte(s, i) end
      v = 0
    end
    n = n + 1
    out[n] = neg and -v or v
  end
  return n
end
D.parseFloats = parseFloats

-- tamsayilar: her "stride" degerden "off" siradakini al
local function parseIndices(s, a, b, stride, off, out, n)
  local i = a
  n = n or 0
  local k = 0
  while i <= b do
    local c = byte(s, i)
    while c == 32 or c == 10 or c == 13 or c == 9 do
      i = i + 1
      if i > b then return n end
      c = byte(s, i)
    end
    local v, any = 0, false
    while c and c >= 48 and c <= 57 do
      v = v * 10 + (c - 48); i = i + 1; c = byte(s, i); any = true
    end
    if not any then
      i = i + 1
    else
      if k == off then
        n = n + 1
        out[n] = v
      end
      k = k + 1
      if k == stride then k = 0 end
    end
  end
  return n
end
D.parseIndices = parseIndices

-----------------------------------------------------------------------------------------------
-- 3x4 matrisler (satir oncelikli, 12 sayi); nil = birim
-----------------------------------------------------------------------------------------------
local function mmul(A, B)
  if not A then return B end
  if not B then return A end
  local a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12 = A[1], A[2], A[3], A[4], A[5], A[6], A[7], A[8], A[9], A[10], A[11], A[12]
  local b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12 = B[1], B[2], B[3], B[4], B[5], B[6], B[7], B[8], B[9], B[10], B[11], B[12]
  return {
    a1 * b1 + a2 * b5 + a3 * b9, a1 * b2 + a2 * b6 + a3 * b10, a1 * b3 + a2 * b7 + a3 * b11, a1 * b4 + a2 * b8 + a3 * b12 + a4,
    a5 * b1 + a6 * b5 + a7 * b9, a5 * b2 + a6 * b6 + a7 * b10, a5 * b3 + a6 * b7 + a7 * b11, a5 * b4 + a6 * b8 + a7 * b12 + a8,
    a9 * b1 + a10 * b5 + a11 * b9, a9 * b2 + a10 * b6 + a11 * b10, a9 * b3 + a10 * b7 + a11 * b11, a9 * b4 + a10 * b8 + a11 * b12 + a12,
  }
end

local function isIdentity(M)
  if not M then return true end
  local e = 1e-9
  return math.abs(M[1] - 1) < e and math.abs(M[6] - 1) < e and math.abs(M[11] - 1) < e
    and math.abs(M[2]) < e and math.abs(M[3]) < e and math.abs(M[4]) < e and math.abs(M[5]) < e and math.abs(M[7]) < e
    and math.abs(M[8]) < e and math.abs(M[9]) < e and math.abs(M[10]) < e and math.abs(M[12]) < e
end

-----------------------------------------------------------------------------------------------
-- dosya dizini
-----------------------------------------------------------------------------------------------
-- s: dosya icerigi (metin). Doner: d ya da nil, hata
function D.open(path, s)
  if type(s) ~= 'string' or #s < 64 then return nil, 'bos dosya' end
  local head = sub(s, 1, 6000)
  if not find(head, '<COLLADA', 1, true) then return nil, 'COLLADA degil' end
  local d = {path = path, s = s, geo = {}, nodes = {}, nodeCount = 0}
  d.up = match(head, '<up_axis>%s*([%w_]+)') or 'Z_UP'
  d.unit = tonumber(match(head, '<unit[^>]-meter%s*=%s*"([^"]+)"')) or 1
  if d.unit <= 0 or d.unit ~= d.unit then d.unit = 1 end

  -- geometri konumlari
  local pos = 1
  local lg0 = find(s, '<library_geometries', 1, true)
  if lg0 then pos = lg0 end
  while true do
    local a, b = find(s, '<geometry', pos, true)
    if not a then break end
    local e = find(s, '>', b, true)
    if not e then break end
    local id = match(sub(s, a, e), '%sid%s*=%s*"([^"]*)"')
    if id then d.geo[id] = a end
    pos = e + 1
  end

  -- sahne dugumleri
  local vs = find(s, '<library_visual_scenes', lg0 or 1, true)
  if not vs then vs = find(s, '<library_visual_scenes', 1, true) end
  if vs then
    local ve = find(s, '</library_visual_scenes>', vs, true) or #s
    local stack, sp = {}, 0
    local i = vs
    local tmp = {}
    while true do
      local a = find(s, '<', i, true)
      if not a or a >= ve then break end
      local c1 = byte(s, a + 1)
      if c1 == 110 and sub(s, a + 1, a + 4) == 'node' then
        local e = find(s, '>', a, true)
        local tag = sub(s, a, e)
        local name = match(tag, '%sname%s*=%s*"([^"]*)"')
        local id = match(tag, '%sid%s*=%s*"([^"]*)"')
        local parentM = sp > 0 and stack[sp].M or nil
        if byte(s, e - 1) ~= 47 then
          sp = sp + 1
          stack[sp] = {name = name or id or '?', id = id, M = parentM}
        end
        i = e + 1
      elseif c1 == 47 then
        if sub(s, a + 2, a + 5) == 'node' and sp > 0 then
          stack[sp] = nil
          sp = sp - 1
        end
        i = a + 2
      elseif sp > 0 and c1 == 109 and sub(s, a + 1, a + 6) == 'matrix' then
        local e = find(s, '>', a, true)
        local f = find(s, '<', e, true)
        local n = parseFloats(s, e + 1, f - 1, tmp, 0)
        if n >= 12 then
          local M = {tmp[1], tmp[2], tmp[3], tmp[4], tmp[5], tmp[6], tmp[7], tmp[8], tmp[9], tmp[10], tmp[11], tmp[12]}
          if not isIdentity(M) then stack[sp].M = mmul(stack[sp].M, M) end
        end
        i = f
      elseif sp > 0 and c1 == 116 and sub(s, a + 1, a + 9) == 'translate' then
        local e = find(s, '>', a, true)
        local f = find(s, '<', e, true)
        local n = parseFloats(s, e + 1, f - 1, tmp, 0)
        if n >= 3 and (tmp[1] ~= 0 or tmp[2] ~= 0 or tmp[3] ~= 0) then
          stack[sp].M = mmul(stack[sp].M, {1, 0, 0, tmp[1], 0, 1, 0, tmp[2], 0, 0, 1, tmp[3]})
        end
        i = f
      elseif sp > 0 and c1 == 114 and sub(s, a + 1, a + 6) == 'rotate' then
        local e = find(s, '>', a, true)
        local f = find(s, '<', e, true)
        local n = parseFloats(s, e + 1, f - 1, tmp, 0)
        if n >= 4 and tmp[4] ~= 0 then
          local x, y, z = tmp[1], tmp[2], tmp[3]
          local l = math.sqrt(x * x + y * y + z * z)
          if l > 1e-9 then
            x, y, z = x / l, y / l, z / l
            local ang = math.rad(tmp[4])
            local c, sn = math.cos(ang), math.sin(ang)
            local t = 1 - c
            stack[sp].M = mmul(stack[sp].M, {
              t * x * x + c, t * x * y - sn * z, t * x * z + sn * y, 0,
              t * x * y + sn * z, t * y * y + c, t * y * z - sn * x, 0,
              t * x * z - sn * y, t * y * z + sn * x, t * z * z + c, 0})
          end
        end
        i = f
      elseif sp > 0 and c1 == 115 and sub(s, a + 1, a + 5) == 'scale' then
        local e = find(s, '>', a, true)
        local f = find(s, '<', e, true)
        local n = parseFloats(s, e + 1, f - 1, tmp, 0)
        if n >= 3 and (tmp[1] ~= 1 or tmp[2] ~= 1 or tmp[3] ~= 1) then
          stack[sp].M = mmul(stack[sp].M, {tmp[1], 0, 0, 0, 0, tmp[2], 0, 0, 0, 0, tmp[3], 0})
        end
        i = f
      elseif sp > 0 and c1 == 105 and sub(s, a + 1, a + 17) == 'instance_geometry' then
        local e = find(s, '>', a, true)
        local url = match(sub(s, a, e), 'url%s*=%s*"#([^"]*)"')
        if url then
          local top = stack[sp]
          local rec = {geo = url, M = top.M}
          local list = d.nodes[top.name]
          if not list then
            list = {}
            d.nodes[top.name] = list
            d.nodeCount = d.nodeCount + 1
          end
          list[#list + 1] = rec
          if top.id and top.id ~= top.name and not d.nodes[top.id] then d.nodes[top.id] = list end
        end
        i = e + 1
      else
        i = a + 1
      end
    end
  end
  return d
end

function D.hasMesh(d, name)
  return d.nodes[name] ~= nil
end

-- dugum adlari (sirali)
function D.meshNames(d)
  local out = {}
  for name in pairs(d.nodes) do out[#out + 1] = name end
  table.sort(out)
  return out
end

-----------------------------------------------------------------------------------------------
-- mesh okuma
-----------------------------------------------------------------------------------------------
local function attr(tag, name)
  return match(tag, '%s' .. name .. '%s*=%s*"([^"]*)"')
end

-- geometri blogu icindeki kaynaklar: id -> {a, b, stride}
local function readSources(s, g0, g1)
  local src = {}
  local pos = g0
  while true do
    local a = find(s, '<source', pos, true)
    if not a or a >= g1 then break end
    local e = find(s, '>', a, true)
    local id = attr(sub(s, a, e), 'id')
    local close = find(s, '</source>', e, true) or g1
    local fa = find(s, '<float_array', e, true)
    if id and fa and fa < close then
      local fe = find(s, '>', fa, true)
      local fz = find(s, '</float_array>', fe, true)
      if fz and fz <= close then
        local stride = 3
        local acc = find(s, '<accessor', fz, true)
        if acc and acc < close then
          local ae = find(s, '>', acc, true)
          stride = tonumber(attr(sub(s, acc, ae), 'stride')) or 3
        end
        src[id] = {fe + 1, fz - 1, stride}
      end
    end
    pos = close + 1
  end
  return src
end

local PRIMS = {'triangles', 'polylist', 'polygons'}

-- Doner: {verts = {x,y,z,...}, nv = N, prims = {{mat = 'ad', idx = {i1,i2,i3,...} (0 tabanli), nt = ucgen sayisi}}} ya da nil
-- Ayni dugumde birden fazla geometri varsa birlestirilir.
function D.mesh(d, name, maxTris)
  local insts = d.nodes[name]
  if not insts then return nil end
  local s = d.s
  local verts, nv = {}, 0
  local prims = {}
  local total = 0
  local tmpI = {}
  for _, inst in ipairs(insts) do
    local g0 = d.geo[inst.geo]
    if g0 then
      local g1 = find(s, '</geometry>', g0, true) or #s
      local src = readSources(s, g0, g1)
      local va = find(s, '<vertices', g0, true)
      local posSrc, vid
      if va and va < g1 then
        local ve = find(s, '</vertices>', va, true) or g1
        local vt = sub(s, va, ve)
        vid = attr(match(vt, '<vertices[^>]*>') or '', 'id')
        for tag in vt:gmatch('<input[^>]*>') do
          if attr(tag, 'semantic') == 'POSITION' then
            posSrc = (attr(tag, 'source') or ''):gsub('^#', '')
          end
        end
      end
      local ps = posSrc and src[posSrc]
      if ps then
        local base = nv
        local raw = {}
        local n = parseFloats(s, ps[1], ps[2], raw, 0)
        local stride = ps[3]
        local cnt = floor(n / stride)
        local M = inst.M
        local unit = d.unit
        local yup = d.up == 'Y_UP'
        local xup = d.up == 'X_UP'
        for k = 0, cnt - 1 do
          local x, y, z = raw[k * stride + 1], raw[k * stride + 2], raw[k * stride + 3] or 0
          if M then
            x, y, z = M[1] * x + M[2] * y + M[3] * z + M[4], M[5] * x + M[6] * y + M[7] * z + M[8], M[9] * x + M[10] * y + M[11] * z + M[12]
          end
          if yup then x, y, z = x, -z, y elseif xup then x, y, z = -y, x, z end
          local o = (base + k) * 3
          verts[o + 1], verts[o + 2], verts[o + 3] = x * unit, y * unit, z * unit
        end
        nv = base + cnt
        -- ilkel bloklari
        for _, kind in ipairs(PRIMS) do
          local pos = g0
          local openTag, closeTag = '<' .. kind, '</' .. kind .. '>'
          while true do
            local a = find(s, openTag, pos, true)
            if not a or a >= g1 then break end
            local e = find(s, '>', a, true)
            local nextCh = byte(s, a + #openTag)
            if nextCh ~= 32 and nextCh ~= 62 and nextCh ~= 10 and nextCh ~= 9 and nextCh ~= 13 then
              pos = e + 1
            elseif byte(s, e - 1) == 47 then
              pos = e + 1
            else
              local z = find(s, closeTag, e, true) or g1
              local tag = sub(s, a, e)
              local mat = attr(tag, 'material') or ''
              mat = mat:gsub('%-material$', '')
              -- girdiler
              local nin, voff = 1, 0
              local ip = e
              while true do
                local ia = find(s, '<input', ip, true)
                if not ia or ia >= z then break end
                local ie = find(s, '>', ia, true)
                local itag = sub(s, ia, ie)
                local off = tonumber(attr(itag, 'offset')) or 0
                if off + 1 > nin then nin = off + 1 end
                if attr(itag, 'semantic') == 'VERTEX' then voff = off end
                ip = ie + 1
              end
              local idx, ni = {}, 0
              if kind == 'triangles' then
                local pa = find(s, '<p>', e, true)
                if pa and pa < z then
                  local pz = find(s, '</p>', pa, true) or z
                  ni = parseIndices(s, pa + 3, pz - 1, nin, voff, idx, 0)
                end
              elseif kind == 'polylist' then
                local vca = find(s, '<vcount>', e, true)
                local pa = find(s, '<p>', e, true)
                if vca and pa and vca < z and pa < z then
                  local vcz = find(s, '</vcount>', vca, true) or z
                  local vc, nvc = {}, 0
                  nvc = parseIndices(s, vca + 8, vcz - 1, 1, 0, vc, 0)
                  local pz = find(s, '</p>', pa, true) or z
                  local all = {}
                  local na = parseIndices(s, pa + 3, pz - 1, nin, voff, all, 0)
                  local k = 0
                  for q = 1, nvc do
                    local c = vc[q]
                    if k + c > na then break end
                    for t = 1, c - 2 do
                      idx[ni + 1], idx[ni + 2], idx[ni + 3] = all[k + 1], all[k + t + 1], all[k + t + 2]
                      ni = ni + 3
                    end
                    k = k + c
                  end
                end
              else
                local pp = e
                while true do
                  local pa = find(s, '<p>', pp, true)
                  if not pa or pa >= z then break end
                  local pz = find(s, '</p>', pa, true) or z
                  local na = parseIndices(s, pa + 3, pz - 1, nin, voff, tmpI, 0)
                  for t = 2, na - 1 do
                    idx[ni + 1], idx[ni + 2], idx[ni + 3] = tmpI[1], tmpI[t], tmpI[t + 1]
                    ni = ni + 3
                  end
                  pp = pz + 4
                end
              end
              ni = ni - (ni % 3)
              if ni > 0 then
                -- gecersiz indeksleri ayikla, tabani ekle
                local ok = true
                for q = 1, ni do
                  local v = idx[q]
                  if v >= cnt then ok = false break end
                  idx[q] = v + base
                end
                if ok then
                  prims[#prims + 1] = {mat = mat, idx = idx, nt = ni / 3}
                  total = total + ni / 3
                end
              end
              pos = z + 1
            end
            if maxTris and total > maxTris then break end
          end
        end
      end
    end
  end
  if nv == 0 or #prims == 0 then return nil end
  return {verts = verts, nv = nv, prims = prims, nt = total}
end

return D
