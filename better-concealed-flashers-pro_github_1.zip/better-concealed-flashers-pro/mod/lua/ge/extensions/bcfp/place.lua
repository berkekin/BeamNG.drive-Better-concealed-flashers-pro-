-- Better Concealed Flashers PRO 3 - montaj cozuculeri
-- Yuzey tarayicinin (scan.lua) sorgulariyla her cakar basligini bolgesine gore yerlestirir:
--   cam ici ust  : tavan dosemesinin hemen altinda, cama belirli bir boslukla (on cam / arka cam)
--   cam ici alt  : torpido ya da arka raf uzerinde, cama belirli bir boslukla
--   dis yuzeyler : panjur, tamponlar, bagaj kapagi, aynalar ... yuzeye oturtulur ve yuzey normaline cevrilir
-- Oyunun kendi (gelistirici) cakar parcalarindan okunan "fabrika" konumlari varsa onlar esas alinir.
-- Durus: {x, y, z, yaw (derece; 0 ileri, 180 geri, +x = sola), tilt (derece; + yukari bakar)}
local P = {}
local U, S

local min, max, abs, floor, sqrt, huge, atan, deg = math.min, math.max, math.abs, math.floor, math.sqrt, math.huge, math.atan, math.deg

function P.init(mods) U, S = mods.U, mods.S end

P.CLEAR = 0.012        -- cam ile baslik kosesi arasindaki dik bosluk (m)
P.EMBED = 0.003        -- tavana / zemine gomme payi (m)

local function clamp(v, a, b) if v < a then return a elseif v > b then return b end return v end

-----------------------------------------------------------------------------------------------
-- cam ici, ust kenar (on cam: sgn = -1, arka cam: sgn = 1)
-----------------------------------------------------------------------------------------------
-- en yuksek z'yi bul: g(z) = baslik kosesi ile cam arasindaki yatay bosluk - gereken >= 0
local function glassLimit(prof, sgn, yf, gapH, zLo, zHi)
  local function g(z) return (yf - S.profY(prof, z)) * (-sgn) - gapH end
  if g(zHi) >= 0 then return zHi end
  if g(zLo) < 0 then return nil end
  for _ = 1, 22 do
    local mid = (zLo + zHi) / 2
    if g(mid) >= 0 then zLo = mid else zHi = mid end
  end
  return zLo
end

-- Tavan: dusey dogru uzerinde, cam ust kenari hizasindaki "tavan katmani"nin (dis sac, ic sac, doseme,
-- guneslik ...) en alt yuzeyi. Katman, en ustteki kati yuzeyden baslayip 8 cm'den buyuk ilk bosluga kadar surer;
-- boylece koltuk basliklari gibi asagidaki nesneler tavan sayilmaz.
-- skipTag: bu etiketli modeller (ornek: bagaj kapagi) yok sayilir
local function ceilingPoint(M, px, py, zT, skipTag)
  local zs, ts, n = M:hitsZ(px, py, S.M_SOLID, zT - 0.32, zT + 0.30)
  local c, lined, ct
  local C = M.C
  for i = 1, n do
    local skip = false
    if skipTag then
      local m = M:meshOf(ts[i])
      skip = m and m.tag == skipTag
    end
    if not skip then
      if not c then
        if zs[i] < zT - 0.07 then return nil end
        c, ct = zs[i], ts[i]
      elseif c - zs[i] <= 0.08 then
        c, ct = zs[i], ts[i]
      else
        break
      end
      if C[ts[i] + 1] == S.INTERIOR then lined = true end
    end
  end
  return c, lined, ct
end

-- ayak izi ornekleri: en alcak tavan (yoksa nil), tum ornekler tavana degdi mi
local function ceilingAt(M, x, y, hw, hd, zT, skipTag)
  local zc = huge
  local hits, total = 0, 0
  local anyLined = false
  local tri
  for ix = -1, 1, 2 do
    for iy = -1, 1 do
      total = total + 1
      local z, lined, t = ceilingPoint(M, x + ix * 0.8 * hw, y + iy * 0.85 * hd, zT, skipTag)
      if z then
        hits = hits + 1
        if z < zc then zc, tri = z, t end
        if lined then anyLined = true end
      end
    end
  end
  if hits == 0 then return nil, false end
  -- ic doseme modeli yoksa (yalnizca dis sac): tavan dosemesi kalinligi kadar asagi
  if not anyLined then zc = zc - 0.015 end
  return zc, hits == total, tri
end

local function floorAt(M, x, y, hw, hd, z0, zMin)
  local zf = -huge
  local hit = false
  local tri
  for ix = -1, 1, 2 do
    for iy = -1, 1 do
      local z, t = M:rayZ(x + ix * 0.8 * hw, y + iy * 0.85 * hd, -1, S.M_SOLID, z0)
      if z and z >= zMin then
        hit = true
        if z > zf then zf, tri = z, t end
      end
    end
  end
  if not hit then return nil end
  return zf, tri
end

-- o: {clear, drop (m, asagi kaydirma), gate (cam bagaj kapaginda: baslik govdenin tavan kenarina asilir)}
-- Kural (oyunun kendi cakarlarindaki gibi): baslik tavana degecek ve cama "clear" kadar bosluk kalacak sekilde,
-- cama en yakin konum.
function P.glassTop(M, set, sgn, x, hw, hh, hd, o)
  o = o or {}
  local prof = M:glassProfile(set, x, sgn)
  if not prof then return nil end
  local yT, zT, k = prof.yTop, prof.zTop, prof.kTop
  local cosphi = 1 / sqrt(1 + k * k)
  local gapH = (o.clear or P.CLEAR) / max(cosphi, 0.25)
  local zCapGlass = zT - 0.008
  local gate = o.gate and true or false
  local skipTag = gate and 'trunk' or nil
  local step = 0.0025
  local n = floor(((gate and 0.36 or 0.18) + 0.08) / step)
  local mtri
  local function pass(cap)
    for i = 0, n do
      local s = -0.08 + i * step
      local y = yT - sgn * s
      local zc, full, tri = ceilingAt(M, x, y, hw, hd, zT, skipTag)
      if zc and (full or not gate) then
        local zl = glassLimit(prof, sgn, y + sgn * hd, gapH, prof.zBot, zT + 0.30)
        if zl then
          local zA = min(zc + P.EMBED, zCapGlass)
          if cap and zA > cap then zA = cap end
          if zl >= zA - 0.002 then mtri = tri return min(zA, zl), y, true end
        end
      end
    end
    return nil
  end
  local zt, y, hasC = pass(nil)
  if not zt then
    -- tavan yok (ustu acik arac / model eksik): cam ust kenarinin 2 cm altinda, cama en yakin konum
    local target = zT - 0.02
    for i = 0, n do
      local s = -0.08 + i * step
      local yy = yT - sgn * s
      local zl = glassLimit(prof, sgn, yy + sgn * hd, gapH, prof.zBot, zT + 0.30)
      if zl and zl >= target then zt, y, hasC = target, yy, false break end
    end
    if not zt then return nil end
  end
  local drop = o.drop or 0
  if drop > 0.0005 then
    local zt2, y2 = pass(zt - drop)
    if zt2 then zt, y = zt2, y2
    else zt = zt - drop end
  end
  return {x = x, y = y, z = zt - hh, yaw = (sgn < 0) and 0 or 180, tilt = 0, ceiling = hasC, zEdge = zT, yEdge = yT, tri = mtri, mount = 'top'}
end

-----------------------------------------------------------------------------------------------
-- cam ici, alt kenar (torpido / arka raf)
-----------------------------------------------------------------------------------------------
function P.glassBottom(M, set, sgn, x, hw, hh, hd, o)
  o = o or {}
  local prof = M:glassProfile(set, x, sgn)
  if not prof then return nil end
  local yB, zB, k = prof.yBot, prof.zBot, prof.kBot
  local cosphi = 1 / sqrt(1 + k * k)
  local gapH = (o.clear or 0.015) / max(cosphi, 0.25)
  for i = 0, 40 do
    local s = i * 0.01
    local y = yB - sgn * s
    local zf, ftri = floorAt(M, x, y, hw, hd, zB + 0.22, zB - (o.depth or 0.22))
    if zf then
      local zb = zf - P.EMBED
      local zl = glassLimit(prof, sgn, y + sgn * hd, gapH, prof.zBot - 0.3, prof.zTop + 0.3)
      if zl and zb + 2 * hh <= zl then
        return {x = x, y = y, z = zb + hh, yaw = (sgn < 0) and 0 or 180, tilt = 0, floor = zf, zEdge = zB, yEdge = yB, tri = ftri, mount = 'bottom'}
      end
    end
  end
  return nil
end

-----------------------------------------------------------------------------------------------
-- dis yuzey (y yonu): dir = 1 on, -1 arka
-----------------------------------------------------------------------------------------------
-- o: {sink (0..1), follow (0..1), mask}
function P.faceY(M, dir, x, z, hw, hh, hd, o)
  o = o or {}
  local mask = o.mask or S.M_EXT
  local best, bestT
  local n = 0
  for ix = -1, 1 do
    for iz = -1, 1 do
      local y, t = M:rayY(x + ix * 0.8 * hw, z + iz * 0.8 * hh, dir, mask)
      if y then
        n = n + 1
        if not best or (dir > 0 and y < best) or (dir < 0 and y > best) then best, bestT = y, t end
      end
    end
  end
  if not best then return nil end
  local yc, tc = M:rayY(x, z, dir, mask)
  -- yuzey yonu: genis pencerede on zarf. Sapma (yaw): her x sutununun en ondeki noktasindan dogrusal egim
  -- (izgara citalarindan etkilenmez). Egim (tilt): yalnizca yuzey duzlemsel ve belirgin egimliyse.
  local wx, wz = max(1.8 * hw, 0.09), max(1.8 * hh, 0.05)
  local cols, rows = {}, {}
  local pts, m = {}, 0
  for ix = -2, 2 do
    for iz = -2, 2 do
      local px, pz = x + ix * 0.5 * wx, z + iz * 0.5 * wz
      local y = M:rayY(px, pz, dir, mask)
      if y and abs(y - best) < 0.08 then
        m = m + 1
        pts[m] = {px - x, pz - z, y}
        local c = cols[ix]
        if not c or (dir > 0 and y < c) or (dir < 0 and y > c) then cols[ix] = y end
        local r = rows[iz]
        if not r or (dir > 0 and y < r) or (dir < 0 and y > r) then rows[iz] = y end
      end
    end
  end
  local function slope(tab, stepLen)
    local s0, s1, s2, sy, sxy, cnt = 0, 0, 0, 0, 0, 0
    for i = -2, 2 do
      local v = tab[i]
      if v then
        local t = i * stepLen
        cnt, s1, s2, sy, sxy = cnt + 1, s1 + t, s2 + t * t, sy + v, sxy + t * v
      end
    end
    local den = cnt * s2 - s1 * s1
    if cnt < 3 or abs(den) < 1e-12 then return 0 end
    return (cnt * sxy - s1 * sy) / den
  end
  local a = slope(cols, 0.5 * wx)
  local b = slope(rows, 0.5 * wz)
  -- duzlemsellik: y = a x + b z + c artik karekoku
  local rms = huge
  if m >= 8 then
    local c0 = 0
    for i = 1, m do c0 = c0 + (pts[i][3] - a * pts[i][1] - b * pts[i][2]) end
    c0 = c0 / m
    local ss = 0
    for i = 1, m do
      local r = pts[i][3] - a * pts[i][1] - b * pts[i][2] - c0
      ss = ss + r * r
    end
    rms = sqrt(ss / m)
  end
  local follow = o.follow == nil and 1 or o.follow
  local followTilt = o.followTilt == nil and 0 or o.followTilt
  local dyaw = clamp(deg(atan(a)), -25, 25) * follow
  local tilt = clamp(deg(atan(dir > 0 and b or -b)), -10, 25) * followTilt
  if abs(dyaw) < 6 then dyaw = 0 end
  if abs(tilt) < 8 or rms > 0.008 then tilt = 0 end
  local sink = o.sink == nil and 0.5 or o.sink
  local y = best - dir * hd * (1 - 2 * sink)
  local mesh = bestT and M:meshOf(bestT)
  local cmesh = tc and M:meshOf(tc)
  return {x = x, y = y, z = z, yaw = (dir > 0) and dyaw or (180 + dyaw), tilt = tilt, surf = best,
          cls = tc and M.C[tc + 1] or (bestT and M.C[bestT + 1]), mesh = (cmesh or mesh) and (cmesh or mesh).name or nil,
          tag = (cmesh or mesh) and (cmesh or mesh).tag or nil, hits = n, rms = rms, tri = bestT or tc, mount = 'face'}
end

-----------------------------------------------------------------------------------------------
-- dis yuzey (x yonu): side = 1 sol (+x), -1 sag; baslik disa bakar
-----------------------------------------------------------------------------------------------
function P.faceX(M, side, y, z, hw, hh, hd, o)
  o = o or {}
  local mask = o.mask or S.M_EXT
  local best, bestT
  for iy = -1, 1 do
    for iz = -1, 1 do
      local x, t = M:rayX(y + iy * 0.8 * hw, z + iz * 0.8 * hh, -side, mask)
      if x and (not best or (side > 0 and x > best) or (side < 0 and x < best)) then best, bestT = x, t end
    end
  end
  if not best then return nil end
  -- egim: x = a y + b z + c
  local wy, wz = max(1.6 * hw, 0.05), max(1.6 * hh, 0.03)
  local s1, s2, s0, s11, s22, s12, s10, s20, m = 0, 0, 0, 0, 0, 0, 0, 0, 0
  for iy = -2, 2 do
    for iz = -1, 1 do
      local py, pz = y + iy * 0.5 * wy, z + iz * wz
      local x = M:rayX(py, pz, -side, mask)
      if x and abs(x - best) < 0.05 then
        local d1, d2 = py - y, pz - z
        s1, s2, s0 = s1 + d1, s2 + d2, s0 + x
        s11, s22, s12 = s11 + d1 * d1, s22 + d2 * d2, s12 + d1 * d2
        s10, s20 = s10 + d1 * x, s20 + d2 * x
        m = m + 1
      end
    end
  end
  local a, b = 0, 0
  if m >= 5 then
    local det = s11 * (s22 * m - s2 * s2) - s12 * (s12 * m - s2 * s1) + s1 * (s12 * s2 - s22 * s1)
    if abs(det) > 1e-12 then
      a = (s10 * (s22 * m - s2 * s2) - s12 * (s20 * m - s2 * s0) + s1 * (s20 * s2 - s22 * s0)) / det
      b = (s11 * (s20 * m - s2 * s0) - s10 * (s12 * m - s2 * s1) + s1 * (s12 * s0 - s20 * s1)) / det
    end
  end
  local follow = o.follow == nil and 1 or o.follow
  -- disa bakan normal: sol icin (1, -a, -b); yaw 90 = +x'e bakar. Yuzey one dogru daraliyorsa (a > 0, sol) baslik one doner
  local dyaw = clamp(deg(atan(a)), -35, 35) * follow
  local tilt = clamp(deg(atan(side > 0 and -b or b)), -25, 35) * follow
  if abs(dyaw) < 3 then dyaw = 0 end
  if abs(tilt) < 3 then tilt = 0 end
  local sink = o.sink == nil and 0.5 or o.sink
  local x = best + side * hd * (1 - 2 * sink)
  local mesh = bestT and M:meshOf(bestT)
  return {x = x, y = y, z = z, yaw = side * 90 - side * dyaw, tilt = tilt, surf = best, cls = bestT and M.C[bestT + 1],
          mesh = mesh and mesh.name or nil, tag = mesh and mesh.tag or nil, tri = bestT, mount = 'face'}
end

-----------------------------------------------------------------------------------------------
-- yan cam ici (arka yan camlar): baslik disa bakar, cam ust kenarinin altinda
-----------------------------------------------------------------------------------------------
function P.sideGlass(M, side, y, hw, hh, hd, o)
  o = o or {}
  local set = o.set or (side > 0 and M.glass.sideL or M.glass.sideR)
  if not set or #set == 0 then return nil end
  local T = M.T
  -- Y = y duzlemiyle kesit
  local zTop, xTop, zBot = -huge, nil, huge
  for i = 1, #set do
    local q = set[i] * 9
    for e = 0, 2 do
      local a, b = q + e * 3, q + ((e + 1) % 3) * 3
      local ya, yb = T[a + 2], T[b + 2]
      if (ya <= y and yb > y) or (yb <= y and ya > y) then
        local u = (y - ya) / (yb - ya)
        local z = T[a + 3] + u * (T[b + 3] - T[a + 3])
        local x = T[a + 1] + u * (T[b + 1] - T[a + 1])
        if z > zTop then zTop, xTop = z, x end
        if z < zBot then zBot = z end
      end
    end
  end
  if not xTop or zTop - zBot < 0.12 then return nil end
  local z = zTop - hh - 0.035
  -- o yukseklikte camin x'i
  local xg = M:rayX(y, z, -side, {[S.GLASS] = true})
  if not xg then xg = xTop end
  local x = xg - side * (hd + 0.022)
  local zc, ctri = M:rayZ(x, y, 1, S.M_SOLID, z - 0.05)
  if zc and zc < zTop + 0.05 and zc - hh < z + 0.03 then z = min(z, zc - hh + P.EMBED) else ctri = nil end
  return {x = x, y = y, z = z, yaw = side * 90, tilt = 0, zEdge = zTop, tri = ctri, mount = 'top'}
end

-----------------------------------------------------------------------------------------------
-- ust yuzey (tavan / kaput): baslik ileri bakar, yuzeye oturur
-----------------------------------------------------------------------------------------------
function P.topZ(M, x, y, hw, hh, hd, o)
  o = o or {}
  local best, bt
  for ix = -1, 1 do
    for iy = -1, 1 do
      local z, t = M:rayZ(x + ix * 0.8 * hw, y + iy * 0.8 * hd, -1, o.mask or S.M_EXT, huge)
      if z and (not best or z > best) then best, bt = z, t end
    end
  end
  if not best then return nil end
  local sink = o.sink == nil and 0.1 or o.sink
  return {x = x, y = y, z = best + hh * (1 - 2 * sink), yaw = o.yaw or 0, tilt = 0, surf = best, tri = bt, mount = 'bottom'}
end

-----------------------------------------------------------------------------------------------
-- bolge cerceveleri: varsayilan yanal konum, yukseklik, adet
-----------------------------------------------------------------------------------------------
local function boxC(b) return (b[1] + b[4]) / 2, (b[2] + b[5]) / 2, (b[3] + b[6]) / 2 end

-- on / arka yuzun alt siniri: (x = 0.3) hattinda, on yuzden 0.6 m icinde kalan en alt nokta
local function faceBottom(M, dir)
  local bb = M.bbox
  local edge = M:rayY(0.3, (bb[3] + bb[6]) * 0.35, dir, S.M_BODY)
  if not edge then edge = dir > 0 and bb[2] or bb[5] end
  local zb
  for i = 0, 60 do
    local z = bb[3] + i * 0.02
    local y = M:rayY(0.3, z, dir, S.M_BODY)
    if y and abs(y - edge) < 0.6 then zb = z break end
  end
  return zb or bb[3], edge
end

function P.frames(M)
  if M.frames then return M.frames end
  local F = {}
  local bb, L, G = M.bbox, M.land, M.glass
  local halfW = 0
  -- govde yari genisligi (aynalar haric): on yuzden bel hizasinda yan isinlar
  local zBelt = bb[3] + 0.45 * (bb[6] - bb[3])
  for i = 1, 9 do
    local y = bb[2] + (bb[5] - bb[2]) * i / 10
    local x = M:rayX(y, zBelt, -1, S.M_BODY)
    if x and x > halfW and x < 1.6 then halfW = x end
  end
  if halfW < 0.4 then halfW = min(abs(bb[1]), abs(bb[4])) end
  F.halfW = halfW
  F.zRoof = bb[6]
  local zbF, yF = faceBottom(M, 1)
  local zbR, yR = faceBottom(M, -1)
  F.yFront, F.yRear, F.zBotF, F.zBotR = yF, yR, zbF, zbR
  local zh = L.headlight and select(3, boxC(L.headlight)) or (zbF + 0.42 * (bb[6] - zbF) * 0.6)
  local zt = L.taillight and select(3, boxC(L.taillight)) or (zbR + 0.5 * (bb[6] - zbR) * 0.6)
  F.zHead, F.zTail = zh, zt

  if G.front and #G.front > 0 then
    local hwTop, zTop = M:glassHalfWidth(G.front, 0.08)
    local x0 = 0.34
    local nMax = floor((hwTop - 0.075 - x0) / 0.065 + 1e-6) + 1
    if nMax < 3 then
      x0 = max(0.10, hwTop - 0.075 - 2 * 0.065)
      nMax = max(1, floor((hwTop - 0.075 - x0) / 0.065 + 1e-6) + 1)
    end
    F.windshield = {x0 = x0, n = min(4, max(1, nMax)), nMax = max(1, nMax + 2), gap = 0.065, hw = hwTop, z = zTop, unit = 'slim'}
    F.dash = {x0 = min(0.34, max(0.15, hwTop - 0.25)), n = 2, gap = 0.07, unit = 'std'}
  end
  if G.rear and #G.rear > 0 then
    local hwTop, zTop = M:glassHalfWidth(G.rear, 0.08)
    local x0 = min(0.30, max(0.10, hwTop - 0.075 - 2 * 0.065))
    local nMax = max(1, floor((hwTop - 0.075 - x0) / 0.065 + 1e-6) + 1)
    F.rearglass = {x0 = x0, n = min(3, nMax), nMax = nMax + 2, gap = 0.065, hw = hwTop, z = zTop, unit = 'slim'}
    F.reardeck = {x0 = min(0.30, max(0.12, hwTop - 0.20)), n = 2, gap = 0.09, unit = 'wide'}
  end
  -- izgara
  do
    local z, x0, src
    if L.grille then
      local gb = L.grille
      z = (gb[3] + gb[6]) / 2
      x0 = clamp(0.45 * max(abs(gb[1]), abs(gb[4])), 0.13, 0.34)
      src = 'mesh'
    else
      z = zh - 0.02
      x0 = 0.22
      src = 'guess'
    end
    F.grille = {x0 = x0, z = z, n = 1, gap = 0.07, unit = 'std', src = src}
  end
  -- tampon yuksekligi: tampon modelinin dikey yuzunun ortasi (model yoksa far / stop yuksekligine gore tahmin)
  local function bumperZ(box, zGuess, zLamp)
    if box and box[6] - box[3] > 0.08 then
      local z = box[3] + 0.5 * (box[6] - box[3])
      if z > zLamp - 0.08 then z = max(box[3] + 0.3 * (box[6] - box[3]), zLamp - 0.16) end
      return z
    end
    return zGuess
  end
  F.bumperF = {x0 = clamp(0.42 * halfW, 0.25, 0.48), z = bumperZ(L.bumperF, zbF + 0.40 * (zh - zbF), zh), n = 1, gap = 0.08, unit = 'std'}
  F.bumperR = {x0 = clamp(0.40 * halfW, 0.28, 0.45), z = bumperZ(L.bumperR, zbR + 0.36 * (zt - zbR), zt), n = 1, gap = 0.08, unit = 'std'}
  do
    -- bagaj / arka kapak: plakanin iki yani (plaka kapaktaysa), yoksa stop lambasi hizasi
    local x0, z = 0.26, zt
    if L.plateR and L.plateR[3] > F.bumperR.z + 0.12 then
      z = L.plateR[3]
      x0 = clamp(0.30, 0.24, 0.34)
    end
    F.trunk = {x0 = x0, z = z, n = 1, gap = 0.07, unit = 'slim'}
  end
  if L.mirrorL or L.mirrorR then
    local mb = L.mirrorL or {-L.mirrorR[4], L.mirrorR[2], L.mirrorR[3], -L.mirrorR[1], L.mirrorR[5], L.mirrorR[6]}
    local cx, cy, cz = boxC(mb)
    F.mirrors = {x0 = cx, z = cz, y = cy, n = 1, gap = 0.05, unit = 'mini', box = mb}
  end
  do
    -- arka yan cam: en gerideki yan pencere modeli (on / arka camin koseleri haric)
    local T, MI = M.T, M.MI
    -- on / arka camin y araliklari (mesh basina): ayni mesh'teki yan cam parcasi bu araliklarla cakisiyorsa kose camidir
    local frY = {}
    for _, set in ipairs({G.front or {}, G.rear or {}}) do
      for i = 1, #set do
        local k = set[i]
        local mi = MI[k + 1]
        local q = k * 9
        local r = frY[mi]
        if not r then r = {huge, -huge}; frY[mi] = r end
        r[1] = min(r[1], T[q + 2], T[q + 5], T[q + 8])
        r[2] = max(r[2], T[q + 2], T[q + 5], T[q + 8])
      end
    end
    -- yan camlar: mesh basina, y boyunca bosluklarla ayrilan parcalar (tek parca govde modellerinde her pencere ayri parca)
    local function rearWindow(set)
      local byMesh = {}
      for i = 1, #set do
        local k = set[i]
        local mi = MI[k + 1]
        local l = byMesh[mi]
        if not l then l = {}; byMesh[mi] = l end
        local q = k * 9
        l[#l + 1] = {k = k, y0 = min(T[q + 2], T[q + 5], T[q + 8]), y1 = max(T[q + 2], T[q + 5], T[q + 8])}
      end
      local entries = {}
      for mi, list in pairs(byMesh) do
        table.sort(list, function(p, q) return p.y0 < q.y0 end)
        local cur
        for _, it in ipairs(list) do
          if cur and it.y0 <= cur.y1 + 0.04 then
            if it.y1 > cur.y1 then cur.y1 = it.y1 end
            cur.tris[#cur.tris + 1] = it.k
          else
            cur = {mi = mi, y0 = it.y0, y1 = it.y1, tris = {it.k}}
            entries[#entries + 1] = cur
          end
        end
      end
      local best
      for _, e in ipairs(entries) do
        local r = frY[e.mi]
        local corner = r and e.y1 > r[1] - 0.03 and e.y0 < r[2] + 0.03
        if not corner then
          local aSum, ySum = 0, 0
          for _, k in ipairs(e.tris) do
            local q = k * 9
            local ux, uy, uz = T[q + 4] - T[q + 1], T[q + 5] - T[q + 2], T[q + 6] - T[q + 3]
            local vx, vy, vz = T[q + 7] - T[q + 1], T[q + 8] - T[q + 2], T[q + 9] - T[q + 3]
            local cx, cy, cz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            local ar = 0.5 * sqrt(cx * cx + cy * cy + cz * cz)
            aSum, ySum = aSum + ar, ySum + ar * (T[q + 2] + T[q + 5] + T[q + 8]) / 3
          end
          e.a, e.cy = aSum, ySum / max(aSum, 1e-9)
          if e.a >= 0.03 and (e.y1 - e.y0) >= 0.18 and (not best or e.cy > best.cy) then best = e end
        end
      end
      return best
    end
    local wl, wr = rearWindow(G.sideL or {}), rearWindow(G.sideR or {})
    local w = wl or wr
    if w then
      F.sideRear = {y = w.cy, n = 1, gap = 0.07, unit = 'slim', setL = wl and wl.tris or nil, setR = wr and wr.tris or nil,
                    yL = wl and wl.cy or nil, yR = wr and wr.cy or nil}
    end
  end
  F.sideF = {y = yF + 0.32, z = zbF + 0.45 * (zh - zbF), n = 1, gap = 0.08, unit = 'std'}
  do
    local yS = (bb[2] + bb[5]) / 2
    local zS = bb[3] + 0.16 + (zbF - bb[3]) * 0.5
    -- marspiyel bandi: kapi olmayan en alt govde yuzeyi
    local run0, run1
    for i = 0, 22 do
      local z = bb[3] + 0.06 + i * 0.02
      local okRow = 0
      for _, dy in ipairs({-0.35, 0, 0.35}) do
        local x, t = M:rayX(yS + dy, z, -1, S.M_BODY)
        if x and x > halfW - 0.16 then
          local m = M:meshOf(t)
          if not (m and m.tag == 'door') then okRow = okRow + 1 end
        end
      end
      if okRow >= 2 then
        run0 = run0 or z
        run1 = z
      elseif run0 then
        break
      end
    end
    if run0 and run1 - run0 >= 0.02 then zS = (run0 + run1) / 2 end
    F.skirt = {y = yS, z = zS, n = 2, gap = 0.6, unit = 'std'}
  end
  if L.headlight then
    local cx, cy, cz = boxC(L.headlight)
    F.hideF = {x0 = cx, z = cz, n = 1, gap = 0.08, unit = 'round'}
  end
  if L.taillight then
    local cx, cy, cz = boxC(L.taillight)
    F.hideR = {x0 = cx, z = cz, n = 1, gap = 0.08, unit = 'round'}
  end
  -- kaput on kenari
  do
    local yH = L.hood and (L.hood[2] + 0.12) or (yF + 0.35)
    F.hood = {x0 = 0.12, y = yH, n = 1, gap = 0.07, unit = 'slim'}
  end
  -- tavan
  do
    local y0, y1
    if L.roof then y0, y1 = L.roof[2], L.roof[5] end
    -- tavan dis yuzeyi: orta hatta en yuksek kesit
    local zr, yr = -huge, 0
    local ya, yb = bb[2], bb[5]
    local prof = {}
    for i = 0, 60 do
      local y = ya + (yb - ya) * i / 60
      local z = M:rayZ(0.05, y, -1, S.M_EXT, huge)
      prof[i] = {y, z}
      if z and z > zr then zr, yr = z, y end
    end
    if zr > -huge then
      local r0, r1
      for i = 0, 60 do
        local p = prof[i]
        if p[2] and p[2] > zr - 0.09 then
          r0 = r0 or p[1]
          r1 = p[1]
        end
      end
      if r0 and r1 and r1 - r0 > 0.25 then y0, y1 = r0, r1 end
      F.roof = {y0 = y0 or (yr - 0.4), y1 = y1 or (yr + 0.4), z = zr, n = 2, gap = 0.2, unit = 'std'}
      F.roof.y = F.roof.y0 + 0.32 * (F.roof.y1 - F.roof.y0)
      F.roof.x0 = 0.2
    end
  end
  M.frames = F
  return F
end

-----------------------------------------------------------------------------------------------
-- tek baslik cozumu
-----------------------------------------------------------------------------------------------
-- zone: bolge kimligi; side: 1 (sol, +x) / -1 (sag); u: yanal konum (m, pozitif); dims: {w, h, d}
-- q: {dz (m, dikey kayma), drop (m), sink, follow, zAbs (istege bagli sabit yukseklik), y (yan bolgeler icin boyuna konum)}
function P.head(M, zone, side, u, dims, q)
  q = q or {}
  local hw, hh, hd = dims.w / 2, dims.h / 2, dims.d / 2
  local F = P.frames(M)
  local f = F[zone]
  local x = side * u
  if zone == 'windshield' then
    if not M.glass.front or #M.glass.front == 0 then return nil end
    return P.glassTop(M, M.glass.front, -1, x, hw, hh, hd, {drop = q.drop, clear = q.clear})
  elseif zone == 'rearglass' then
    if not M.glass.rear or #M.glass.rear == 0 then return nil end
    return P.glassTop(M, M.glass.rear, 1, x, hw, hh, hd, {drop = q.drop, clear = q.clear, gate = M.glass.rearGate})
  elseif zone == 'dash' then
    if not M.glass.front or #M.glass.front == 0 then return nil end
    return P.glassBottom(M, M.glass.front, -1, x, hw, hh, hd, {depth = 0.30})
  elseif zone == 'reardeck' then
    if not M.glass.rear or #M.glass.rear == 0 then return nil end
    return P.glassBottom(M, M.glass.rear, 1, x, hw, hh, hd, {depth = 0.18})
  elseif zone == 'grille' or zone == 'bumperF' or zone == 'hideF' then
    if not f then return nil end
    local z = (q.zAbs or f.z) + (q.dz or 0)
    local o = {sink = q.sink, follow = q.follow, followTilt = q.followTilt}
    if zone == 'grille' and o.follow == nil then o.follow = 0 end
    if zone == 'hideF' then
      local p = P.faceY(M, 1, x, z, hw, hh, hd, {sink = 0.5, follow = 0})
      if p then p.y = p.surf + 0.03 + hd end
      return p
    end
    local p = P.faceY(M, 1, x, z, hw, hh, hd, o)
    -- lamba ustune denk geldiyse yana kaydir (once ice, sonra disa)
    if p and p.cls == S.LAMP and not q.noAvoid then
      for _, dx in ipairs({-0.07, 0.07, -0.14, 0.14, -0.21}) do
        local p2 = P.faceY(M, 1, side * (u + dx), z, hw, hh, hd, o)
        if p2 and p2.cls ~= S.LAMP then p2.moved = dx return p2 end
      end
    end
    return p
  elseif zone == 'bumperR' or zone == 'trunk' or zone == 'hideR' then
    if not f then return nil end
    local z = (q.zAbs or f.z) + (q.dz or 0)
    local o = {sink = q.sink, follow = q.follow, followTilt = q.followTilt}
    if zone == 'trunk' and o.follow == nil then o.follow = 0 end
    if zone == 'hideR' then
      local p = P.faceY(M, -1, x, z, hw, hh, hd, {sink = 0.5, follow = 0})
      if p then p.y = p.surf - 0.03 - hd end
      return p
    end
    local p = P.faceY(M, -1, x, z, hw, hh, hd, o)
    if p and p.cls == S.LAMP and not q.noAvoid then
      for _, dx in ipairs({-0.07, 0.07, -0.14, 0.14, -0.21}) do
        local p2 = P.faceY(M, -1, side * (u + dx), z, hw, hh, hd, o)
        if p2 and p2.cls ~= S.LAMP then p2.moved = dx return p2 end
      end
    end
    return p
  elseif zone == 'mirrors' then
    if not f then return nil end
    local z = (q.zAbs or f.z) + (q.dz or 0)
    return P.faceY(M, 1, x, z, hw, hh, hd, {sink = q.sink == nil and 0.4 or q.sink, follow = 0})
  elseif zone == 'sideRear' then
    if not f then return nil end
    local set = (side > 0) and f.setL or f.setR
    local yc = (side > 0) and f.yL or f.yR
    return P.sideGlass(M, side, (q.y or yc or f.y), hw, hh, hd, {set = set})
  elseif zone == 'sideF' or zone == 'skirt' then
    if not f then return nil end
    local z = (q.zAbs or f.z) + (q.dz or 0)
    return P.faceX(M, side, (q.y or f.y), z, hw, hh, hd, {sink = q.sink, follow = q.follow})
  elseif zone == 'hood' then
    if not f then return nil end
    return P.topZ(M, x, (q.y or f.y), hw, hh, hd, {sink = q.sink})
  elseif zone == 'roof' then
    if not f then return nil end
    return P.topZ(M, x, (q.y or f.y), hw, hh, hd, {sink = q.sink})
  end
  return nil
end

-----------------------------------------------------------------------------------------------
-- bolge listesi (arayuz ve hazir duzenler icin)
-----------------------------------------------------------------------------------------------
-- kind: glass (cam ici), face (dis yuzey, one / arkaya bakar), side (yana bakar), top (ust yuzey)
P.ZONES = {
  {id = 'windshield', tr = 'Ön cam içi (üst)',        kind = 'glass', facing = 0,      head = 'slim', n = 4, gap = 6.5},
  {id = 'dash',       tr = 'Torpido üstü',            kind = 'glass', facing = 0,      head = 'std',  n = 2, gap = 7},
  {id = 'grille',     tr = 'Ön panjur',               kind = 'face',  facing = 0,      head = 'std',  n = 1, gap = 7},
  {id = 'bumperF',    tr = 'Ön tampon',               kind = 'face',  facing = 0,      head = 'std',  n = 1, gap = 8},
  {id = 'hood',       tr = 'Kaput önü',               kind = 'top',   facing = 0,      head = 'slim', n = 1, gap = 7},
  {id = 'hideF',      tr = 'Far içi (hideaway)',      kind = 'face',  facing = 0,      head = 'round', n = 1, gap = 8},
  {id = 'mirrors',    tr = 'Yan aynalar',             kind = 'face',  facing = 0,      head = 'mini', n = 1, gap = 5},
  {id = 'sideF',      tr = 'Ön çamurluk (kavşak)',    kind = 'side',  facing = 'side', head = 'std',  n = 1, gap = 8},
  {id = 'skirt',      tr = 'Marşpiyel (yan)',         kind = 'side',  facing = 'side', head = 'std',  n = 2, gap = 60},
  {id = 'sideRear',   tr = 'Arka yan cam içi',        kind = 'side',  facing = 'side', head = 'slim', n = 1, gap = 7},
  {id = 'rearglass',  tr = 'Arka cam içi (üst)',      kind = 'glass', facing = 180,    head = 'slim', n = 3, gap = 6.5},
  {id = 'reardeck',   tr = 'Arka raf (cam altı)',     kind = 'glass', facing = 180,    head = 'wide', n = 2, gap = 9},
  {id = 'trunk',      tr = 'Bagaj kapağı (plaka yanı)', kind = 'face', facing = 180,   head = 'slim', n = 1, gap = 7},
  {id = 'bumperR',    tr = 'Arka tampon',             kind = 'face',  facing = 180,    head = 'std',  n = 1, gap = 8},
  {id = 'hideR',      tr = 'Stop içi (hideaway)',     kind = 'face',  facing = 180,    head = 'round', n = 1, gap = 8},
  {id = 'roof',       tr = 'Tavan',                   kind = 'top',   facing = 0,      head = 'std',  n = 2, gap = 20},
  {id = 'custom',     tr = 'Serbest (araç merkezine göre)', kind = 'free', facing = 0, head = 'std',  n = 1, gap = 7},
}
P.zoneById = {}
for _, z in ipairs(P.ZONES) do P.zoneById[z.id] = z end

-- fabrika (gelistirici) satirinda x'e gore ara deger; ikinci deger: x fabrika araliginin icinde mi
local function hintAt(H, u)
  local hs = H.heads
  local n = #hs
  local half = 0.5 * (H.pitch or 0.065)
  if n == 1 or u <= hs[1].x then return hs[1], (u >= hs[1].x - half) end
  if u >= hs[n].x then return hs[n], (u <= hs[n].x + half) end
  for i = 1, n - 1 do
    local a, b = hs[i], hs[i + 1]
    if u >= a.x and u <= b.x then
      local t = (b.x - a.x) > 1e-6 and (u - a.x) / (b.x - a.x) or 0
      return {x = u, y = a.y + t * (b.y - a.y), z = a.z + t * (b.z - a.z), yaw = a.yaw + t * (b.yaw - a.yaw),
              tilt = a.tilt + t * (b.tilt - a.tilt), roll = (a.roll or 0) + t * ((b.roll or 0) - (a.roll or 0))}, true
    end
  end
  return hs[n], false
end

local TOP_MOUNT = {windshield = true, rearglass = true, sideRear = true}
local BOTTOM_MOUNT = {dash = true, reardeck = true, hood = true, roof = true}
local SIDE_ROW = {sideRear = true, sideF = true, skirt = true}
local GLASS_TOP = {windshield = true, rearglass = true}

local sin, cos, rad = math.sin, math.cos, math.rad

-- fabrika basliginin merkezinden bizim basligin merkezine: on yuzler (lens duzlemi) ve dayanma yuzeyi cakisir
local function fitHint(zone, h, hd, dims)
  local out = {x = h.x, y = h.y, z = h.z, yaw = h.yaw, tilt = h.tilt or 0, roll = h.roll or 0}
  if hd then
    local df = (hd.d - dims.d) / 2
    local a = rad(out.yaw)
    out.x = out.x + sin(a) * df
    out.y = out.y - cos(a) * df
    if TOP_MOUNT[zone] then out.z = out.z + (hd.h - dims.h) / 2
    elseif BOTTOM_MOUNT[zone] then out.z = out.z - (hd.h - dims.h) / 2 end
  end
  return out
end
P.fitHint = fitHint

-- bolgenin varsayilan duzeni: adet, aralik (cm), ic mesafe (cm), baslik tipi, kaynak
-- w: secili baslik genisligi (m; aralik basliklarin ust uste binmeyecegi sekilde secilir)
function P.defaults(zone, env, w)
  local zd = P.zoneById[zone] or P.zoneById.custom
  local out = {n = zd.n, gap = zd.gap, x0 = 30, head = zd.head, src = 'approx'}
  local H = env and env.hints and env.hints[zone]
  local M = env and env.M
  local A = env and env.anchors and env.anchors[zone]
  if H and #H.heads > 0 then
    out.n = #H.heads
    out.gap = (H.pitch or (zd.gap / 100)) * 100
    out.head = H.head or zd.head
    out.x0 = H.heads[1].x * 100
    out.src = 'factory'
    out.part = H.part
    out.active = H.active
  elseif M and zone ~= 'custom' then
    local f = P.frames(M)[zone]
    if f then
      out.n = f.n or zd.n
      out.gap = (f.gap or zd.gap / 100) * 100
      out.head = f.unit or zd.head
      out.x0 = (f.x0 or 0.3) * 100
      out.src = 'scan'
    else
      out.src = false
    end
  elseif A then
    out.x0 = (A.x0 or 0.3) * 100
  elseif zone ~= 'custom' then
    out.src = false
  end
  if w and not SIDE_ROW[zone] and out.gap < (w - 0.0012) * 100 then out.gap = (w + 0.003) * 100 end
  out.gap, out.x0 = U.r(out.gap, 2), U.r(out.x0, 1)
  return out
end

-- hangi bolgeler bu aracta kullanilabilir: {id -> 'factory' | 'scan' | 'approx' | false}
function P.available(env)
  local out = {}
  local M = env and env.M
  local F = M and P.frames(M) or nil
  for _, z in ipairs(P.ZONES) do
    local id = z.id
    local v = false
    if env and env.hints and env.hints[id] then v = 'factory'
    elseif id == 'custom' then v = 'approx'
    elseif F then
      if F[id] then v = 'scan' end
    elseif env and env.anchors and env.anchors[id] then v = 'approx' end
    out[id] = v
  end
  return out
end

-- o: dizi ogesi (config.lua), env: {M, hints, anchors}, dims: {w, h, d} (m)
-- Doner: {L = {baslik...}, R = {...} | nil, src = 'factory' | 'scan' | 'approx', gap, x0}
--   baslik: {x, y, z, yaw, tilt, roll, src, tri}
function P.layout(o, env, dims)
  local zone = o.anchor
  local zd = P.zoneById[zone] or P.zoneById.custom
  local M = env.M
  local H = env.hints and env.hints[zone]
  local A = env.anchors and env.anchors[zone]
  if o.src == 'scan' then H = nil end
  if o.src == 'approx' then H, M = nil, nil end
  local F = M and P.frames(M) or nil
  local f = F and F[zone] or nil
  local sideRow = SIDE_ROW[zone]
  local def = P.defaults(zone, {hints = H and env.hints or nil, M = M, anchors = env.anchors}, dims.w)
  local gap = ((o.gap or -1) > 0 and o.gap or def.gap) / 100
  local n = o.n or 1
  local x0 = ((o.x0 or -1) >= 0 and o.x0 or def.x0) / 100
  local res = {src = 'approx', gap = gap * 100, x0 = x0 * 100}
  local facing = o.facing
  if facing == nil or facing == -999 then facing = zd.facing end
  local offX, offY, offZ = (o.x or 0) / 100, (o.y or 0) / 100, (o.z or 0) / 100
  local dirx = (o.dirx == -1) and -1 or 1
  local q = {sink = ((o.sink or -1) >= 0) and (o.sink / 100) or nil, follow = (o.follow == 0) and 0 or nil, followTilt = (o.ftilt == 1) and 1 or nil}
  if GLASS_TOP[zone] then
    if offZ < 0 then q.drop = -offZ end
  else
    q.dz = offZ
  end

  -- fabrika satiri ile tarama arasindaki fark (fabrika araliginin disindaki basliklar taramayla, ayni farkla yerlesir)
  local delta
  local function scanDelta()
    if delta ~= nil then return delta end
    delta = false
    if H and M and not sideRow then
      local sy, sz, c = 0, 0, 0
      for _, h in ipairs(H.heads) do
        local hp = fitHint(zone, h, H.dims, dims)
        local okP, p = pcall(P.head, M, zone, 1, h.x, dims, {sink = q.sink, follow = 0, zAbs = (zd.kind == 'face') and hp.z or nil})
        if okP and p then sy, sz, c = sy + (hp.y - p.y), sz + (hp.z - p.z), c + 1 end
      end
      if c > 0 then delta = {y = sy / c, z = sz / c} end
    end
    return delta
  end

  local function solve(side, k)
    local u, yRow
    local zStack = 0
    if sideRow then
      local yc = (f and f.y) or (A and A.y) or 0
      yRow = yc + (k - (n + 1) / 2) * gap + offY
      u = x0
    elseif o.axis == 'y' then
      u = x0 + offX
    elseif o.axis == 'z' then
      u = x0 + offX
      zStack = (k - 1) * gap
    else
      u = x0 + dirx * (k - 1) * gap + offX
    end
    if u < 0 then u = 0 end
    local p, src
    if H and #H.heads > 0 and not sideRow then
      local h, inside = hintAt(H, u)
      if inside or not M then
        p = fitHint(zone, h, H.dims, dims)
        p.x = side * u + (p.x - h.x) * side
        p.z = p.z + offZ + zStack
        if side < 0 then p.yaw = -p.yaw end
        src = 'factory'
      else
        local d = scanDelta()
        local hp = fitHint(zone, h, H.dims, dims)
        local qq = {sink = q.sink, follow = q.follow, followTilt = q.followTilt, drop = q.drop, dz = (q.dz or 0) + zStack,
                    zAbs = (zd.kind == 'face') and hp.z or nil}
        local okP, pp = pcall(P.head, M, zone, side, u, dims, qq)
        if okP and pp then
          p = pp
          if d then p.y, p.z = p.y + d.y, p.z + d.z end
          if GLASS_TOP[zone] and offZ > 0 then p.z = p.z + offZ end
          src = 'factory'
        end
      end
    end
    if not p and M and zone ~= 'custom' then
      local qq = {sink = q.sink, follow = q.follow, followTilt = q.followTilt, drop = q.drop, dz = (q.dz or 0) + zStack, y = yRow}
      local okP, pp = pcall(P.head, M, zone, side, u, dims, qq)
      if okP and pp then
        p = pp
        src = 'scan'
        if (GLASS_TOP[zone] and offZ > 0) or zone == 'dash' or zone == 'reardeck' or zone == 'hood' or zone == 'roof' then
          if not (GLASS_TOP[zone] and offZ <= 0) then p.z = p.z + offZ end
        end
      end
    end
    if not p then
      -- yuzey modeli varken cozulemeyen baslik yerlestirilmez (bu aracta o bolge yok: ornek, camsiz arac);
      -- model hic okunamadiysa dugum bulutundan yaklasik konum kullanilir
      if zone ~= 'custom' and (M or not A) then return nil end
      local ay, az = (A and A.y) or 0, (A and A.z) or 1
      if zone == 'custom' then ay, az = 0, 0 end
      local yy = ay
      if A and A.curve and not sideRow then yy = yy + max(0, abs(u) - 0.46) * A.curve end
      if sideRow then yy = (A and A.y or 0) + (k - (n + 1) / 2) * gap + offY end
      local yaw = (facing == 'side') and (side * 90) or (tonumber(facing) or 0)
      p = {x = side * u, y = yy, z = az + offZ + zStack, yaw = yaw, tilt = 0}
      src = 'approx'
    end
    -- kullanici: derinlik / boyuna kaydirma
    if sideRow then
      p.x = p.x + side * offX
    else
      p.y = p.y + offY
      if o.axis == 'y' then p.y = p.y + (k - (n + 1) / 2) * gap end
    end
    -- ust yuzey / serbest bolgelerde bakis yonu secilebilir
    if (zd.kind == 'top' or zd.kind == 'free') and src ~= 'factory' then
      p.yaw = (facing == 'side') and (side * 90) or (tonumber(facing) or 0)
    end
    -- kullanici acilari (iki yanda simetrik)
    local uy = o.yaw or 0
    if uy ~= 0 then
      if o.mirror == false then p.yaw = p.yaw + uy
      else
        local a = ((p.yaw + 180) % 360) - 180
        local isSide = abs(abs(a) - 90) < 30
        local isRear = abs(a) > 120
        if isSide then p.yaw = p.yaw - side * uy
        else p.yaw = p.yaw + side * (isRear and -1 or 1) * uy end
      end
    end
    p.tilt = (p.tilt or 0) + (o.tilt or 0)
    p.roll = p.roll or 0
    p.src = src
    return p
  end

  local sides = (o.mirror == false) and {1} or {1, -1}
  local out = {}
  local srcCount = {}
  local missing = 0
  for _, side in ipairs(sides) do
    local list = {}
    for k = 1, n do
      local p = solve(side, k)
      if p then
        list[#list + 1] = p
        srcCount[p.src] = (srcCount[p.src] or 0) + 1
      else
        missing = missing + 1
      end
    end
    out[side] = list
  end
  res.missing = missing
  -- iki yanda ayni sayida baslik kalsin (simetri)
  if out[1] and out[-1] and #out[1] ~= #out[-1] then
    local m2 = min(#out[1], #out[-1])
    for _, side in ipairs(sides) do
      while #out[side] > m2 do table.remove(out[side]) end
    end
  end
  n = (out[1] and #out[1]) or 0
  if n == 0 then
    res.L, res.R, res.n, res.none = {}, (out[-1] and {} or nil), 0, true
    res.src = 'none'
    return res
  end
  -- simetri: iki yan arasindaki kucuk tarama farklarini ortala
  if out[1] and out[-1] then
    for k = 1, n do
      local a, b = out[1][k], out[-1][k]
      if a and b and a.src == b.src and a.src ~= 'factory' and abs(a.y - b.y) < 0.03 and abs(a.z - b.z) < 0.03 and abs(a.x + b.x) < 0.03 then
        local y, z, x = (a.y + b.y) / 2, (a.z + b.z) / 2, (a.x - b.x) / 2
        a.y, b.y, a.z, b.z, a.x, b.x = y, y, z, z, x, -x
        local t = (a.tilt + b.tilt) / 2
        a.tilt, b.tilt = t, t
        local ya = ((a.yaw + 180) % 360) - 180
        local yb = ((-b.yaw + 180) % 360) - 180
        if abs(ya - yb) < 12 then
          local ym = (ya + yb) / 2
          a.yaw, b.yaw = ym, -ym
        end
      end
    end
  end
  -- sira duzgunlugu: tarama basliklari arasindaki 6 mm'den kucuk dalgalanmalari duzelt
  for _, side in ipairs(sides) do
    local list = out[side]
    if n >= 2 and not sideRow and o.axis == 'x' then
      for _, key in ipairs({'y', 'z'}) do
        local lo, hi, sum = huge, -huge, 0
        for k = 1, n do
          local v = list[k][key]
          lo, hi, sum = min(lo, v), max(hi, v), sum + v
        end
        if hi - lo < 0.006 then
          for k = 1, n do list[k][key] = sum / n end
        end
      end
    end
  end
  res.L, res.R = out[1], out[-1]
  res.src = (srcCount.factory and 'factory') or (srcCount.scan and 'scan') or 'approx'
  res.mixed = (srcCount.approx and (srcCount.factory or srcCount.scan)) and true or false
  res.n = n
  return res
end

return P
