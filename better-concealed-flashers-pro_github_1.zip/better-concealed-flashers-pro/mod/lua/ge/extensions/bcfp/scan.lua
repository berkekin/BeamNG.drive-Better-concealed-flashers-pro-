-- Better Concealed Flashers PRO 3 - yuzey tarayici
-- Aracin o an takili govde parcalarinin gercek 3B modellerini (.dae) okur, ucgenleri siniflandirir
-- (govde / cam / lamba / ic mekan) ve eksenlere paralel isinlarla yuzey sorgulari yapar. Montaj cozuculeri
-- (place.lua) bu sorgularla cakarlari camin icine, panjura, tampona ... tam oturtur.
-- Koordinatlar arac uzayi: +x sol, +y geri (on = -y), +z yukari, metre.
local S = {}
local U, D

local min, max, abs, floor, sqrt, huge = math.min, math.max, math.abs, math.floor, math.sqrt, math.huge
local find, lower = string.find, string.lower

function S.init(mods) U, D = mods.U, mods.D end

-- ucgen siniflari
local SKIP, BODY, GLASS, LAMP, INTERIOR, EQUIP, PLATE = 0, 1, 2, 3, 4, 5, 6
S.SKIP, S.BODY, S.GLASS, S.LAMP, S.INTERIOR, S.EQUIP, S.PLATE = SKIP, BODY, GLASS, LAMP, INTERIOR, EQUIP, PLATE
-- maskeler (sinif -> true)
S.M_EXT = {[BODY] = true, [GLASS] = true, [LAMP] = true}
S.M_SOLID = {[BODY] = true, [INTERIOR] = true}
S.M_BODY = {[BODY] = true}
S.M_ALL = {[BODY] = true, [GLASS] = true, [LAMP] = true, [INTERIOR] = true}

S.SLAB = 0.04
S.MAX_TRIS = 1600000
S.MAX_FILE = 700 * 1024 * 1024

-----------------------------------------------------------------------------------------------
-- siniflandirma (mesh / materyal adlarindan)
-----------------------------------------------------------------------------------------------
local function splitTokens(s)
  local t = {}
  for w in s:gmatch('[%a%d]+') do t[w] = true end
  return t
end

-- uzun kelimeler: alt dize; kisa kelimeler: tam belirtec (ya da sonunda rakam / s)
local function hasAny(s, toks, longs, shorts)
  if longs then
    for i = 1, #longs do
      if find(s, longs[i], 1, true) then return longs[i] end
    end
  end
  if shorts then
    for i = 1, #shorts do
      local w = shorts[i]
      if toks[w] or toks[w .. 's'] then return w end
    end
  end
  return nil
end

local EQUIP_L = {'lightbar', 'light_bar', 'beacon', 'flasher', 'siren', 'strobe', 'spotlight', 'searchlight', 'search_light',
  'roofrack', 'roof_rack', 'roofbar', 'roofbasket', 'roof_basket', 'antenna', 'aerial', 'pushbar', 'push_bar', 'bullbar',
  'bull_bar', 'winch', 'snorkel', 'ladder', 'taxisign', 'taxi_sign', 'wigwag', 'bcfp_', 'lightrack', 'brushguard',
  'grilleguard', 'grille_guard', 'nudgebar', 'rollbar', 'roll_bar', 'sportbar', 'lightpod', 'light_pod', 'rallylight',
  'cargobox', 'cargo_box', 'kayak', 'bikerack', 'awning', 'towhitch', 'tow_hitch', 'trailerhitch'}
local EQUIP_S = {'uel', 'hitch', 'rack'}
local PLATE_L = {'licenseplate', 'license_plate', 'numberplate', 'number_plate'}
local LAMP_L = {'headlight', 'taillight', 'foglight', 'brakelight', 'brake_light', 'reverselight', 'turnlight', 'parklight',
  'indicator', 'blinker', 'headlamp', 'taillamp', 'foglamp', 'chmsl', 'sidemarker', 'side_marker', 'turnsignal',
  'turn_signal', 'runninglight', 'daylight', 'popup_light', 'cornerlight', 'corner_light', 'signal_', '_signal', 'marker_light'}
local LAMP_S = {'light', 'lamp', 'tsl', 'drl', 'marker', 'signal', 'reflector'}
local SKIP_L = {'wheel', 'tyre', 'brake', 'caliper', 'hubcap', 'suspension', 'strut', 'shock', 'coilover', 'swaybar', 'tierod',
  'halfshaft', 'driveshaft', 'subframe', 'lowerarm', 'upperarm', 'wishbone', 'engine', 'transmission', 'gearbox',
  'transfercase', 'transfer_case', 'differential', 'exhaust', 'muffler', 'manifold', 'radiator', 'radhose', 'intercooler',
  'fueltank', 'fuel_tank', 'steeringbox', 'steering_box', 'steering_rack', 'character', 'occupant', 'undertray', 'skidplate',
  'skid_plate', 'fenderliner', 'engbay', 'enginebay', 'floorpan', 'supercharger', 'turbocharger', 'oilpan', 'leafspring',
  'monoleaf', 'flywheel', 'alternator', 'battery', 'airbox', 'airfilter', '_dmg', 'catalytic', 'downpipe', 'oilcooler',
  'trailingarm', 'knuckle', 'spindle', 'control_arm', 'controlarm', 'torsion', 'wiper', 'badge', 'emblem', 'lettering',
  'mudflap', 'mud_flap', 'hinge', 'gasstrut', 'wiring', 'coolant', 'crossmember', 'driveline', 'sparewheel', 'jato',
  'nitrous', 'ballast', 'cargo_load', 'payload', 'trailer_', 'fifthwheel', 'license_frame', 'dummy', 'collision',
  'intake', 'fusebox', 'reservoir', 'expansiontank', 'compressor', 'condenser', 'carburetor', 'throttle', 'valvecover',
  'strutbar', 'strut_bar', 'powersteering', 'masterbrake', 'mastercyl', 'washerbottle', 'washer_bottle', 'heatshield', 'jack'}
local SKIP_S = {'tire', 'hub', 'axle', 'diff', 'spring', 'rotor', 'disc', 'leaf', 'logo', 'decal', 'hose', 'wire', 'pipe',
  'n2o', 'hubs', 'pedal', 'col', 'lod', 'ecu', 'abs', 'header', 'headers', 'carb', 'pulley', 'fan'}
local INT_L = {'interior', 'dashboard', 'headliner', 'sunvisor', 'sun_visor', 'doorpanel', 'door_panel', 'doorcard', 'carpet',
  'steering', 'gauge', 'shifter', 'headunit', 'stereo', 'seatbelt', 'rollcage', 'roll_cage', 'partition', 'laptop', 'glovebox',
  'cluster', 'console', 'handbrake', 'parkingbrake', 'armrest', 'headrest', 'center_mirror', 'centermirror', 'rearview',
  'rear_view', 'infotainment', 'speaker', 'airbag', 'floormat', 'cargo_cover', 'cargocover', 'parcel', 'hatshelf',
  'rearshelf', 'rear_shelf', 'backseat', 'pillar_trim', 'pillartrim', 'innerpanel', 'inner_panel', 'firewall', 'cabfloor',
  'tachometer', 'speedometer', 'radar', 'panel_bare', 'cupholder', 'ashtray'}
local INT_S = {'dash', 'seat', 'bench', 'cage', 'navi', 'screen', 'radio', 'int', 'cabin', 'mirror_int', 'belt', 'belts', 'trimint'}
local GLASS_L = {'glass', 'window', 'windshield', 'windscreen', 'backlight', 'quarterlight', 'sunroof', 'moonroof'}
local NOGLASS_L = {'fiberglass', 'fibreglass', 'glassfiber', 'windowtrim', 'window_trim', 'window_frame', 'windowframe',
  'windshield_frame', 'windshieldframe', 'window_seal', 'gauges_glass', 'glassframe', 'glass_frame', 'window_switch',
  'windowswitch', 'window_crank', 'louver', 'louvre'}

local TAGS = {
  {'grille', {'grille', 'grill'}},
  {'bumper', {'bumper', 'nosecone', 'valance', 'fascia', 'lip_f', 'frontlip', 'front_lip', 'splitter', 'diffuser'}},
  {'hood', {'hood', 'bonnet'}},
  {'trunk', {'trunk', 'tailgate', 'liftgate', 'decklid', 'bootlid', 'hatch', 'reardoor', 'rear_door', 'barndoor'}},
  {'mirror', {'mirror'}},
  {'roof', {'roof', 'hardtop', 'softtop'}},
  {'door', {'door'}},
  {'fender', {'fender', 'quarter', 'wing_f'}},
  {'spoiler', {'spoiler'}},
  {'skirt', {'sideskirt', 'side_skirt', 'rocker', 'sill'}},
  {'headlight', {'headlight', 'headlamp', 'popup_light'}},
  {'taillight', {'taillight', 'taillamp'}},
  {'foglight', {'foglight', 'foglamp'}},
  {'chmsl', {'chmsl', 'brakelight', 'brake_light'}},
  {'body', {'body', 'shell', 'unibody', 'cab'}},
}

-- "...light" / "...lamp" ile biten belirtecler lambadir (trunklight, bumperlight ...); cam adlari haric
local WINDOW_LIGHT = {backlight = true, quarterlight = true, skylight = true, sidelight = true, ventlight = true}
local function lightToken(toks)
  for w in pairs(toks) do
    if #w > 5 and not WINDOW_LIGHT[w] then
      if w:sub(-5) == 'light' or w:sub(-6) == 'lights' or w:sub(-4) == 'lamp' or w:sub(-5) == 'lamps' then return true end
    end
  end
  return false
end

-- mesh adi (+ model oneki) -> sinif, etiket
function S.classify(meshName, model)
  local s = lower(meshName or '')
  if model and model ~= '' then
    local m = lower(model)
    if s:sub(1, #m + 1) == m .. '_' then s = s:sub(#m + 2) end
  end
  local toks = splitTokens(s)
  local cls
  if hasAny(s, toks, PLATE_L) then cls = PLATE
  elseif hasAny(s, toks, EQUIP_L, EQUIP_S) then cls = EQUIP
  elseif hasAny(s, toks, LAMP_L, LAMP_S) or lightToken(toks) then cls = LAMP
  elseif hasAny(s, toks, SKIP_L, SKIP_S) then cls = SKIP
  elseif hasAny(s, toks, GLASS_L) and not hasAny(s, toks, NOGLASS_L) then cls = GLASS
  elseif hasAny(s, toks, INT_L, INT_S) then cls = INTERIOR
  else cls = BODY end
  local tag
  for i = 1, #TAGS do
    local words = TAGS[i][2]
    for j = 1, #words do
      if find(s, words[j], 1, true) then tag = TAGS[i][1] break end
    end
    if tag then break end
  end
  return cls, tag, s
end

-- materyal tanimlarindan cam / lamba bilgisi: adlari bir sey soylemeyen modeller icin (ornek: Automation / CAMSO
-- disa aktarimlari "material_4_<arac>_body0" gibi adlar kullanir; cam, "glass_base" yansima haritasindan anlasilir)
local matCache = {}

local function flatText(v, out, depth)
  if depth > 6 then return end
  if type(v) == 'table' then
    for k, x in pairs(v) do
      if x == true then out[#out + 1] = tostring(k) .. '=true'
      elseif type(x) == 'string' then out[#out + 1] = tostring(k) .. '=' .. x
      elseif type(x) == 'number' then out[#out + 1] = tostring(x)
      elseif type(x) == 'table' then
        if type(k) == 'string' then out[#out + 1] = k end
        flatText(x, out, depth + 1)
      end
    end
  end
end

local function matKind(name, txt, defs)
  local ln = lower(name)
  if ln:find('_on$') or ln:find('_off$') or ln:find('_onintense$') or defs[name .. '_on'] or defs[name .. '_off'] then return 'lamp' end
  if find(txt, 'glowmap', 1, true) or find(txt, 'glow=true', 1, true) or txt:find('glow%[%d%]%s*=%s*"?1') or txt:find('glow%s*=%s*"?true') then
    return 'lamp'
  end
  if find(txt, 'glass_base', 1, true) or find(txt, 'windshield', 1, true) or find(txt, 'windscreen', 1, true) then return 'glass' end
  -- "..._GlassReflectivityMap0.dds" gibi: cam adi gecen, saydam ve lamba olmayan materyal
  local translucent = txt:find('translucent%s*=%s*"?[1t]') ~= nil
  if translucent and find(txt, 'glass', 1, true) then return 'glass' end
  -- Automation (CAMSO) disa aktarimlarinin cam rengi (0.0039, 0.102, 0.086): adinda / dokusunda "glass" gecmeyen surumler
  if translucent and find(txt, '0.101961', 1, true) and find(txt, '0.0862745', 1, true) then return 'glass' end
  return nil
end

function S.matInfo(dirs)
  local info = {}
  for _, dir in ipairs(dirs or {}) do
    if type(dir) == 'string' and not dir:find('/vehicles/common/?$') then
      local c = matCache[dir]
      if not c then
        c = {}
        local defs = {}
        local ok, files = pcall(function() return FS:findFiles(dir, '*.json\t*.cs', -1, true, false) end)
        for _, f in ipairs((ok and type(files) == 'table') and files or {}) do
          local lf = lower(f)
          if lf:find('materials%.json$') then
            local okJ, d = pcall(jsonReadFile, f)
            if okJ and type(d) == 'table' then
              for name, def in pairs(d) do
                if type(name) == 'string' and type(def) == 'table' then
                  local out = {}
                  flatText(def, out, 0)
                  defs[name] = lower(table.concat(out, ' '))
                end
              end
            end
          elseif lf:find('%.cs$') then
            local okR, src = pcall(readFile, f)
            if okR and type(src) == 'string' and #src < 8000000 then
              for name, body in src:gmatch('[Mm]aterial%s*%(%s*"?([%w_%.%-]+)"?%s*%)%s*(%b{})') do defs[name] = lower(body) end
            end
          end
        end
        for name, txt in pairs(defs) do
          local k = matKind(name, txt, defs)
          if k then c[lower(name)] = k end
        end
        matCache[dir] = c
      end
      for k, v in pairs(c) do info[k] = v end
    end
  end
  return info
end

-- materyal adina gore sinif duzeltmesi (cok materyalli govde modelleri)
local function classForMaterial(cls, meshLower, mat, minfo)
  if cls ~= BODY and cls ~= GLASS and cls ~= INTERIOR then return cls end
  local m = lower(mat or '')
  if m == '' then return cls end
  local mk = minfo and minfo[m]
  if mk == 'glass' then return GLASS end
  if mk == 'lamp' and cls == BODY then return LAMP end
  if m == 'invis' or find(m, 'invisible', 1, true) or find(m, 'collision', 1, true) then return SKIP end
  local glassy = (find(m, 'glass', 1, true) or find(m, 'window', 1, true) or find(m, 'windshield', 1, true) or find(m, 'windscreen', 1, true))
    and not (find(m, 'fiberglass', 1, true) or find(m, 'light', 1, true) or find(m, 'lamp', 1, true) or find(m, 'gauge', 1, true)
      or find(m, 'mirror', 1, true) or find(m, 'lens', 1, true) or find(m, 'signal', 1, true) or find(m, 'screen', 1, true))
  if cls == BODY and glassy then return GLASS end
  if cls == GLASS and not glassy then
    -- cam modelinin cam olmayan materyali (cerceve, fitil): govde say
    if find(m, 'trim', 1, true) or find(m, 'rubber', 1, true) or find(m, 'seal', 1, true) or find(m, 'frame', 1, true)
      or find(m, 'chrome', 1, true) or find(m, 'plastic', 1, true) or find(m, 'metal', 1, true) then return BODY end
  end
  if cls == BODY and (find(m, 'interior', 1, true) or find(m, 'carpet', 1, true) or find(m, 'headliner', 1, true)) then return INTERIOR end
  return cls
end

-----------------------------------------------------------------------------------------------
-- dondurme (oyunun flexbody euler sirasi: +Z +X +Y icsel, derece)
-----------------------------------------------------------------------------------------------
local function eulerZXY(rx, ry, rz)
  local a, b, c = math.rad(rx or 0), math.rad(ry or 0), math.rad(rz or 0)
  local cx, sx, cy, sy, cz, sz = math.cos(a), math.sin(a), math.cos(b), math.sin(b), math.cos(c), math.sin(c)
  -- R = Rz * Rx * Ry
  return cz * cy - sz * sx * sy, -sz * cx, cz * sy + sz * sx * cy,
         sz * cy + cz * sx * sy, cz * cx, sz * sy - cz * sx * cy,
         -cx * sy, sx, cx * cy
end
S.eulerZXY = eulerZXY

local function num(v, d)
  v = tonumber(v)
  if v == nil or v ~= v then return d end
  return v
end

-----------------------------------------------------------------------------------------------
-- dosya erisimi
-----------------------------------------------------------------------------------------------
local function listDae(dir)
  local out = {}
  local seen = {}
  local ok, files = pcall(function() return FS:findFiles(dir, '*.dae\t*.DAE\t*.Dae', -1, true, false) end)
  if ok and type(files) == 'table' then
    for _, f in ipairs(files) do
      if not seen[f] then seen[f] = true; out[#out + 1] = f end
    end
  end
  return out
end

local function fileSize(f)
  local sz
  pcall(function()
    local st = FS:stat(f)
    if st and st.filesize then sz = st.filesize end
  end)
  return sz
end

-- klasor -> {dosya -> {mesh adlari}} dizini (bellek ici); dosya boyutu degisirse yenilenir
local dirIndex = {}

function S.invalidate()
  dirIndex = {}
  matCache = {}
  S.models = {}
  S.order = {}
end

S.models = {}   -- imza -> model (son kullanilanlar)
S.order = {}
S.KEEP = 3

-----------------------------------------------------------------------------------------------
-- model kurulumu
-----------------------------------------------------------------------------------------------
local Model = {}
Model.__index = Model

-- flex: {{mesh=, pos=, rot=, scale=, part=}}, dirs: arac klasorleri, model: arac modeli adi
-- reader(path) -> icerik (test icin degistirilebilir)
function S.signature(flex, dirs)
  local parts = {}
  for i, f in ipairs(flex) do
    local p, r, sc = f.pos, f.rot, f.scale
    parts[i] = table.concat({tostring(f.mesh), p and p.x or 0, p and p.y or 0, p and p.z or 0, r and r.x or 0, r and r.y or 0, r and r.z or 0,
      sc and sc.x or 1, sc and sc.y or 1, sc and sc.z or 1}, ',')
  end
  table.sort(parts)
  return table.concat(dirs or {}, ';') .. '|' .. table.concat(parts, '|')
end

local function addTri(M, x1, y1, z1, x2, y2, z2, x3, y3, z3, cls, mi)
  -- dejenere ucgenleri at
  local ux, uy, uz = x2 - x1, y2 - y1, z2 - z1
  local vx, vy, vz = x3 - x1, y3 - y1, z3 - z1
  local nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
  local l2 = nx * nx + ny * ny + nz * nz
  if l2 < 1e-16 then return end
  local n = M.nt
  local o = n * 9
  local T = M.T
  T[o + 1], T[o + 2], T[o + 3], T[o + 4], T[o + 5], T[o + 6], T[o + 7], T[o + 8], T[o + 9] = x1, y1, z1, x2, y2, z2, x3, y3, z3
  M.C[n + 1] = cls
  M.MI[n + 1] = mi
  M.nt = n + 1
end

function S.build(flex, dirs, modelName, opts)
  opts = opts or {}
  local reader = opts.reader or readFile
  local t0 = os.clock()
  local M = setmetatable({T = {}, C = {}, MI = {}, nt = 0, meshes = {}, model = modelName, warnings = {}, stats = {}}, Model)
  -- gereken mesh adlari
  local need, needCount = {}, 0
  local entries = {}
  for _, f in ipairs(flex or {}) do
    local name = f.mesh
    if type(name) == 'string' and name ~= '' and name ~= 'SPOTLIGHT' and name ~= 'POINTLIGHT' then
      local cls, tag, low = S.classify(name, modelName)
      local e = {mesh = name, cls = cls, tag = tag, low = low, pos = f.pos, rot = f.rot, scale = f.scale, part = f.part, groups = f.groups, dg = f.dg}
      entries[#entries + 1] = e
      if cls ~= SKIP and cls ~= EQUIP and not need[name] then
        need[name] = true
        needCount = needCount + 1
      end
    end
  end
  M.stats.flex = #entries
  M.stats.need = needCount
  -- DAE dosyalari: aracin kendi klasorleri (ortak klasor taranmaz: tekerlek / aksesuar)
  local geoms = {}
  local files = {}
  for _, dir in ipairs(dirs or {}) do
    if type(dir) == 'string' and not dir:find('/vehicles/common/?$') then
      local idx = dirIndex[dir]
      local list = listDae(dir)
      if not idx then
        idx = {files = {}}
        dirIndex[dir] = idx
      end
      -- ana model dosyasi once (<model>.dae), sonra buyukten kucuge
      local sized = {}
      for _, f in ipairs(list) do sized[#sized + 1] = {f = f, sz = fileSize(f) or 0} end
      local mainName = modelName and ('/' .. lower(modelName) .. '.dae') or nil
      table.sort(sized, function(a, b)
        local am = mainName and lower(a.f):sub(-#mainName) == mainName
        local bm = mainName and lower(b.f):sub(-#mainName) == mainName
        if am ~= bm then return am end
        if a.sz ~= b.sz then return a.sz > b.sz end
        return a.f < b.f
      end)
      for _, it in ipairs(sized) do files[#files + 1] = {f = it.f, sz = it.sz, idx = idx} end
    end
  end
  M.stats.files = #files
  local filesRead = 0
  for _, it in ipairs(files) do
    if needCount <= 0 then break end
    local known = it.idx.files[it.f]
    local wanted = true
    if known and known.sz == it.sz then
      wanted = false
      for name in pairs(need) do
        if known.names[name] then wanted = true break end
      end
    end
    if wanted then
      if it.sz > S.MAX_FILE then
        M.warnings[#M.warnings + 1] = {k = 'bigFile', v = it.f}
      else
        local okR, src = pcall(reader, it.f)
        if okR and type(src) == 'string' then
          filesRead = filesRead + 1
          local d = D.open(it.f, src)
          if d then
            if not (known and known.sz == it.sz) then
              local names = {}
              for name in pairs(d.nodes) do names[name] = true end
              it.idx.files[it.f] = {sz = it.sz, names = names}
            end
            for name in pairs(need) do
              if d.nodes[name] then
                local okM, g = pcall(D.mesh, d, name, 600000)
                if okM and g then geoms[name] = g end
                need[name] = nil
                needCount = needCount - 1
              end
            end
            d.s = nil
          end
          src = nil
        end
      end
    end
  end
  M.stats.filesRead = filesRead
  M.stats.missing = needCount
  local okMI, minfo = pcall(S.matInfo, dirs)
  if not okMI then minfo = nil end
  -- ucgen corbasi
  local T = M.T
  local x0, y0, z0, x1, y1, z1 = huge, huge, huge, -huge, -huge, -huge
  for _, e in ipairs(entries) do
    local g = geoms[e.mesh]
    if g and M.nt < S.MAX_TRIS then
      local V = g.verts
      local px, py, pz = 0, 0, 0
      local sx, sy, sz = 1, 1, 1
      local r11, r12, r13, r21, r22, r23, r31, r32, r33
      local hasRot = false
      if type(e.scale) == 'table' then sx, sy, sz = num(e.scale.x, 1), num(e.scale.y, 1), num(e.scale.z, 1) end
      if type(e.rot) == 'table' then
        local rx, ry, rz = num(e.rot.x, 0), num(e.rot.y, 0), num(e.rot.z, 0)
        if rx ~= 0 or ry ~= 0 or rz ~= 0 then
          hasRot = true
          r11, r12, r13, r21, r22, r23, r31, r32, r33 = eulerZXY(rx, ry, rz)
        end
      end
      if type(e.pos) == 'table' then px, py, pz = num(e.pos.x, 0), num(e.pos.y, 0), num(e.pos.z, 0) end
      local simple = (not hasRot) and sx == 1 and sy == 1 and sz == 1 and px == 0 and py == 0 and pz == 0
      local W = V
      if not simple then
        W = {}
        for k = 0, g.nv - 1 do
          local o = k * 3
          local x, y, z = V[o + 1] * sx, V[o + 2] * sy, V[o + 3] * sz
          if hasRot then
            x, y, z = r11 * x + r12 * y + r13 * z, r21 * x + r22 * y + r23 * z, r31 * x + r32 * y + r33 * z
          end
          W[o + 1], W[o + 2], W[o + 3] = x + px, y + py, z + pz
        end
      end
      local mi = #M.meshes + 1
      local mb = {huge, huge, huge, -huge, -huge, -huge}
      local before = M.nt
      for _, pr in ipairs(g.prims) do
        local cls = classForMaterial(e.cls, e.low, pr.mat, minfo)
        if cls ~= SKIP and cls ~= EQUIP then
          local idx = pr.idx
          for q = 1, pr.nt * 3, 3 do
            local a, b, c = idx[q] * 3, idx[q + 1] * 3, idx[q + 2] * 3
            local ax, ay, az = W[a + 1], W[a + 2], W[a + 3]
            local bx, by, bz = W[b + 1], W[b + 2], W[b + 3]
            local cx, cy, cz = W[c + 1], W[c + 2], W[c + 3]
            if ax and bx and cx then
              addTri(M, ax, ay, az, bx, by, bz, cx, cy, cz, cls, mi)
            end
          end
        end
      end
      -- mesh sinir kutusu
      for k = before, M.nt - 1 do
        local o = k * 9
        for v = 0, 2 do
          local x, y, z = T[o + v * 3 + 1], T[o + v * 3 + 2], T[o + v * 3 + 3]
          if x < mb[1] then mb[1] = x end
          if y < mb[2] then mb[2] = y end
          if z < mb[3] then mb[3] = z end
          if x > mb[4] then mb[4] = x end
          if y > mb[5] then mb[5] = y end
          if z > mb[6] then mb[6] = z end
        end
      end
      M.meshes[mi] = {name = e.mesh, cls = e.cls, tag = e.tag, part = e.part, bbox = mb, t0 = before + 1, t1 = M.nt, groups = e.groups, dg = e.dg}
      if e.cls == BODY and M.nt > before then
        x0, y0, z0 = min(x0, mb[1]), min(y0, mb[2]), min(z0, mb[3])
        x1, y1, z1 = max(x1, mb[4]), max(y1, mb[5]), max(z1, mb[6])
      end
    elseif e.cls == PLATE or e.cls == EQUIP then
      -- konumu bilinen aksesuarlar (plaka, tepe lambasi ...): yalnizca yer bilgisi
      if type(e.pos) == 'table' then
        M.meshes[#M.meshes + 1] = {name = e.mesh, cls = e.cls, tag = e.tag, part = e.part, pos = {num(e.pos.x, 0), num(e.pos.y, 0), num(e.pos.z, 0)},
          rot = e.rot, t0 = 1, t1 = 0}
      end
    end
  end
  if M.nt == 0 or x0 > x1 then
    return nil, 'govde modeli okunamadi (' .. tostring(M.stats.missing) .. ' eksik)'
  end
  M.bbox = {x0, y0, z0, x1, y1, z1}
  M:buildSlabs()
  M:findGlass()
  M:findLandmarks()
  M.stats.tris = M.nt
  M.stats.time = os.clock() - t0
  return M
end

-- onbellekli kurulum
function S.get(flex, dirs, modelName, opts)
  local sig = S.signature(flex, dirs)
  local M = S.models[sig]
  if M then return M, true end
  local err
  M, err = S.build(flex, dirs, modelName, opts)
  if not M then return nil, err end
  M.sig = sig
  S.models[sig] = M
  table.insert(S.order, 1, sig)
  while #S.order > S.KEEP do
    local old = table.remove(S.order)
    S.models[old] = nil
  end
  return M, false
end

-----------------------------------------------------------------------------------------------
-- dilim dizinleri: x dilimleri (y ve z yonlu isinlar, x kesitleri), z dilimleri (x yonlu isinlar)
-----------------------------------------------------------------------------------------------
function Model:buildSlabs()
  local T, nt = self.T, self.nt
  local w = S.SLAB
  local bx0, bz0 = huge, huge
  for k = 0, nt - 1 do
    local o = k * 9
    local a, b, c = T[o + 1], T[o + 4], T[o + 7]
    if a < bx0 then bx0 = a end
    if b < bx0 then bx0 = b end
    if c < bx0 then bx0 = c end
    a, b, c = T[o + 3], T[o + 6], T[o + 9]
    if a < bz0 then bz0 = a end
    if b < bz0 then bz0 = b end
    if c < bz0 then bz0 = c end
  end
  self.sx0, self.sz0 = bx0, bz0
  local SX, SZ = {}, {}
  for k = 0, nt - 1 do
    local o = k * 9
    local a, b, c = T[o + 1], T[o + 4], T[o + 7]
    local lo, hi = a, a
    if b < lo then lo = b elseif b > hi then hi = b end
    if c < lo then lo = c elseif c > hi then hi = c end
    for i = floor((lo - bx0) / w), floor((hi - bx0) / w) do
      local l = SX[i]
      if not l then l = {}; SX[i] = l end
      l[#l + 1] = k
    end
    a, b, c = T[o + 3], T[o + 6], T[o + 9]
    lo, hi = a, a
    if b < lo then lo = b elseif b > hi then hi = b end
    if c < lo then lo = c elseif c > hi then hi = c end
    for i = floor((lo - bz0) / w), floor((hi - bz0) / w) do
      local l = SZ[i]
      if not l then l = {}; SZ[i] = l end
      l[#l + 1] = k
    end
  end
  self.SX, self.SZ = SX, SZ
end

local EPS = 1e-7

-- y yonlu isin: (x, z) noktasindan gecen tum kesisimler arasinda secim
-- dir = 1: y0'dan buyuk en kucuk y (onden arkaya ilk yuzey); dir = -1: y0'dan kucuk en buyuk y
-- Doner: y, ucgen indeksi (0 tabanli) ya da nil
function Model:rayY(x, z, dir, mask, y0)
  local l = self.SX[floor((x - self.sx0) / S.SLAB)]
  if not l then return nil end
  local T, C = self.T, self.C
  local best, bt
  y0 = y0 or (dir > 0 and -huge or huge)
  for i = 1, #l do
    local k = l[i]
    if mask[C[k + 1]] then
      local o = k * 9
      local x1, z1, x2, z2, x3, z3 = T[o + 1], T[o + 3], T[o + 4], T[o + 6], T[o + 7], T[o + 9]
      local d = (z2 - z3) * (x1 - x3) + (x3 - x2) * (z1 - z3)
      if d > 1e-14 or d < -1e-14 then
        local a = ((z2 - z3) * (x - x3) + (x3 - x2) * (z - z3)) / d
        if a >= -EPS and a <= 1 + EPS then
          local b = ((z3 - z1) * (x - x3) + (x1 - x3) * (z - z3)) / d
          if b >= -EPS and a + b <= 1 + EPS then
            local y = a * T[o + 2] + b * T[o + 5] + (1 - a - b) * T[o + 8]
            if dir > 0 then
              if y > y0 and (not best or y < best) then best, bt = y, k end
            else
              if y < y0 and (not best or y > best) then best, bt = y, k end
            end
          end
        end
      end
    end
  end
  return best, bt
end

-- z yonlu isin: dir = 1 yukari (z0'dan buyuk en kucuk z), dir = -1 asagi
function Model:rayZ(x, y, dir, mask, z0)
  local l = self.SX[floor((x - self.sx0) / S.SLAB)]
  if not l then return nil end
  local T, C = self.T, self.C
  local best, bt
  z0 = z0 or (dir > 0 and -huge or huge)
  for i = 1, #l do
    local k = l[i]
    if mask[C[k + 1]] then
      local o = k * 9
      local x1, y1, x2, y2, x3, y3 = T[o + 1], T[o + 2], T[o + 4], T[o + 5], T[o + 7], T[o + 8]
      local d = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
      if d > 1e-14 or d < -1e-14 then
        local a = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / d
        if a >= -EPS and a <= 1 + EPS then
          local b = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / d
          if b >= -EPS and a + b <= 1 + EPS then
            local z = a * T[o + 3] + b * T[o + 6] + (1 - a - b) * T[o + 9]
            if dir > 0 then
              if z > z0 and (not best or z < best) then best, bt = z, k end
            else
              if z < z0 and (not best or z > best) then best, bt = z, k end
            end
          end
        end
      end
    end
  end
  return best, bt
end

-- dusey dogru uzerindeki tum kesisimler [zLo, zHi]: zs (azalan sirali), ts (ucgenler), n
function Model:hitsZ(x, y, mask, zLo, zHi)
  local l = self.SX[floor((x - self.sx0) / S.SLAB)]
  local zs, ts, n = {}, {}, 0
  if not l then return zs, ts, 0 end
  local T, C = self.T, self.C
  for i = 1, #l do
    local k = l[i]
    if mask[C[k + 1]] then
      local o = k * 9
      local x1, y1, x2, y2, x3, y3 = T[o + 1], T[o + 2], T[o + 4], T[o + 5], T[o + 7], T[o + 8]
      local d = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
      if d > 1e-14 or d < -1e-14 then
        local a = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / d
        if a >= -EPS and a <= 1 + EPS then
          local b = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / d
          if b >= -EPS and a + b <= 1 + EPS then
            local z = a * T[o + 3] + b * T[o + 6] + (1 - a - b) * T[o + 9]
            if z >= zLo and z <= zHi then
              n = n + 1
              zs[n], ts[n] = z, k
            end
          end
        end
      end
    end
  end
  -- azalan sirala (ekleme siralamasi: n kucuk)
  for i = 2, n do
    local z, t = zs[i], ts[i]
    local j = i - 1
    while j >= 1 and zs[j] < z do
      zs[j + 1], ts[j + 1] = zs[j], ts[j]
      j = j - 1
    end
    zs[j + 1], ts[j + 1] = z, t
  end
  return zs, ts, n
end

-- x yonlu isin: dir = 1 (+x yonunde, x0'dan buyuk en kucuk x), dir = -1
function Model:rayX(y, z, dir, mask, x0)
  local l = self.SZ[floor((z - self.sz0) / S.SLAB)]
  if not l then return nil end
  local T, C = self.T, self.C
  local best, bt
  x0 = x0 or (dir > 0 and -huge or huge)
  for i = 1, #l do
    local k = l[i]
    if mask[C[k + 1]] then
      local o = k * 9
      local y1, z1, y2, z2, y3, z3 = T[o + 2], T[o + 3], T[o + 5], T[o + 6], T[o + 8], T[o + 9]
      local d = (z2 - z3) * (y1 - y3) + (y3 - y2) * (z1 - z3)
      if d > 1e-14 or d < -1e-14 then
        local a = ((z2 - z3) * (y - y3) + (y3 - y2) * (z - z3)) / d
        if a >= -EPS and a <= 1 + EPS then
          local b = ((z3 - z1) * (y - y3) + (y1 - y3) * (z - z3)) / d
          if b >= -EPS and a + b <= 1 + EPS then
            local xx = a * T[o + 1] + b * T[o + 4] + (1 - a - b) * T[o + 7]
            if dir > 0 then
              if xx > x0 and (not best or xx < best) then best, bt = xx, k end
            else
              if xx < x0 and (not best or xx > best) then best, bt = xx, k end
            end
          end
        end
      end
    end
  end
  return best, bt
end

-- ucgenin birim normali (yonlendirilmemis)
function Model:normal(k)
  local T = self.T
  local o = k * 9
  local ux, uy, uz = T[o + 4] - T[o + 1], T[o + 5] - T[o + 2], T[o + 6] - T[o + 3]
  local vx, vy, vz = T[o + 7] - T[o + 1], T[o + 8] - T[o + 2], T[o + 9] - T[o + 3]
  local nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
  local l = sqrt(nx * nx + ny * ny + nz * nz)
  if l < 1e-12 then return 0, 0, 1 end
  return nx / l, ny / l, nz / l
end

function Model:meshOf(k)
  return self.meshes[self.MI[k + 1]]
end

-----------------------------------------------------------------------------------------------
-- camlar: on cam, arka cam, yan camlar
-----------------------------------------------------------------------------------------------
function Model:findGlass()
  local T, C, nt = self.T, self.C, self.nt
  local cand = {}
  local sideL, sideR = {}, {}
  local sySum, sArea = 0, 0
  local gy0, gy1 = huge, -huge
  for k = 0, nt - 1 do
    if C[k + 1] == GLASS then
      local o = k * 9
      local ux, uy, uz = T[o + 4] - T[o + 1], T[o + 5] - T[o + 2], T[o + 6] - T[o + 3]
      local vx, vy, vz = T[o + 7] - T[o + 1], T[o + 8] - T[o + 2], T[o + 9] - T[o + 3]
      local nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
      local l = sqrt(nx * nx + ny * ny + nz * nz)
      if l > 1e-12 then
        local area = l / 2
        nx, ny, nz = abs(nx / l), abs(ny / l), abs(nz / l)
        local cx = (T[o + 1] + T[o + 4] + T[o + 7]) / 3
        local cy = (T[o + 2] + T[o + 5] + T[o + 8]) / 3
        if nx >= 0.7 then
          if cx > 0 then sideL[#sideL + 1] = k else sideR[#sideR + 1] = k end
          sySum, sArea = sySum + cy * area, sArea + area
        elseif ny >= 0.22 and nx < 0.68 then
          cand[#cand + 1] = k
          if cy < gy0 then gy0 = cy end
          if cy > gy1 then gy1 = cy end
        end
      end
    end
  end
  local yc
  if sArea > 0.05 then yc = sySum / sArea
  elseif #cand > 0 then yc = (gy0 + gy1) / 2
  else yc = (self.bbox[2] + self.bbox[5]) / 2 end
  -- yalnizca on cam varsa (yan / arka cam yok) hepsi on cam
  if sArea <= 0.05 and #cand > 0 and (gy1 - gy0) < 1.0 then
    yc = ((gy0 + gy1) / 2 < (self.bbox[2] + self.bbox[5]) / 2) and huge or -huge
  end
  local front, rear = {}, {}
  for i = 1, #cand do
    local k = cand[i]
    local o = k * 9
    local cy = (T[o + 2] + T[o + 5] + T[o + 8]) / 3
    if cy < yc then front[#front + 1] = k else rear[#rear + 1] = k end
  end
  self.glass = {front = front, rear = rear, sideL = sideL, sideR = sideR, yc = yc}
  -- arka camin en buyuk kumesi: birden fazla arka cam (kabin + kasa kapagi) varsa en geridekini degil,
  -- kabine en yakin (en buyuk alanli) olani secmek icin y'ye gore ayristir
  if #rear > 0 then self.glass.rear = self:largestCluster(rear) end
  if #front > 0 then self.glass.front = self:largestCluster(front) end
  -- arka cam bagaj kapaginda mi (hatchback / SUV / station): ucgenlerin cogu "trunk" etiketli modelde
  local gate, tot = 0, 0
  for _, k in ipairs(self.glass.rear) do
    local m = self.meshes[self.MI[k + 1]]
    tot = tot + 1
    if m and m.tag == 'trunk' then gate = gate + 1 end
  end
  self.glass.rearGate = tot > 0 and gate > tot * 0.5
end

-- ucgen listesini y ekseninde 0.6 m'den buyuk bosluklarla kumelere ayir, en buyuk alanliyi dondur
function Model:largestCluster(list)
  local T = self.T
  local items = {}
  for i = 1, #list do
    local k = list[i]
    local o = k * 9
    local ux, uy, uz = T[o + 4] - T[o + 1], T[o + 5] - T[o + 2], T[o + 6] - T[o + 3]
    local vx, vy, vz = T[o + 7] - T[o + 1], T[o + 8] - T[o + 2], T[o + 9] - T[o + 3]
    local nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
    items[i] = {k = k, y = (T[o + 2] + T[o + 5] + T[o + 8]) / 3, a = sqrt(nx * nx + ny * ny + nz * nz) / 2}
  end
  table.sort(items, function(a, b) return a.y < b.y end)
  local clusters = {}
  local cur = {list = {}, area = 0}
  local lastY
  for _, it in ipairs(items) do
    if lastY and it.y - lastY > 0.6 then
      clusters[#clusters + 1] = cur
      cur = {list = {}, area = 0}
    end
    cur.list[#cur.list + 1] = it.k
    cur.area = cur.area + it.a
    lastY = it.y
  end
  clusters[#clusters + 1] = cur
  local best = clusters[1]
  for i = 2, #clusters do
    if clusters[i].area > best.area then best = clusters[i] end
  end
  -- kumede yalnizca baskin modeller kalsin (kucuk lamba camlari, ucgen camlar ayiklanir)
  local MI = self.MI
  local areaBy, amax = {}, 0
  local areaOf = {}
  for _, it in ipairs(items) do areaOf[it.k] = it.a end
  for _, k in ipairs(best.list) do
    local mi = MI[k + 1]
    areaBy[mi] = (areaBy[mi] or 0) + (areaOf[k] or 0)
    if areaBy[mi] > amax then amax = areaBy[mi] end
  end
  local out = {}
  for _, k in ipairs(best.list) do
    if areaBy[MI[k + 1]] >= 0.2 * amax then out[#out + 1] = k end
  end
  return out
end

-- X = x duzlemiyle kesit: cam ucgenlerinin (y, z) kesisim noktalari
-- Doner: profil {n, ys, zs (z'ye gore sirali, ic zarf), zTop, yTop, zBot, yBot} ya da nil
-- sgn = -1: on cam (cam, kabinin onunde: ic zarf = en buyuk y), sgn = 1: arka cam (ic zarf = en kucuk y)
function Model:glassProfile(set, x, sgn)
  local T = self.T
  local pts, np = {}, 0
  for i = 1, #set do
    local o = set[i] * 9
    local x1, x2, x3 = T[o + 1], T[o + 4], T[o + 7]
    local lo, hi = x1, x1
    if x2 < lo then lo = x2 elseif x2 > hi then hi = x2 end
    if x3 < lo then lo = x3 elseif x3 > hi then hi = x3 end
    if x >= lo and x <= hi and hi > lo then
      for e = 0, 2 do
        local a, b = o + e * 3, o + ((e + 1) % 3) * 3
        local xa, xb = T[a + 1], T[b + 1]
        if (xa <= x and xb > x) or (xb <= x and xa > x) then
          local u = (x - xa) / (xb - xa)
          np = np + 1
          pts[np] = {T[a + 2] + u * (T[b + 2] - T[a + 2]), T[a + 3] + u * (T[b + 3] - T[a + 3])}
        end
      end
    end
  end
  if np < 2 then return nil end
  -- z'ye gore 1 cm'lik kutular; her kutuda ic zarf
  local zmin, zmax = huge, -huge
  for i = 1, np do
    local z = pts[i][2]
    if z < zmin then zmin = z end
    if z > zmax then zmax = z end
  end
  if zmax - zmin < 0.05 then return nil end
  -- kesit parcalarini sik ornekle: her ucgen kenar cifti bir dogru parcasi verir (ardisik noktalar)
  local bin = 0.01
  local nb = floor((zmax - zmin) / bin) + 1
  local by = {}
  local function put(y, z)
    local bi = floor((z - zmin) / bin) + 1
    local cur = by[bi]
    if not cur or (sgn < 0 and y > cur) or (sgn > 0 and y < cur) then by[bi] = y end
  end
  for i = 1, np - 1, 2 do
    local a, b = pts[i], pts[i + 1]
    if b then
      local dz = abs(b[2] - a[2])
      local steps = max(1, floor(dz / (bin * 0.5)))
      for q = 0, steps do
        local u = q / steps
        put(a[1] + u * (b[1] - a[1]), a[2] + u * (b[2] - a[2]))
      end
    end
  end
  local ys, zs, n = {}, {}, 0
  for bi = 1, nb do
    if by[bi] then
      n = n + 1
      ys[n] = by[bi]
      zs[n] = zmin + (bi - 0.5) * bin
    end
  end
  if n < 3 then return nil end
  -- ust / alt uc: gercek uc noktalar
  local yTop, yBot
  for i = 1, np do
    local p = pts[i]
    if p[2] >= zmax - 1e-6 then
      if not yTop or (sgn < 0 and p[1] > yTop) or (sgn > 0 and p[1] < yTop) then yTop = p[1] end
    end
    if p[2] <= zmin + 1e-6 then
      if not yBot or (sgn < 0 and p[1] > yBot) or (sgn > 0 and p[1] < yBot) then yBot = p[1] end
    end
  end
  local prof = {n = n, ys = ys, zs = zs, zTop = zmax, yTop = yTop or ys[n], zBot = zmin, yBot = yBot or ys[1], sgn = sgn}
  -- uclardaki egim (dy/dz): en kucuk kareler, uca yakin 14 cm
  local function slope(fromTop)
    local sz, sy, szz, szy, m = 0, 0, 0, 0, 0
    for i = 1, n do
      local z = zs[i]
      if (fromTop and z > zmax - 0.14) or (not fromTop and z < zmin + 0.14) then
        sz, sy, szz, szy, m = sz + z, sy + ys[i], szz + z * z, szy + z * ys[i], m + 1
      end
    end
    local den = m * szz - sz * sz
    if m < 2 or abs(den) < 1e-12 then return 0 end
    return (m * szy - sz * sy) / den
  end
  prof.kTop = slope(true)
  prof.kBot = slope(false)
  return prof
end

-- profilde z yuksekligindeki cam y'si (uclarin disinda egimle uzatilir)
function S.profY(prof, z)
  local zs, ys, n = prof.zs, prof.ys, prof.n
  if z >= zs[n] then return prof.yTop + (z - prof.zTop) * prof.kTop end
  if z <= zs[1] then return prof.yBot + (z - prof.zBot) * prof.kBot end
  -- ikili arama
  local lo, hi = 1, n
  while hi - lo > 1 do
    local mid = floor((lo + hi) / 2)
    if zs[mid] <= z then lo = mid else hi = mid end
  end
  local u = (z - zs[lo]) / (zs[hi] - zs[lo])
  return ys[lo] + u * (ys[hi] - ys[lo])
end

-- camin (yaklasik) yanal yari genisligi: ust kenardan dz kadar asagida
function Model:glassHalfWidth(set, zFromTop)
  local T = self.T
  local zmax = -huge
  for i = 1, #set do
    local o = set[i] * 9
    zmax = max(zmax, T[o + 3], T[o + 6], T[o + 9])
  end
  local hw = 0
  local zl = zmax - (zFromTop or 0.08)
  for i = 1, #set do
    local o = set[i] * 9
    for v = 0, 2 do
      if T[o + v * 3 + 3] >= zl - 0.06 then hw = max(hw, abs(T[o + v * 3 + 1])) end
    end
  end
  return hw, zmax
end

-----------------------------------------------------------------------------------------------
-- yer isaretleri: farlar, stoplar, izgara, tamponlar, aynalar, plaka
-----------------------------------------------------------------------------------------------
local function unionBox(b, mb)
  if not b then return {mb[1], mb[2], mb[3], mb[4], mb[5], mb[6]} end
  b[1], b[2], b[3] = min(b[1], mb[1]), min(b[2], mb[2]), min(b[3], mb[3])
  b[4], b[5], b[6] = max(b[4], mb[4]), max(b[5], mb[5]), max(b[6], mb[6])
  return b
end

function Model:findLandmarks()
  local bb = self.bbox
  local ymid = (bb[2] + bb[5]) / 2
  local L = {}
  for _, m in ipairs(self.meshes) do
    local mb = m.bbox
    if mb and m.t1 >= m.t0 then
      local cy = (mb[2] + mb[5]) / 2
      local cx = (mb[1] + mb[4]) / 2
      local front = cy < ymid
      local tag = m.tag
      if m.cls == LAMP and (tag == 'headlight' or tag == 'taillight' or tag == 'foglight' or tag == 'chmsl') then
        local key = tag
        if tag == 'headlight' and not front then key = nil end
        if tag == 'taillight' and front then key = nil end
        if key then
          -- sol / sag ayri (ortali tek parca ise ikiye bol)
          if (mb[4] - mb[1]) > 0.9 and abs(cx) < 0.15 then
            L[key] = unionBox(L[key], {max(mb[1], 0.3), mb[2], mb[3], mb[4], mb[5], mb[6]})
          elseif cx > 0.1 or key == 'chmsl' then
            L[key] = unionBox(L[key], mb)
          elseif cx < -0.1 then
            L[key] = unionBox(L[key], {-mb[4], mb[2], mb[3], -mb[1], mb[5], mb[6]})
          end
        end
      elseif m.cls == BODY then
        if tag == 'grille' and front then L.grille = unionBox(L.grille, mb)
        elseif tag == 'bumper' then
          if front then L.bumperF = unionBox(L.bumperF, mb) else L.bumperR = unionBox(L.bumperR, mb) end
        elseif tag == 'hood' and front then L.hood = unionBox(L.hood, mb)
        elseif tag == 'trunk' and not front then L.trunk = unionBox(L.trunk, mb)
        elseif tag == 'mirror' then
          if cx > 0.3 then L.mirrorL = unionBox(L.mirrorL, mb) elseif cx < -0.3 then L.mirrorR = unionBox(L.mirrorR, mb) end
        elseif tag == 'roof' then L.roof = unionBox(L.roof, mb)
        end
      end
    elseif m.cls == PLATE and m.pos then
      if m.pos[2] < ymid then L.plateF = m.pos else L.plateR = m.pos end
    end
  end
  -- yedek: lamba adlari bilgi vermiyorsa (ornek: Automation disa aktarimlarinda tum lambalar "headlight" adli ya da govde
  -- modelinin icinde) far / stop konumu, aracin on / arka ucundaki lamba ucgenlerinin alan agirlikli merkezinden
  if not L.headlight or not L.taillight then
    local T, C = self.T, self.C
    local zlo, zhi = bb[3] + 0.2, bb[3] + 0.8 * (bb[6] - bb[3])
    local fr, rr = {0, 0, 0, 0}, {0, 0, 0, 0}
    for k = 0, self.nt - 1 do
      if C[k + 1] == LAMP then
        local q = k * 9
        local x = (T[q + 1] + T[q + 4] + T[q + 7]) / 3
        local z = (T[q + 3] + T[q + 6] + T[q + 9]) / 3
        if x > 0.2 and z > zlo and z < zhi then
          local y = (T[q + 2] + T[q + 5] + T[q + 8]) / 3
          local s = (y < bb[2] + 0.8) and fr or ((y > bb[5] - 0.8) and rr or nil)
          if s then
            local ux, uy, uz = T[q + 4] - T[q + 1], T[q + 5] - T[q + 2], T[q + 6] - T[q + 3]
            local vx, vy, vz = T[q + 7] - T[q + 1], T[q + 8] - T[q + 2], T[q + 9] - T[q + 3]
            local cx, cy, cz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            local a = 0.5 * sqrt(cx * cx + cy * cy + cz * cz)
            s[1], s[2], s[3], s[4] = s[1] + a * x, s[2] + a * y, s[3] + a * z, s[4] + a
          end
        end
      end
    end
    local function box(s)
      if s[4] < 2e-4 then return nil end
      local x, y, z = s[1] / s[4], s[2] / s[4], s[3] / s[4]
      return {x - 0.08, y - 0.05, z - 0.05, x + 0.08, y + 0.05, z + 0.05}
    end
    if not L.headlight then L.headlight = box(fr) end
    if not L.taillight then L.taillight = box(rr) end
  end
  self.land = L
end

-----------------------------------------------------------------------------------------------
-- yardimci sorgular
-----------------------------------------------------------------------------------------------
-- (x, y) uzerindeki en yuksek govde noktasi (tavan / kaput / bagaj dis yuzeyi)
function Model:topZ(x, y, mask)
  return self:rayZ(x, y, -1, mask or S.M_EXT, huge)
end

-- on / arka dis yuzey: dir = 1 on (en kucuk y), dir = -1 arka (en buyuk y)
function Model:faceY(x, z, dir, mask)
  return self:rayY(x, z, dir, mask or S.M_EXT)
end

-- yan dis yuzey: side = 1 sol (+x, en buyuk x), side = -1 sag
function Model:faceX(y, z, side, mask)
  return self:rayX(y, z, -side, mask or S.M_EXT)
end

S.Model = Model
return S
