-- Better Concealed Flashers PRO 3 - fabrika konumlari
-- Oyunun (ya da bir modun) bu araca ozel hazirladigi gizli cakar parcalarini okur: aracin su anki parca agacindaki
-- yuvalara takilabilen "flasher / concealed / emergency lights" parcalarinin icindeki cakar basliklarinin tam
-- konumu, acisi ve olcusu alinir. Bu konumlar aracin yapimcisinin elle yerlestirdigi konumlardir; otomatik
-- yerlesimde once bunlar kullanilir (kaynak: "fabrika"), olmayan bolgelerde yuzey taramasi devreye girer.
local H = {}
local mods
local U, S, P, E

local jbeamIO, ss

local min, max, abs, floor, sqrt, huge = math.min, math.max, math.abs, math.floor, math.sqrt, math.huge

function H.init(m)
  mods = m
  U, S, P, E = m.U, m.Sc, m.Pl, m.E
  jbeamIO = require('jbeam/io')
  ss = require('jbeam/slotSystem')
end

-- oyunun genel cakar modeli (generic_flasher_led_*): 65.2 x 17 x 40.6 mm, merkez orijin
H.DEV = {w = 0.0652, h = 0.0406, d = 0.0170}

local NAME_WORDS = {'flasher', 'concealed', 'emergencylight', 'emergency_light', 'beaconlight', 'strobe', 'hideaway',
  'warninglight', 'warning_light', 'decklight', 'dashlight', 'visorlight', 'cakar'}
local BAR_WORDS = {'lightbar', 'light_bar'}

local function isList(t) return type(t) == 'table' and t[1] ~= nil end

local function isFlasherMesh(mesh)
  return type(mesh) == 'string' and mesh:find('generic_flasher_led', 1, true) ~= nil
end
H.isFlasherMesh = isFlasherMesh

local function stripSlotOptions(so)
  so.name, so.type, so.allowTypes, so.denyTypes, so.default, so.description, so.maxRecursion = nil, nil, nil, nil, nil, nil, nil
  if so.coreSlot == true then so.coreSlot = nil end
  so.variables = nil
  return so
end

local function normYaw(a)
  a = a % 360
  if a < 0 then a = a + 360 end
  return a
end

local function facingOf(rz)
  local a = normYaw(rz)
  if a < 50 or a > 310 then return 'F' end
  if a > 130 and a < 230 then return 'R' end
  return 'S'
end

local function clamp(v, a, b) if v < a then return a elseif v > b then return b end return v end

-----------------------------------------------------------------------------------------------
-- bir fabrika basliginin bolgesi
-----------------------------------------------------------------------------------------------
local function zoneFor(env, h)
  local M = env.M
  local face = facingOf(h.rz)
  local gl = U.lower(table.concat(h.groups or {}, ' '))
  local hw, hh, hd = h.dims.w / 2, h.dims.h / 2, h.dims.d / 2
  if face == 'F' then
    if M and M.glass.front and #M.glass.front > 0 then
      local prof = M:glassProfile(M.glass.front, h.x, -1)
      if prof then
        local gy = S.profY(prof, clamp(h.z, prof.zBot, prof.zTop))
        if h.y > gy - 0.04 and h.y < prof.yTop + 1.1 and h.z > prof.zBot - 0.10 and h.z < prof.zTop + 0.12 then
          return (h.z > (prof.zTop + prof.zBot) / 2) and 'windshield' or 'dash'
        end
      end
    end
    if gl:find('mirror', 1, true) then return 'mirrors' end
    if gl:find('hood', 1, true) then return 'hood' end
    if gl:find('grille', 1, true) or gl:find('fascia', 1, true) then return 'grille' end
    if gl:find('bumper', 1, true) or gl:find('lip', 1, true) or gl:find('nosecone', 1, true) then return 'bumperF' end
    if M then
      local F = P.frames(M)
      -- on yuzden cok geride (kabin hizasi) ve yuksekteyse: cam ici say
      if h.y > M.bbox[2] + 0.9 and h.z > F.zRoof - 0.5 then return 'windshield' end
      local p = P.faceY(M, 1, h.x, h.z, hw, hh, hd, {follow = 0})
      if p then
        if p.tag == 'grille' then return 'grille' end
        if p.tag == 'hood' then return 'hood' end
        if p.tag == 'bumper' then return 'bumperF' end
        if p.tag == 'mirror' then return 'mirrors' end
      end
      return (h.z >= F.zHead - 0.12) and 'grille' or 'bumperF'
    end
    return 'bumperF'
  elseif face == 'R' then
    if M and M.glass.rear and #M.glass.rear > 0 then
      local prof = M:glassProfile(M.glass.rear, h.x, 1)
      if prof then
        local gy = S.profY(prof, clamp(h.z, prof.zBot, prof.zTop))
        if h.y < gy + 0.04 and h.y > prof.yTop - 1.1 and h.z > prof.zBot - 0.10 and h.z < prof.zTop + 0.12 then
          return (h.z > (prof.zTop + prof.zBot) / 2) and 'rearglass' or 'reardeck'
        end
      end
    end
    if gl:find('trunk', 1, true) or gl:find('tailgate', 1, true) or gl:find('hatch', 1, true) or gl:find('decklid', 1, true) then return 'trunk' end
    if gl:find('bumper', 1, true) then return 'bumperR' end
    if M then
      local F = P.frames(M)
      if h.y < M.bbox[5] - 0.6 and h.z > F.zRoof - 0.6 then return 'rearglass' end
      local p = P.faceY(M, -1, h.x, h.z, hw, hh, hd, {follow = 0})
      if p then
        if p.tag == 'trunk' then return 'trunk' end
        if p.tag == 'bumper' then return 'bumperR' end
      end
      return (h.z >= F.zTail - 0.10) and 'trunk' or 'bumperR'
    end
    return 'bumperR'
  else
    if gl:find('mirror', 1, true) then return 'mirrors' end
    if M then
      local F = P.frames(M)
      if h.z > F.zRoof - 0.55 then return 'sideRear' end
      local yc = (M.bbox[2] + M.bbox[5]) / 2
      return (h.y < yc - 0.5) and 'sideF' or 'skirt'
    end
    return 'sideF'
  end
end
H.zoneFor = zoneFor

-----------------------------------------------------------------------------------------------
-- adaylari topla
-----------------------------------------------------------------------------------------------
local function nameMatches(name, words)
  local s = name:lower()
  for _, w in ipairs(words) do if s:find(w, 1, true) then return true end end
  return false
end

local function unitFor(sx, sy, sz)
  if sx >= 1.2 then return 'wide' end
  if sx <= 0.6 and sz <= 0.6 then return 'mini' end
  if sz <= 0.62 then return 'slim' end
  if sx <= 0.78 then return 'mini' end
  return 'std'
end

-- parca icindeki cakar basliklari (x >= 0 tarafi; simetrik kabul edilir)
local function headsOfPart(part, so, vars, path)
  local flex = {}
  E.collectPartFlex(part, so, vars, flex, path)
  local out = {}
  for _, f in ipairs(flex) do
    if isFlasherMesh(f.mesh) then
      local sx, sy, sz = f.scale.x, f.scale.y, f.scale.z
      out[#out + 1] = {x = f.pos.x, y = f.pos.y, z = f.pos.z, rx = f.rot.x, ry = f.rot.y, rz = f.rot.z,
        dims = {w = H.DEV.w * abs(sx), h = H.DEV.h * abs(sz), d = H.DEV.d * abs(sy)}, unit = unitFor(abs(sx), abs(sy), abs(sz)),
        groups = f.groups, dg = f.dg, mesh = f.mesh}
    end
  end
  return out
end

-- satirlara ayir: ayni bolgedeki basliklar y / z olarak ayriksa (iki sira) en kalabalik sira alinir
local function bestRow(list)
  if #list <= 1 then return list end
  local rows = {}
  for _, h in ipairs(list) do
    local placed = false
    for _, r in ipairs(rows) do
      if abs(r.z - h.z) < 0.05 and abs(r.y - h.y) < 0.20 then
        r.list[#r.list + 1] = h
        placed = true
        break
      end
    end
    if not placed then rows[#rows + 1] = {y = h.y, z = h.z, list = {h}} end
  end
  table.sort(rows, function(a, b) return #a.list > #b.list end)
  return rows[1].list
end

local function median(t)
  if #t == 0 then return nil end
  table.sort(t)
  return t[floor((#t + 1) / 2)]
end

-- ioCtx, kok parca, gunluk, ortam (cloud / M hazir), degiskenler
function H.collect(ioCtx, rootPart, journal, env, vars)
  local res = {zones = {}, parts = {}, count = 0}
  if type(ioCtx) ~= 'table' then return res end
  local slotMap = jbeamIO.getAvailableSlotNameMap(ioCtx)
  if type(slotMap) ~= 'table' then return res end
  local M = env.M
  -- etkin parcalar
  local active = {}
  local list = {{part = rootPart, so = {}, path = '/' .. tostring(rootPart.partName) .. '/'}}
  active[tostring(rootPart.partName)] = true
  for _, j in ipairs(journal or {}) do
    if type(j[2]) == 'table' and not (type(j[5]) == 'string' and j[5]:find('^/bcfp_')) then
      active[tostring(j[2].partName)] = j
      -- j[5]: /yuva1/.../yuvaN/parcaAdi  -> alt yuvalarin yolu ayni kok
      local base = type(j[5]) == 'string' and (j[5]:match('^(.*/)') or '/') or '/'
      list[#list + 1] = {part = j[2], so = j[4] or {}, path = base, vars = (type(j[6]) == 'table' and j[6].variables) and E.literalVars(j[6], vars) or vars}
    end
  end
  local seen = {}
  local cands = {}       -- {name, heads, active, slotPath}
  local barCands = {}
  local function consider(name, slotDef, parentSO, pvars, slotPath)
    if seen[name] then return end
    local isFl, isBar = nameMatches(name, NAME_WORDS), nameMatches(name, BAR_WORDS)
    local act = active[name]
    if not (isFl or isBar or act) then return end
    seen[name] = true
    local part = jbeamIO.getPart(ioCtx, name)
    if type(part) ~= 'table' then return end
    local fits = true
    pcall(function() fits = ss.partFitsSlot(part, slotDef) end)
    if not fits then return end
    local so = stripSlotOptions(tableMerge(deepcopy(parentSO or {}), deepcopy(slotDef)))
    local cv = E.literalVars(slotDef, pvars)
    local heads = headsOfPart(part, so, cv, slotPath .. name)
    if #heads > 0 then
      cands[#cands + 1] = {name = name, heads = heads, active = act and true or false, slotPath = slotPath}
      res.count = res.count + 1
    elseif isBar and not isFl then
      -- tepe lambasi: dugumlerinin sinir kutusu (tavan cubugu icin fabrika yeri)
      local nodes = {}
      E.collectPartNodes(part, so, nodes, slotPath, cv)
      local x0, y0, z0, x1, y1, z1, n = huge, huge, huge, -huge, -huge, -huge, 0
      for _, nd in pairs(nodes) do
        n = n + 1
        x0, y0, z0 = min(x0, nd.x), min(y0, nd.y), min(z0, nd.z)
        x1, y1, z1 = max(x1, nd.x), max(y1, nd.y), max(z1, nd.z)
      end
      if n >= 4 and (x1 - x0) > 0.5 and abs(x0 + x1) < 0.2 then
        barCands[#barCands + 1] = {name = name, active = act and true or false, y = (y0 + y1) / 2, z = z0, len = x1 - x0, depth = y1 - y0, n = n}
      end
    end
  end
  for _, a in ipairs(list) do
    local slots = a.part.slots2 or a.part.slots
    if type(slots) == 'table' then
      for _, slotDef in ipairs(slots) do
        if type(slotDef) == 'table' then
          local slotId = slotDef.name or slotDef.type
          local types = slotDef.allowTypes or (slotDef.type and {slotDef.type}) or {}
          if type(slotId) == 'string' then
            for _, t in ipairs(types) do
              for _, name in ipairs(slotMap[t] or {}) do
                consider(name, slotDef, a.so, a.vars or vars, a.path .. slotId .. '/')
              end
            end
          end
        end
      end
    end
  end

  -- ayni arac ailesindeki diger cakar parcalari (su anki agacta yuvasi olmayanlar): yalnizca yuzey taramasi
  -- ile dogrulanirsa kullanilir (baska govde tipine ait olabilirler)
  if M then
    local all = jbeamIO.getAvailableParts(ioCtx)
    local names = {}
    for name in pairs(type(all) == 'table' and all or {}) do
      if not seen[name] and nameMatches(name, NAME_WORDS) then names[#names + 1] = name end
    end
    table.sort(names)
    for i = 1, math.min(#names, 60) do
      local name = names[i]
      seen[name] = true
      local part = jbeamIO.getPart(ioCtx, name)
      if type(part) == 'table' then
        local okF, heads = pcall(headsOfPart, part, {}, vars, '/?/' .. name)
        if okF and #heads > 0 then
          cands[#cands + 1] = {name = name, heads = heads, active = false, family = true}
          res.count = res.count + 1
        end
      end
    end
  end

  -- bolgelere ayir
  local byZone = {}
  for _, c in ipairs(cands) do
    local zl = {}
    for _, h in ipairs(c.heads) do
      if h.x > -0.012 then
        local ok, zone = pcall(zoneFor, env, h)
        if ok and zone then
          zl[zone] = zl[zone] or {}
          zl[zone][#zl[zone] + 1] = h
        end
      end
    end
    local info = {name = c.name, active = c.active, zones = {}}
    for zone, hl in pairs(zl) do
      local row = bestRow(hl)
      table.sort(row, function(a, b) return a.x < b.x end)
      byZone[zone] = byZone[zone] or {}
      byZone[zone][#byZone[zone] + 1] = {part = c.name, active = c.active, heads = row, family = c.family}
      info.zones[#info.zones + 1] = zone
    end
    table.sort(info.zones)
    res.parts[#res.parts + 1] = info
  end

  for zone, list2 in pairs(byZone) do
    local zd = P.zoneById[zone]
    -- tarama ile tutarlilik: baska govde varyantina ait parcalari ele
    for _, c in ipairs(list2) do
      c.dev = 0
      if M and zd then
        local sum, n = 0, 0
        for _, h in ipairs(c.heads) do
          local q = {follow = 0}
          if zd.kind == 'face' then q.zAbs = h.z end
          local okP, p = pcall(P.head, M, zone, 1, max(h.x, 0.0), h.dims, q)
          if okP and p then
            sum, n = sum + abs(p.y - h.y) + abs(p.z - h.z), n + 1
          end
        end
        if n > 0 then c.dev = sum / n else c.dev = 0.5 end
      end
    end
    table.sort(list2, function(a, b)
      if a.active ~= b.active then return a.active end
      if (a.family and true or false) ~= (b.family and true or false) then return not a.family end
      if abs(a.dev - b.dev) > 0.02 then return a.dev < b.dev end
      if #a.heads ~= #b.heads then return #a.heads > #b.heads end
      return a.part < b.part
    end)
    local c = list2[1]
    local tol = (zd and zd.kind == 'glass') and 0.22 or 0.30
    if c and c.family then
      -- aile adaylari arasinda taramaya en yakin olan; siki tolerans
      for _, o2 in ipairs(list2) do if o2.family and o2.dev < c.dev then c = o2 end end
      tol = 0.09
    end
    if c and not (c.active or not M or c.dev <= tol) then
      res.rejected = res.rejected or {}
      res.rejected[#res.rejected + 1] = {zone = zone, part = c.part, dev = U.r(c.dev, 3), tol = tol}
    end
    if c and (c.active or not M or c.dev <= tol) then
      local heads = {}
      local xs = {}
      for i, h in ipairs(c.heads) do
        heads[i] = {x = max(h.x, 0), y = h.y, z = h.z, yaw = normYaw(h.rz), tilt = -h.rx, roll = h.ry}
        if heads[i].yaw > 180 then heads[i].yaw = heads[i].yaw - 360 end
        if i > 1 then xs[#xs + 1] = abs(h.x - c.heads[i - 1].x) end
      end
      -- arkaya bakanlar 180 civarinda kalsin (sureklilik)
      for _, hd in ipairs(heads) do
        if hd.yaw < -90 then hd.yaw = hd.yaw + 360 end
      end
      local h1 = c.heads[1]
      res.zones[zone] = {heads = heads, pitch = median(xs) or 0.065, head = h1.unit, dims = h1.dims, part = c.part, active = c.active,
        groups = h1.groups, dg = h1.dg, dev = U.r(c.dev, 3), n = #heads, alts = #list2, family = c.family and true or nil}
    end
  end

  -- tavan cubugu
  if #barCands > 0 then
    table.sort(barCands, function(a, b)
      if a.active ~= b.active then return a.active end
      if a.n ~= b.n then return a.n > b.n end
      return a.name < b.name
    end)
    local b = barCands[1]
    res.roofBar = {y = b.y, z = b.z, len = b.len, depth = b.depth, part = b.name, active = b.active}
  end
  return res
end

return H
